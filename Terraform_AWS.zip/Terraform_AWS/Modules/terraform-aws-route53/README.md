# **AWS Route53 Module**

Terraform module to create Route53 on AWS

# **Description**
 
 This module is basically used to create Route53 on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `name`,`comment`,`force_destroy`,`hosted_zone_records` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create_hosted_zone"></a>[create\_hosted\_zone](#input\_create\_hosted\_zone) | Create Route53 Hosted Zone | `bool` | No | false | `false` |
| <a name = "input_hosted_zone_name"></a>[hosted\_zone\_name](#input\_hosted\_zone\_name) | Route53 Hosted Zone Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_hosted_zone_description"></a>[hosted\_zone\_description](#input\_hosted\_zone\_description) | Route53 Hosted Zone Description | `string` | No | "Managed by Terraform" | `"Managed by Terraform"` |
| <a name = "input_force_destroy"></a>[force\_destroy](#input\_force\_destroy) | Route53 Hosted Zone force destroy non managed resources | `bool` | No | false | `false` |
| <a name = "input_hosted_zone_records"></a>[hosted\_zone\_records](#input\_hosted\_zone\_records) | Route53 Hosted Zone Records. Pass Zone ID to create record for Non-Managed Hosted Zone | <pre><code>list(object({<br> zone_id 						= optional(string, null)<br> name 							= string<br> type							= string<br> ttl								= optional(number, null)<br> records 						= optional(list(string), null)<br> set_identifer 					= optional(string, null)<br> alias_name						= optional(string, null)<br> alias_zone_id					= optional(string, null)<br> alias_evaluate_target_health	= optional(bool, true)<br> }))</code></pre> | No | <pre><code>[<br> { <br> zone_id 						= N/A<br> name 							= N/A<br> type							= N/A<br> ttl								= 172800<br> records 						= N/A<br> set_identifer 					= null<br> alias_name						= N/A<br> alias_zone_id					= N/A<br> alias_evaluate_target_health	= true<br> }<br>]</code></pre> | <pre><code>[<br> { <br> zone_id 						= N/A<br> name 							= N/A<br> type							= N/A<br> ttl								= 172800<br> records 						= N/A<br> set_identifer 					= null<br> alias_name						= N/A<br> alias_zone_id					= N/A<br> alias_evaluate_target_health	= true<br> }<br>]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "eventbridge" {
  source                       = "tfe.axisb.com/ax-tfe/route53/aws"
  version                      = "X.X.X"

  name                         = "route53"
  comment                      = "terraform-aws.example.com"
  force_destroy                = false
  hosted_zone_records          = [{ 
                                   zone_id = N/A
                                   name = "geo"
                                   type = "CNAME"
                                   ttl = 5
                                   records = ["mumbai.test.clouddrove.com"]
                                   set_identifer = "mumbai"
                                   alias_name = N/A
                                   alias_zone_id = N/A
                                   alias_evaluate_target_health = true
                                }]

  tags                         = {
                                  Name = "Test"
                                 }

}

```