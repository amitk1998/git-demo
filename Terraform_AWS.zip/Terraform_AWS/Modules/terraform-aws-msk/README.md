# **AWS  MSK Module**

Terraform module to create  MSK on AWS

# **Description**
 
 This module is basically used to create MSK on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `cluster_type`,`name`,`storage_mode`,`number_of_broker_nodes`,`enhanced_monitoring`,`kafka_version`,`broker_node_group_info`,`client_authentication`,`encryption_at_rest_kms_key_arn`,`encryption_in_transit_client_broker`,`cloudwatch_logs`,`firehose`,`s3_logs`,`configuration_name`,`configuration_description`,`kafka_versions`,`server_properties` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_cluster_type"></a>[cluster\\_type](#input\_cluster\_type) | The  cluster type you want to create possible values are serverless Provisioned | `string` | Yes | `N/A` | `"Provisioned"` |
| <a name="input_name"></a>[name](#input\_name) | The name of the MSK cluster | `string` | Yes | `N/A` | `N/A` |
| <a name="input_storage_mode"></a>[storage\_mode](#input\_storage\_mode) | The storage mode for the MSK cluster | `string` | No | null | `null` |
| <a name="input_enhanced_monitoring"></a>[enhanced\_monitoring](#input\_enhanced\_monitoring) | Enhanced monitoring configuration | `string` | No | null | `"PER_TOPIC_PER_BROKER"` |
| <a name="input_kafka_version"></a>[kafka\_version](#input\_kafka\_version) | The Kafka version for the MSK cluster | `string` | Yes | `N/A` | `N/A` |
| <a name="input_broker_node_group_info"></a>[broker\_node\_group\_info](#input\_broker\_node\_group\_info) | Configuration block for the broker node of the kafka cluster | <pre><code>object({<br> az_distribution     = optional(string)<br> client_subnets      = list(string)<br> instance_type       = string<br> security_groups     = list(string)<br> volume_size         = optional(number)<br> enabled           = optional(bool)<br> volume_throughput = optional(number)<br> })</code></pre> | Yes | `N/A` | `N/A` |
| <a name="input_client_authentication"></a>[client\_authentication](#input\_client\_authentication) | Configuration block for specifying clinet authentication | <pre><code>object({<br> unauthenticated = optional(bool)<br> sasl = optional(map(object({<br> iam   = optional(bool)<br> scram = optional(bool)<br> })))<br> tls = optional(map(object({<br> certificate_authority_arns = list(string)<br> })))<br> })</code></pre> | No | <pre><code>{<br> unauthenticated = false<br> sasl = {<br> iam   = false<br> scram = true<br> }<br> tls = {<br> certificate_authority_arns = []<br> }<br> }</code></pre> | <pre><code>{<br> unauthenticated = false<br> sasl = {<br> iam   = false<br> scram = true<br> }<br> tls = {<br> certificate_authority_arns = []<br> }<br> }</code></pre> |
| <a name="input_encryption_at_rest_kms_key_arn"></a>[encryption\_at\_rest\_kms\_key\_arn](#input\_encryption\_at_rest\_kms\_key\_arn) | KMS key ARN for encryption at rest | `string` | No | null | `"input kms key arn"` |
| <a name="input_encryption_in_transit_client_broker"></a>[encryption\_in\_transit\_client\_broker](#input\_encryption\_in\_transit\_client\_broker) | Enable encryption for client-to-broker communication | `string` | No | "TLS" | `"TLS"` |
| <a name="input_encryption_in_transit_in_cluster"></a>[encryption\_in\_transit\_in\_cluster](#input\_encryption\_in\_transit\_in\_cluster) | Enable encryption within the cluster | `bool` | No | true | `true` |
| <a name="input_enable_logging_info"></a>[enable\_logging\_info](#input\_enable\_logging\_info) | A flag to enable logging information | `bool` | No | false | `false` |
| <a name="input_enable_broker_logs"></a>[enable\_broker\_logs](#input\_enable\_broker\_logs) | A flag to enable broker logs | `bool` | No | false | `false` |
| <a name="input_cloudwatch_logs"></a>[cloudwatch\_logs](#input\_cloudwatch\_logs) | CloudWatch logs configuration | <pre><code>object({<br> cloudwatch_logs_enabled = bool<br> })</code></pre> | No | <pre><code>{<br> cloudwatch_logs_enabled = true<br> }</code></pre> | <pre><code>{<br> cloudwatch_logs_enabled = true<br> }</code></pre> |
| <a name="input_enable_firehose_logs"></a>[enable\_firehose\_logs](#input\_enable\_firehose\_logs) | A flag to enable Firehose logs | `bool` | No | false | `false` |
| <a name="input_firehose"></a>[firehose](#input\_firehose) | Firehose logs configuration | <pre><code>object({<br> firehose_logs_enabled     = optional(bool)<br> firehose_delivery_stream  = optional(string)<br> })</code></pre> | No | <pre><code>{<br> firehose_logs_enabled     = true<br> firehose_delivery_stream  = "qedwsfcsdzvdnvsj"<br> }</code></pre> | <pre><code>{<br> firehose_logs_enabled     = true<br> firehose_delivery_stream  = "qedwsfcsdzvdnvsj"<br> }</code></pre> |
| <a name="input_s3_logs"></a>[s3\_logs](#input\_s3\_logs) | S3 logs configuration | <pre><code>object({<br> s3_logs_enabled = optional(bool)<br> s3_logs_bucket  = optional(string)<br> s3_logs_prefix  = optional(string)<br> })</code></pre> | No | <pre><code>{<br> s3_logs_enabled = true<br> s3_logs_bucket  = ""<br> s3_logs_prefix  = "logs/msk"<br> }</code></pre> | <pre><code>{<br> s3_logs_enabled = true<br> s3_logs_bucket  = ""<br> s3_logs_prefix  = "logs/msk"<br> }</code></pre> |
| <a name="input_number_of_broker_nodes"></a>[number\_of\_broker\_nodes](#input\_number\_of\_broker\_nodes) | The number of broker nodes for the MSK cluster | `number` | No | 2 | `2` |
| <a name="input_enable_open_monitoring"></a>[enable\_open\_monitoring](#input\_enable\_open\_monitoring) | A flag to enable open monitoring | `bool` | No | false | `false` |
| <a name="input_create_cluster_policy"></a>[create\_cluster\_policy](#input\_create\_cluster\_policy) | Set to true to create the MSK cluster policy, or false to skip | `bool` | No | false | `false` |
| <a name="input_policy"></a>[policy](#input\_policy) | The MSK cluster policy JSON document | `string` | Yes | `N/A` | `N/A` |
| <a name="input_create_msk_configuration"></a>[create\_msk\_configuration](#input\_create\_msk\_configuration) | Set to true to create the MSK configuration, or false to skip | `bool` | No | false | `false` |
| <a name="input_configuration_name"></a>[configuration\_name](#input\_configuration\_name) | The name of the MSK configuration | `string` | Yes | `N/A` | `N/A` |
| <a name="input_configuration_description"></a>[configuration\_description](#input\_configuration\_description) | The description of the MSK configuration | `string` | No | null | `"msk cluster configuration"` |
| <a name="input_kafka_versions"></a>[kafka\_versions](#input\_kafka\_versions) | The version of Kafka for the MSK configuration | `string` | Yes | `N/A` | `N/A` |
| <a name="input_create_msk_scram_secret_association"></a>[create\_msk\_scram\_secret\_association](#input\_create\_msk\_scram\_secret\_association) | Set to true to create the MSK SCRAM secret association, or false to skip | `string` | No | false | `false` |
| <a name="input_scram_secret_association_secret_arn_list"></a>[scram\_secret\_association\_secret\_arn\_list](#input\_scram\_secret\_association\_secret\_arn\_list) | List of SCRAM secret ARNs to associate with the MSK cluster | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_vpc_connections"></a>[vpc\_connections](#input\_vpc\_connections) | A map of objects, each defining a VPC connection configuration | <pre><code>list(object({<br> authentication     = string<br> client_subnets     = list(string)<br> security_groups    = list(string)<br> vpc_id             = string<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name="input_serverless_cluster_name"></a>[serverless\_cluster\_name](#input\_serverless\_cluster\_name) | The name for the AWS MSK Serverless Cluster | `string` | Yes | `N/A` | `N/A` |
| <a name="input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | A list of subnet IDs where the MSK Serverless Cluster will be deployed | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | A list of security group IDs to associate with the MSK Serverless Cluster | `list(string)` | No | ["sg-a3o8u33y3yh3i3"] |`["sg-a3o8u33y3yh3i3"]` |
| <a name="input_enable_iam_authentication"></a>[enable\_iam\_authentication](#input\_enable\_iam\_authentication) | Set to true to enable IAM-based authentication for the MSK Serverless Cluster | `bool` | No | true | `true` |
| <a name="input_cluster_arn"></a>[cluster\_arn](#input\_cluster\_arn) | The ARN of the MSK cluster | `string` | Yes | `N/A` | `N/A` |
| <a name="input_server_properties"></a>[server\_properties](#input\_server\_properties) | The server properties for the MSK cluster | `string` | Yes | `N/A` | `N/A` |
| <a name="input_tags"></a>[tags](#input\_tags) | Resource Tags. | `map(string)` | No | `{}` | `{}` |

## **Example Usage**

```hcl

module "msk_configuration" {
  source                              = "tfe.axisb.com/ax-tfe/msk/aws"
  version                             = "X.X.X"
 
  cluster_type                        = "Provisioned"
  name                                = "axwstestpocmskcluster"
  storage_mode                        = "LOCAL"
  number_of_broker_nodes              = 2
  enhanced_monitoring                 = "PER_TOPIC_PER_BROKER"
  kafka_version                       = "3.2.0"
 
  broker_node_group_info              = {
                                         az_distribution      = "DEFAULT"
                                         client_subnets       = ["subnet-03b1227d5071ac12f", "subnet-0ed4e4260c516b7db"]
                                         instance_type        = "kafka.m5.4xlarge"
                                         security_groups      = ["sg-01b745a8225377c38"]
                                         volume_size          = 1000
                                         enabled              = true
                                         volume_throughput    = 250
                                        }

    client_authentication             = {
                                          unauthenticated     = false
                                          sasl = {
                                                  "msk-sasl"  = {
                                                                 iam                         = false
                                                                 scram                       = true
                                                                }
                                                }
                                          tls  = {
                                                   "msk-tls"  = {
                                                                 certificate_authority_arns = null
                                                                }
                                                  }
                                        }
 
  encryption_at_rest_kms_key_arn      = "arn:aws:kms:ap-south-1:12345678912:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  encryption_in_transit_client_broker = "TLS"
  encryption_in_transit_in_cluster    = true
  enable_logging_info                 = false 
  enable_broker_logs                  = false  
 
  cloudwatch_logs                     = {
                                         cloudwatch_logs_enabled    = true
                                        }
 
  firehose                             = {
                                          firehose_logs_enabled     = true
                                          firehose_delivery_stream  = "qedwsfcsdzvdnvsj"
                                         }
 
  s3_logs                              = {
                                          s3_logs_enabled           = true
                                          s3_logs_bucket            = ""
                                          s3_logs_prefix            = "logs/msk"
                                         }

  create_msk_configuration             = true
  configuration_name                   = "testmskconfiguration"
  configuration_description            = "msk test poc configuration description"
  kafka_versions                       = ["2.1.0"]
  server_properties                    = <<PROPERTIES
  auto.create.topics.enable            = true
  delete.topic.enable                  = true
  PROPERTIES

  tags                                 = {
                                          Name = "Test"
                                         }
 
}

```