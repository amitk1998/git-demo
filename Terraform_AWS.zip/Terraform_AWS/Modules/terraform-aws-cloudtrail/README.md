# **AWS  CloudTrail Module**

Terraform module to create  CloudTrail on AWS

# **Description**
 
 This module is basically used to  create cloud trail on Amazon Web Services(AWS).
 To create  cloud trail it requires few attributes like `create_trail`,`trail_name`,`bucket_name`,`bucket_key_prefix` , `enable_cloudwatch_logging` , `kms_key_arn` , `event_selector`  etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_create_trail"></a>[create\_trail](#input\_create\_trail) | Create Trail. | `bool` | No | `false` | `false` |
| <a name="input_trail_name"></a>[trail\_name](#input\_trail\_name) | Trail Name. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_enable_cloudwatch_logging"></a>[enable\_cloudwatch\_logging](#input\_enable\_cloudwatch\_logging) | Enable Cloudwatch Logging for the trail. | `bool` | No | `true` | `true` |
| <a name="input_bucket_name"></a>[bucket\_name](#input\_bucket\_name) | Bucket Name for publishing log files. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_bucket_key_prefix"></a>[bucket\_key\_prefix](#input\_bucket\_key\_prefix) | Bucket Key Path Prefix for publishing log files. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_enable_log_file_validation"></a>[enable\_log\_file\_validation](#input\_enable\_log\_file\_validation) | Enable Log File Integrity Validation. | `bool` | No | `false` | `false` |
| <a name="input_is_multi_region_trail"></a>[is\_multi\_region\_trail](#input\_is\_multi\_region\_trail) | Trail to be created in the current region or all regions. | `bool` | NO | `false` | `false` |
| <a name="input_is_organization_trail"></a>[is\_organization\_trail](#input\_is\_organization\_trail) | Trail to be created is an Organization Trail. Can only be enabled for the organization master account. | `bool` | No | `false` | `false` |
| <a name="input_include_global_service_events"></a>[include\_global\_service\_events](#input\_include\_global\_service\_events) | Specifies whether the trail is publishing events from global services such as IAM. | `bool` | No | `true` | `false` |
| <a name="input_sns_topic_name"></a>[sns\_topic\_name](#input\_sns\_topic\_name) | SNS Topic Name for Log Delivery Notifications. | `string` | No | `null` | `Input your sns topic name` |
| <a name="input_enable_api_call_rate_insight"></a>[enable\_api\_call\_rate\_insight](#input\_enable\_api\_call\_rate\_insight) | Cloudtrail Enable API Call Rate Insights. | `bool` | No | `false` | `false` |
| <a name="input_enable_api_error_rate_insight"></a>[enable\_api\_error\_rate\_insight](#input\_enable\_api\_error\_rate\_insight) | Cloudtrail Enable API Error Rate Insights. | `bool` | No | `false` | `false` |
| <a name="input_event_selector"></a>[event\_selector](#input\_event\_selector) | Cloudtrail Event Selector. | <pre><code>object({ <br> read_write_type = optional(string, "All") <br> include_management_events = optional(bool, true) <br> exclude_management_event_sources = optional(list(string), null) <br> data_resource = list(object({ br> type = string <br> values = list(string) })) <br> }) </code></pre>` | No | <pre><code>object({ <br> read_write_type = all <br> include_management_events = true <br> exclude_management_event_sources = null <br> data_resource = list(object({ <br> type = N/A <br> values = N/A })) <br> }) </code></pre> | <pre><code>object({ <br> read_write_type = all <br> include_management_events = true <br> exclude_management_event_sources = null <br> data_resource = list(object({ <br> type = N/A <br> values = N/A })) <br> }) </code></pre> |
| <a name="input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | KMS Key ARN to encrypt logs delivered by CloudTrail. | `string` | No | `null` | `Input your KMS key ARN` |
| <a name="input_log_group_kms_key_arn"></a>[log\_group\_kms\_key\_arn](#input\_log\_group\_kms\_key\_arn) | CloudWatch Log Group KMS Key ARN. | `string` | No | `null` | `Input your log group kms key ARN` |
| <a name="input_log_group_retention_period"></a>[log\_group\_retention\_period](#input\_log\_group\_retention\_period) | CloudWatch Log Group Retention Period. | `number` | No | `7` | `7` |
| <a name="input_log_group_skip_destroy"></a>[log\_group\_skip\_destroy](#input\_log\_group\_skip\_destroy) | CloudWatch Log Group Skip Destroy. | `bool` | No | `false` | `false` |
| <a name="input_tags"></a>[tags](#input\_tags) | Route53 Hosted Zone Resource Tags. | `map(string)` | Yes | `{}` | `N/A` |

## **Example Usage**

```hcl

module "cloudtrail" {
  source                     = "tfe.axisb.com/ax-tfe/cloudtrail/aws"
  version                    = "X.X.X"
  
  create_trail               = true
  trail_name                 = "Terraform-Test-POC"
  bucket_name                = "ax-tfe-eks-poc-bucket1"
  bucket_key_prefix          = "tfecloudtrial/AWSlogs" 
  enable_cloudwatch_logging  = true
  kms_key_arn                = null
  event_selector             = [{ read_write_type = "All" include_management_events = false exculde_management_event_sources = null data_resource = [{ type = "AWS::Lambda::Function" values = ["arn:aws:lambda"] }, { type = "AWS::S3::Object" values = ["arn:aws:s3"] }] }] 

  tags                       = {
                                Name = "Test"
                               }
 
}

```