# **AWS DynamoDb Module**

Terraform module to create DynamoDb on AWS

# **Description**
 
 This module is basically used to create DynamoDb on Amazon Web Services(AWS).
It requires few attributes in order to be created on AWS `name`,`hash_key`,`attributes`,`read_capacity`,`write_capacity` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | DynamoDB Table Name | `string` | No | null | `"example-db-table"` |
| <a name = "input_hash_key"></a>[hash\_key](#input\_hash\_key) | DynamoDB Table Hash Key | `string` | No | null | `"UserId"` |
| <a name = "input_range_key"></a>[range\_key](#input\_range\_key) | DynamoDB Table Range Key | `string` | No | null | `"GameTitle"` |
| <a name = "input_capacity_mode"></a>[capacity\_mode](#input\_capacity\_mode) | DynamoDB Table Capacity Mode. Valid values are PAY_PER_REQUEST and PROVISIONED | `string` | No | "PROVISIONED" | `"PROVISIONED"` |
| <a name = "input_read_capacity"></a>[read\_capacity](#input\_read\_capacity) | DynamoDB Table Read Units | `string` | No | null | `20` |
| <a name = "input_write_capacity"></a>[write\_capacity](#input\_write\_capacity) | DynamoDB Table Write Units | `string` | No | null | `20` |
| <a name = "input_storage_class"></a>[storage\_class](#input\_storage\_class) | DynamoDB Table Storage Class. Valid values are STANDARD and STANDARD_INFREQUENT_ACCESS | `string` | No | "STANDARD" | `"STANDARD"` |
| <a name = "input_enable_streaming"></a>[enable\_streaming](#input\_enable\_streaming) | DynamoDB Enable Streaming | `bool` | No | false | `false` |
| <a name = "input_kinesis_stream_arn"></a>[kinesis\_stream\_arn](#input\_kinesis\_stream\_arn) | Kinesis ARN for Dynamo DB Streaming if streaming is enabled | `string` | No | null | `"input stream arn"` |
| <a name = "input_stream_view_type"></a>[stream\_view\_type](#input\_stream\_view\_type) | DynamoDB Enable Stream Type if Streaming is Enabled. Valid values are KEYS_ONLY, NEW_IMAGE, OLD_IMAGE and NEW_AND_OLD_IMAGE | `string` | No | null | `"KEYS_ONLY"` |
| <a name = "input_enable_delete_protection"></a>[enable_delete_protection](#input\_enable_delete_protection) | DynamoDB Enable Delete Protection | `bool` | No | false | `false` |
| <a name = "input_enable_point_in_time_recovery"></a>[enable\_point\_in\_time\_recovery](#input\_enable\_point\_in\_time\_recovery) | DynamoDB Enable Point In Time Recovery | `bool` | No | false | `false` |
| <a name = "input_attributes"></a>[attributes](#input\_attributes) | DynamoDB Table Attributes. Valid Types are S (String), N (Number) and B (Binary) | <pre><code>list(object({<br> name = string<br> type = string<br> }))</code></pre> | No | [ ] | <pre><code>[{<br> name = "db-attributes"<br>      type = string<br> }]</code></pre> |
| <a name = "input_global_secondary_indexes"></a>[global\_secondary\_indexes](#input\_global\_secondary\_indexes) | DynamoDB Global Secondary Indexes. Valid Projection Types are ALL, INCLUDE, or KEYS_ONLY | <pre><code>list(object({<br> name = string<br> hash_key = string<br> range_key = optional(string)<br> projection_type = string<br> non_key_attributes = optional(list(string))<br> read_capacity = optional(number)<br> write_capacity = optional(number)<br> }))</code></pre> | No | [ ] | <pre><code>[<br>  {<br> name = "GameTitleIndex"<br> hash_key = "GameTitle"<br> range_key = "TopScore"<br> projection_type = "INCLUDE"<br> non_key_attributes = ["Userid"]<br> read_capacity = 20<br> write_capacity = 20<br>  }<br>  ]</code></pre> |
| <a name = "input_local_secondary_indexes"></a>[local\_secondary\_indexes](#input\_local\_secondary\_indexes) | DynamoDB Local Secondary Indexes. Valid Projection Types are ALL, INCLUDE, or KEYS_ONLY | <pre><code>list(object({<br> name = string<br> range_key = string<br> projection_type = string<br> non_key_attributes = optional(list(string))<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> name = "GameTitleIndex"<br> range_key = "TopScore"<br> projection_type = "INCLUDE"<br> non_key_attributes = ["Userid"]<br> }<br> ]</code></pre> |
| <a name = "input_ttl_attribute_name"></a>[ttl\_attribute\_name](#input\_ttl\_attribute\_name) | DynamoDB TTL Attribute Name | `string` | No | null | `"Examplettl"` |
| <a name = "input_kms_key_arn"></a>[kms_key_arn](#input\_kms_key_arn) | DynamoDB KMS Key ARN | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "dynamodb" {
  source          = "tfe.axisb.com/ax-tfe/dynamodb/aws"
  version         = "X.X.X"

  name            = "test-poc-dynamodb-597"
  hash_key        = "TestTableHashKey"
  attributes      = [{ name = "TestTableHashKey" type = "S" }]
  read_capacity   = 20
  write_capacity  = 20

  tags            = {
                     Name = "Test"
                    }
}

```