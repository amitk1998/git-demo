# **AWS ECR Module**

Terraform module to create ECR which is fully-managed Docker Container Registry on AWS

# **Description**
 
 This module is basically used to create Elastic Container Registry on Amazon Web Services(AWS).
 It requires few attributes to create container registry like `name`,`image_tag_mutability`,`encryption_configuration`,`image_scanning_configuration` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\name) | ECR Repository Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_is_repository_mutable"></a>[is\_repository\_mutable](#input\_is\_repository\_mutable) | Is Repository Mutable | `bool` | No | true | `true` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\kms\_key\_arn) | KMS Key Arn | `string` | No | null | `arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf` |
| <a name = "input_enable_scanning"></a>[enable\_scanning](#input\enable\_scanning) | ECR Repository Enable Scanning | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ecr" {
  source          = "tfe.axisb.com/ax-tfe/ecr/aws"
  version         = "X.X.X"
  
  name            = "testpocecr"
  kms_key_arn     = "arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  enable_scanning = true

  tags            = {
                      Name = "Test"
                    }

}

```