# **AWS DocumentDb Module**

Terraform module to create Document Database on AWS

# **Description**
 
 This module is basically used to create Document Database on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `cluster_name`,`engine_version`,`master_username`,`master_password`,`security_group_ids`,`subnet_ids`,`primary_instance_class`,`replicas_count`,`parameter_details`,`parameter_group_name` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_cluster_name"></a>[cluster\_name](#input\_cluster\_name) | DocumentDB Cluster Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_engine_version"></a>[engine\_version](#input\_engine\_version) | DocumentDB Cluster Engine Version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_master_username"></a>[master_username](#input\_master_username) | DocumentDB Cluster Master Username | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_master_password"></a>[master\_password](#input\_master\_password) | DocumentDB Cluster Master Password | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | DocumentDB Cluster Security Group IDs | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | DocumentDB Cluster Subnet IDs | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_backup_retention_period"></a>[backup\_retention\_period](#input\_backup\_retention\_period) | DocumentDB Cluster Backup Retention Period | `number` | Yes | `N/A` | `N/A` |
| <a name = "input_enable_auto_minor_version_upgrade"></a>[enable\_auto\_minor\_version\_upgrade](#input\_enable\_auto\_minor\_version\_upgrade) | DocumentDB Cluster Enable Auto Minor Version Upgrade | `bool` | No | true | `true` |
| <a name = "input_enable_delete_protection"></a>[enable\_delete\_protection](#input\_enable\_delete\_protection) | DocumentDB Cluster Enable Delete Protection | `bool` | No | false | `false` |
| <a name = "input_apply_immediately"></a>[apply\_immediately](#input\_apply\_immediately) | DocumentDB Cluster Apply Changes Immediately | `bool` | No | true | `true` |
| <a name = "input_port"></a>[port](#input\_port) | DocumentDB Cluster Port | `number` | No | 27017 | `27017` |
| <a name = "input_enabled_cloudwatch_log_types"></a>[enabled\_cloudwatch\_log\_types](#input\_enabled\_cloudwatch\_log\_types) | DocumentDB Cluster Logging Types to be Enabled. Valid Values are audit and profiler | `list(string)` | No | ["audit", "profiler"] | `["audit", "profiler"]` |
| <a name = "input_skip_final_snapshot"></a>[skip\_final\_snapshot](#input\_skip\_final\_snapshot) | DocumentDB Cluster Skip Final Snapshot | `bool` | No | false | `false` |
| <a name = "input_snapshot_identifier"></a>[snapshot\_identifier](#input\_snapshot\_identifier) | Snapshot Name or ARN to create DocumentDB Cluster from a Snapshot | `string` | No | null | `"snapshot-name"` |
| <a name = "input_enable_performance_insights"></a>[enable\_performance\_insights](#input\_enable\_performance\_insights) | DocumentDB Cluster Enable Performance Insights | `bool` | No | true | `true` |
| <a name = "input_kms_key_arn"></a>[kms_key_arn](#input\_kms_key_arn) | DocumentDB Cluster KMS Key ARN | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"` |
| <a name = "input_primary_instance_class"></a>[primary\_instance\_class](#input\_primary\_instance\_class) | DocumentDB Cluster Primary Instance Class | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_replicas_count"></a>[replicas\_count](#input\_replicas\_count) | DocumentDB Cluster Replicas Count | `number` | No | 0 | `0` |
| <a name = "input_replica_instance_class"></a>[replica\_instance\_class](#input\_replica\_instance\_class) | DocumentDB Cluster Replicas Instance Class | `string` | No | null | `"db.r5.2xlarge"` |
| <a name = "input_backup_window"></a>[backup\_window](#input\_backup\_window) | DocumentDB Cluster Backup Window | `string` | No | null | `"07:00-09:00"` |
| <a name = "input_maintenance_window"></a>[maintenance\_window](#input\_maintenance\_window) | DocumentDB Cluster Maintenance Window | `string` | No | null | `"input maintenance window"` |
| <a name = "input_use_default_parameter_group"></a>[use\_default\_parameter\_group](#input\_use\_default\_parameter\_group) | DocumentDB Cluster Use Default Parameter Group. If True then AWS Managed Default Parameter Group will be used to create cluster | `bool` | No | false | `false` |
| <a name = "input_cluster_engine_family"></a>[cluster\_engine\_family](#input\_cluster\_engine\_family) | DocumentDB Cluster Engine Family for Parameter Group Ex. docdbx.x | `string` | No | null | `"docdb3.6"` |
| <a name = "input_parameter_group_name"></a>[parameter\_group\_name](#input\_parameter\_group\_name) | DocumentDB Cluster Parameter Group Name. If Parameter Group Name is Empty and use of Default Parameter Group is disabled, then Custom Parameter Group will be created and used to create cluster | `string` | No | null | `"example-parameter-group-name"` |
| <a name = "input_parameter_details"></a>[parameter\_details](#input\_parameter\_details) | DocumentDB Cluster Default Paramter Configuration List | `list(map(string))` | No | null | `[{ name = "tls" value = "enabled" }]` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "documentdb" {
  source                   = "tfe.axisb.com/ax-tfe/documentdb/aws"
  version                  = "X.X.X"

  cluster_name             = "testdocdb-597"
  engine_version           = "5.0.0"
  master_username          = "TestDocDbUser597"
  master_password          = "Admin998"
  security_group_ids       = ["sg-04b2e35dc3688e802","sg-03bf9e76fb7a9a383"]
  subnet_ids               = var.doc_subnet_ids
  primary_instance_class   = "db.r6g.2xlarge"
  replicas_count           = 0
  cluster_engine_family    = "docdb5.0"
  parameter_group_name     = null
  parameter_details        = [{ name = "tls" value = "enabled" }]
  tags                     = {
                              Name = "Test"
                              }
  }

```

