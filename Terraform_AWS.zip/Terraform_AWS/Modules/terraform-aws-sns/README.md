# **AWS SNS Module**

Terraform module to create Simple Notification Service on AWS

# **Description**
 
 This module is basically used to create & manage Simple Notification Service on Amazon Web Services(AWS).
 It requires few attributes like `sns_topic_policy`,`protocol`,`endpoint` etc. 

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_sns_topic_name"></a>[sns\_topic\_name](#input\_sns\_topic\_name) | SNS Topic Name | `string` | No | null | `"example-topic"` |
| <a name = "input_display_name"></a>[display\_name](#input\_display\_name) | SNS Display Name | `string` | No | null | `"example-dispaly"` |
| <a name = "input_sns_delivery_policy"></a>[sns\_delivery\_policy](#input\_sns\_delivery\_policy) | SNS Delivery Policy | `string` | No | null | `"Enter your delivery policy"` |
| <a name = "input_kms_master_key_id"></a>[kms\_master\_key\_id](#input\_kms\_master\_key\_id) | KMS Master Key ID For SNS Topic | `string` | No | null | `"Enter your master kms key"` |
| <a name = "input_enable_fifo_topic"></a>[enable\_fifo\_topic](#input\_enable\_fifo\_topic) | Enable SNS FIFO Topic | `bool` | No | false | `false` |
| <a name = "input_enable_content_based_deduplication"></a>[enable\_content\_based\_deduplication](#input\_enable\_content\_based\_deduplication) | Enable SNS Topic Content Based Deduplication | `bool` | No | false | `false` |
| <a name = "input_existing_topic_name"></a>[existing\_topic\_name](#input\_existing\_topic\_name) | The name of the existing SNS topic | `string` | Yes | null | `"Enter your existing sns topic name"` |
| <a name = "input_subscribers"></a>[subscribers](#input\_subscribers) | SNS Subscription Details Which consist endpoint and protocol | <pre><code>list(object({<br> protocol  = string<br> endpoint  = string<br> }))</code></pre> | No | `N/A` | `N/A` |
| <a name = "input_sns_topic_policy"></a>[sns\_topic\_policy](#input\_sns\_topic\_policy) | SNS Topic Policy | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_data_protection_policy"></a>[data\_protection\_policy](#input\_data\_protection\_policy) | A map of data protection policy statements | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

locals {
    policy = jsonencode(
    {
    "Version": "2012-10-17",
    "Id": "sns-topic-policy",
    "Statement": [
      {
        "Sid": "sns-statement",
        "Effect": "Allow",
        "Principal": {
          "Service": "sns.amazonaws.com"
        },
        "Action": [
          "SNS:Publish",
          "SNS:Subscribe",
          "SNS:Receive",
          "SNS:DeleteTopic"
        ],
      "Resource": "*",
        "Condition": {
          "StringEquals": {
            "AWS:SourceOwner": data.aws_caller_identity.current.account_id
          }
        }
      }
    ]
    })
}

module "sns" {
  source           = "tfe.axisb.com/ax-tfe/sns/aws"
  version          = "X.X.X"
  
  sns_topic_policy = local.policy
  protocol         = "email"
  endpoint         = "testpoc1234@gmail.com"
  tags             = {
                      Name = "Test"
                     }
  
}

```