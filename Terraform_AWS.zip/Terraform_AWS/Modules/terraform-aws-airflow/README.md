# **AWS Airflow Module**

Terraform module to create Airflow on AWS

# **Description**
 
 This module is basically used to create Airflow on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `name`,`dag_s3_path`,`execution_role_arn`,`environment_class`,`max_workers`,`min_workers`,`source_bucket_arn`,`security_group_ids`,`security_group_ids`,`logging_configuration`,`scheduler_log_level`,`webserver_access_mode`,`kms_key`,`subnet_ids` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | The name of the MWAA environment | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | A list of security group IDs for the MWAA environment | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | A list of subnet IDs for the MWAA environment | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_dag_s3_path"></a>[dag\_s3\_path](#input\_dag\_s3\_path) | The Amazon S3 path for DAGs | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_execution_role_arn"></a>[execution\_role\_arn](#input\_execution\_role\_arn) | The ARN of the execution role | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_source_bucket_arn"></a>[source\_bucket\_arn](#input\_source\_bucket\_arn) | The ARN of the source S3 bucket | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_airflow_configuration_options"></a>[airflow\_configuration\_options](#input\_airflow\_configuration\_options) | A map of Airflow configuration options | `map(string)` | No | {} | `{"core.default_task_retries" = 16,"core.parallelism" = 1}` |
| <a name = "input_airflow_version"></a>[airflow\_version](#input\_airflow\_version) | The version of Apache Airflow for the MWAA environment | `string` | No | null | `null` |
| <a name = "input_environment_class"></a>[environment\_class](#input\_environment\_class) | The environment class for the MWAA environment | `string` | No | "mw1.small" | `"mw1.small"` |
| <a name = "input_kms_key"></a>[kms\_key](#input\_kms_key) | The ARN of the AWS Key Management Service (KMS) key for environment encryption | `string` | No | null | `"input kms key arn"` |
| <a name = "input_max_workers"></a>[max\_workers](#input\_max\_workers) | The maximum number of workers | `number` | No | 2 | `2` |
| <a name = "input_min_workers"></a>[min\_workers](#input\_min\_workers) | The minimum number of workers | `number` | No | 1 | `1` |
| <a name = "input_plugins_s3_object_version"></a>[plugins\_s3\_object\_version](#input\_plugins\_s3\_object\_version) | The object version for the plugins S3 path | `string` | No | null | `null` |
| <a name = "input_plugins_s3_path"></a>[plugins\_s3\_path](#input\_plugins\_s3\_path) | The Amazon S3 path for plugins | `string` | No | null | `null` |
| <a name = "input_requirements_s3_object_version"></a>[requirements\_s3\_object\_version](#input\_requirements\_s3\_object\_version) | The object version for the requirements S3 path | `string` | No | null | `null` |
| <a name = "input_requirements_s3_path"></a>[requirements\_s3\_path](#input\_requirements\_s3\_path) | The Amazon S3 path for requirements | `string` | No | null | `null` |
| <a name = "input_webserver_access_mode"></a>[webserver\_access\_mode](#input\_webserver\_access\_mode) | The webserver access mode for the MWAA environment | `string` | No | "PUBLIC_ONLY" | `"PUBLIC_ONLY"` |
| <a name = "input_weekly_maintenance_window_start"></a>[weekly\_maintenance\_window\_start](#input\_weekly\_maintenance\_window\_start) | The start time of the weekly maintenance window | `string` | No | null | `null` |
| <a name = "input_logging_configuration"></a>[logging\_configuration](#input\_logging\_configuration) | Logging configuration settings | <pre><code>list(object({<br> dag_enabled            = optional(bool)<br> dag_log_level          = optional(string)<br> scheduler_logs_enabled = optional(bool)<br> scheduler_log_level    = optional(string)<br> task_logs_enabled      = optional(bool)<br> task_log_level         = optional(string)<br> webserver_logs_enabled = optional(bool)<br> webserver_log_level    = optional(string)<br> worker_logs_enabled    = optional(bool)<br> worker_log_level       = optional(string)<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> dag_enabled            = true<br> dag_log_level          = "DEBUG"<br> scheduler_logs_enabled = true<br> scheduler_log_level    = "INFO"<br> task_logs_enabled      = true<br> task_log_level         = "WARNING"<br> webserver_logs_enabled = true<br> webserver_log_level    = "ERROR"<br> worker_logs_enabled    = true<br> worker_log_level       = "CRITICAL"<br> }<br>]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "airflow_iam_role" {
  source                    = "tfe.axisb.com/ax-tfe/iam/aws"
  version                   = "X.X.X"
  
  role_name                 = "Terraform-Airflow-IAM-Role"
  trust_relationship_policy = jsonencode({
      "Version" : "2012-10-17",
      "Statement" : [
          {
            "Effect" : "Allow",
              "Principal" : {
                "Service" : [
				"airflow-env.amazonaws.com",
				"airflow.amazonaws.com"
				]
            },
            "Action" : "sts:AssumeRole"
          }
        ]
  })

  iam_policy = [{
    name        = "Terraform-Deployment-Airflow-Custom-Policy"
    description = "Airflow IAM Policy"
    policy      = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement": [
        {
            "Effect": "Allow",
            "Action": "airflow:PublishMetrics",
            "Resource": "arn:aws:airflow:ap-south-1:1234567890:environment/*"
        },
        { 
            "Effect": "Deny",
            "Action": "s3:ListAllMyBuckets",
            "Resource": "*"
        },
        { 
            "Effect": "Allow",
            "Action": [ 
                "s3:GetObject*",
                "s3:GetBucket*",
                "s3:List*"
            ],
            "Resource": [
                "arn:aws:s3:::ax-tfe-eks-poc-bucket1",
                "arn:aws:s3:::ax-tfe-eks-poc-bucket1/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogStream",
                "logs:CreateLogGroup",
                "logs:PutLogEvents",
                "logs:GetLogEvents",
                "logs:GetLogRecord",
                "logs:GetLogGroupFields",
                "logs:GetQueryResults"
            ],
            "Resource": [
                "arn:aws:logs:ap-south-1:1234567890:log-group:airflow-Terraform-Airflow-Test-*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:DescribeLogGroups"
            ],
            "Resource": [
                "*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetAccountPublicAccessBlock"
            ],
            "Resource": [
                "*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": "cloudwatch:PutMetricData",
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "sqs:ChangeMessageVisibility",
                "sqs:DeleteMessage",
                "sqs:GetQueueAttributes",
                "sqs:GetQueueUrl",
                "sqs:ReceiveMessage",
                "sqs:SendMessage"
            ],
            "Resource": "arn:aws:sqs:ap-south-1:*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:GenerateDataKey*",
                "kms:Encrypt"
            ],
            "NotResource": "arn:aws:kms:*:1234567890:key/*",
            "Condition": {
                "StringLike": {
                    "kms:ViaService": [
                        "sqs.ap-south-1.amazonaws.com"
                    ]
                }
            }
        }
    ]
    }
   )
  }]
  attach_policy               = true
  create_instance_profile     = false
  tags                        = {
                                 Name = "Test"
                                }
}

```

```hcl

module "airflow" {
  source                      = "tfe.axisb.com/ax-tfe/airflow/aws"
  version                     = "X.X.X"
  
  name                        = var.airflow_name 
  dag_s3_path                 = "/tfe" 
  execution_role_arn          = module.airflow_iam_role.aws_iam_role.arn
  environment_class           = "mw1.small"
  max_workers                 = 2
  min_workers                 = 1 
  source_bucket_arn           = "arn:aws:s3:::ax-tfe-eks-poc-bucket1"
  security_group_ids          = ["sg-01b745a8225377c38"]
  logging_configuration       = [{ dag_enabled = true dag_log_level = "DEBUG" scheduler_logs_enabled = true scheduler_log_level = "INFO" task_logs_enabled = true task_log_level = "WARNING" webserver_logs_enabled = true webserver_log_level = "ERROR" worker_logs_enabled = true worker_log_level = "CRITICAL" }]
  webserver_access_mode       = "PRIVATE_ONLY"
  kms_key                     = "arn:aws:kms:ap-south-1:1234567890:key/282f737a-404d-4dae-beb1-701bb1919d22"
  subnet_ids                  = ["subnet-0f2e7b65cc502f3fd", "subnet-05ca8890f5ab9d87b"]

  tags                        = {
                                 Name = "Test"
                                }

}

```