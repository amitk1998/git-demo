# **AWS  Elasticache Module**

Terraform module to create Elasticache on AWS

# **Description**
 
 This module is basically used to  create Elasticache on Amazon Web Services(AWS).
 It requires these attributes in order to be created on aws `redis_cluster_type`, `engine`,`node_type`, `engine_version`, `initial_cluster_num_cache_nodes`, `security_group_ids`,`ip_discovery`, `memcached_preferred_availability_zones`, `snapshot_name`,`replication_group_description`, `num_cache_clusters`, `num_node_groups`, `replicas_per_node_group`,`redis_authentication_type`, `authentication_mode_type`, `elasticache_parameter_group_name`,  `elasticache_engine_family` etc.

## **Variable Definations**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_name_prefix"></a>[name\_prefix](#input\_name\_prefix) | Name Prefix | `string` | No | `"Test-TFE-ECSHARD"` | `"Test-TFE-ECSHARD"` |
| <a name="input_redis_cluster_type"></a>[redis\_cluster\_type](#input\_redis\_cluster\_type) | Type of Elasticache Redis Cluster. Available options are SHARD, REPLICATION | `string` | No | `null` | `"SHARD"` |
| <a name="input_engine"></a>[engine](#input\_engine) | Elasticache Cluster Engine | `string` | Yes | `N/A` | `N/A` |
| <a name="input_engine_version"></a>[engine\_version](#input\_engine\_version) | Elasticache Cluster Engine Version | `string` | No | `null` | `"7.0"` |
| <a name="input_node_type"></a>[node\_type](#input\_node\_type) | Elasticache Cluster Node Type | `string` | Yes | `N/A` | `N/A` |
| <a name="input_initial_cluster_num_cache_nodes"></a>[initial\_cluster\_num\_cache\_nodes](#input\_initial\_cluster\_num\_cache\_nodes) | Number of Elasticache Cluster Nodes | `number` | Yes | `N/A` | `N/A` |
| <a name="input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | Elasticache Security Group IDs | `list(string)` | No | `[]` | `["sg-37eyiu33y33s"]` |
| <a name="input_apply_immediately"></a>[apply\_immediately](#input\_apply\_immediately) | Whether to apply Immediately | `bool` | No | `false` | `false` |
| <a name="input_auto_minor_version_upgrade"></a>[auto\_minor\_version\_upgrade](#input\_auto\_minor\_version\_upgrade) | Enable Auto Minor Version upgrade | `bool` | No | `false` | `false` |
| <a name="input_replication_group_description"></a>[replication\_group\_description](#input\_replication\_group\_description) | Elasticache REPLICATION Group description | `string` | Yes | `N/A` | `N/A` |
| <a name="input_num_cache_clusters"></a>[num\_cache\_clusters](#input\_num\_cache\_clusters) | Number of Elasticache Cluster | `number` | No | `null` | `2` |
| <a name="input_num_node_groups"></a>[num\_node\_groups](#input\_num\_node\_groups) | Number of Elasticache Node Groups | `number` | No | `null` | `1` |
| <a name="input_replicas_per_node_group"></a>[replicas\_per\_node\_group](#input\_replicas\_per\_node\_group) | Number of Replicas of Elasticache Node Groups | `number` | No | `null` | `1` |
| <a name="input_security_group_names"></a>[security\_group\_names](#input\_security\_group\_names) | Elasticache Security Group Names | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_at_rest_encryption_enabled"></a>[at\_rest\_encryption\_enabled](#input\_at\_rest\_encryption\_enabled) | Enable Encryption at rest | `bool` | No | `false` | `false` |
| <a name="input_users_list"></a>[users\_list](#input\_users\_list) | Users List | `list(map(string))` | No | `[]` | `[]` |
| <a name="input_authentication_mode_type"></a>[authentication\_mode\_type](#input\_authentication\_mode\_type) | Authentication Mode Type. Available Options are iam, password, no-password-required | `string` | No | `null` | `"no-password-required"` |
| <a name="input_authentication_passwords"></a>[authentication\_passwords](#input\_authentication\_passwords) | Authentication Passwords for Redis User | `list(string)` | No | `[]` | `[]` |
| <a name="input_user_group_id"></a>[user\_group\_id](#input\_user\_group\_id) | User Group ID | `string` | Yes | `N/A` | `N/A` |
| <a name="input_use_default_elasticache_parameter_group"></a>[use\_default\_elasticache\_parameter\_group](#input\_use\_default\_elasticache\_parameter\_group) | Elasticache Use Default Parameter Group. If True then AWS Managed Default Parameter Group will be used to create a database instance. | `bool` | No | `false` | `false` |
| <a name="input_elasticache_parameter_group_name"></a>[elasticache\_parameter\_group\_name](#input\_elasticache\_parameter\_group\_name) | Elasticache Parameter Group Name | `string` | Yes | `N/A` | `N/A` |
| <a name="input_elasticache_engine_family"></a>[elasticache\_engine\_family](#input\_elasticache\_engine\_family) | Elasticache Engine Family | `string` | Yes | `N/A` | `N/A` |
| <a name="input_elasticache_parameter_details"></a>[elasticache\_parameter\_details](#input\_elasticache\_parameter\_details) | Elasticache Default Parameter Configuration List | `list(map(string))` | No | `[]` | `[]` |
| <a name="input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | List of Subnet IDs for Elasticache | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_tags"></a>[tags](#input\_tags) | Tags | `map(string)` | No | `{}` | `{}` |


## **Example Usage**

```hcl

module "elasticache" {
    source                                  = "tfe.axisb.com/ax-tfe/elasticache/aws"
    version                                 = "X.X.X"

    redis_cluster_type                      = "SHARD"
    engine                                  = "redis"
    engine_version                          = "7.0"
    node_type                               = "cache.r6g.xlarge"
    initial_cluster_num_cache_nodes         = 1 
    security_group_ids                      = ["sg-37efetffef36r3"]
    apply_immediately                       = false
    auto_minor_version_upgrade              = false
    cluster_single_az_availability_zone     = null
    memcached_az_mode                       = null
    ip_discovery                            = "ipv4"
    maintenance_window                      = null
    notification_topic_arn                  = null
    outpost_mode                            = null 
    preferred_outpost_arn                   = null 
    memcached_preferred_availability_zones  = 2
    transit_encryption_enabled              = false
    enable_final_snapshot                   = false 
    snapshot_arns                           = [ ] 
    snapshot_name                           = "example-snapshot"
    snapshot_retention_limit                = 0 
    snapshot_window                         = null
    replication_group_description           = "Redis Elasticache SHARD Group"
    num_cache_clusters                      = 2 
    num_node_groups                         = 1 
    replicas_per_node_group                 = 1 
    security_group_names                    = [ ] 
    at_rest_encryption_enabled              = false 
    redis_authentication_type               = "No Auth"
    kms_key_arn                             = null
    multi_az_enabled                        = false 
    enable_cluster_mode                     = false
    users_list                              = [ ] 
    authentication_mode_type                = "no-password-required"
    authentication_passwords                = [ ]
    user_group_id                           = null
    use_default_elasticache_parameter_group = false 
    elasticache_parameter_group_name        = "cache-params" 
    elasticache_engine_family               = "redis2.8" 
    elasticache_parameter_details           = {name = "activerehashing",value = "yes"}
    subnet_ids                              = ["subnet-89yeuh84y43e","subnet-1a5yeuh8y01b"]
    auth_token_password                     = null 
    port                                    = 6379
    data_tiering_enabled                    = false 
    automatic_failover_enabled              = false
    preferred_cache_cluster_azs             = []
    name_prefix                             = "Test-TFE-ECSHARD"

    tags                                    = {
                                               Name = "Test"
                                              }
}

```