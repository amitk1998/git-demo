# **AWS VPC Endpoint Module**

Terraform module to create VPC Endpoint on AWS

# **Description**
 
 This module is basically used to create VPC Endpoint on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `vpc_id`,`policy`,`subnet_ids`,`security_group_ids`,`vpc_endpoint_type`,`private_dns_enabled`,`service_name` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create"></a>[create](#input\_create) | Do you want to create the vpc endpoint ? | `bool` | No | true | `true` |
| <a name = "input_policy"></a>[policy](#input\_policy) | The policy of the  vpc endpoint | `string` | No | null | `"input policy that attch endpoint"` |
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | The id of the vpc in which to create the vpc endpoint | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_service_name"></a>[service\_name](#input\_service\_name) | The service_name of the vpc endpoint | `string` | No | null | `"com.amazonaws.ap-south-1.ec2"` |
| <a name = "input_vpc_endpoint_type"></a>[vpc\_endpoint\_type](#input\_vpc\_endpoint\_type) | The type of vpc endpoint.(e.g , 'Gateway','Interface') | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_private_dns_enabled"></a>[private\_dns\_enabled](#input\_private\_dns\_enabled) | Indicate wether private dns is enabled for the VPC endpoint | `bool` | No | false | `false` |
| <a name = "input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | list of security_group_ids to associate with vpc endpoints | `list(string)` | No | [ ] | `["sg-0y3yy4du1eu8ay"]` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | list of subnet_ids to associate with  vpc endpoints | `list(string)` | No | [ ] | `["subnet-2yheu3yy2jsb0c","subnet-01yheu2yy2jsb5c"]` |
| <a name = "input_route_table_ids"></a>[route\_table\_ids](#input\_route\_table\_ids) | list of  route_table_ids to associate with  vpc endpoints | `list(string)` | No | [ ] | `["rtb-0h3eh8o7e8u24u2"]` |
| <a name = "input_auto_accept"></a>[auto\_accept](#input\_auto\_accept) | Whether the VPC endpoint should be automatically accepted | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

locals {
    endpoint_full_access_policy = jsonencode({
        "Statement": [
            {
                "Effect": "Deny",
                "Principal": "*",
                "Action": "*",
                "Resource": "*",
                "Condition": {
                  "StringNotEquals": {
                    "aws:SourceVpc": "vpc-0sg3yt1gsy5s0gc"
                  }
                }
            }
        ]
    })
}

module "vpc_endpoints" {
  source              = "tfe.axisb.com/ax-tfe/vpcendpoint/aws"
  version             = "X.X.X"

  create              = true
  policy              = local.endpoint_full_access_policy
  vpc_id              = "vpc-0sg3yt1gsy5s0gc"
  subnet_ids          = ["subnet-2yheu3yy2jsb0c","subnet-01yheu2yy2jsb5c"]
  security_group_ids  = ["sg-0y3yy4du1eu8ay"]
  service_name        = "com.amazonaws.ap-south-1.ec2"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true
  auto_accept         = true

  tags                = {
                         Name = "Test"
                        } 

}

```