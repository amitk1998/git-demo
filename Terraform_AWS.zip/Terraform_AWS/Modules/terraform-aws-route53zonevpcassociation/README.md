# **AWS Route53DNSResolverVPCAssociation Module**

Terraform module to create Route53DNSResolverVPCAssociation on AWS

# **Description**
 
 This module is basically used to create Route53DNSResolverVPCAssociation on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS 

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | Vpc Id to be associated to the Hosted Zones | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_remote_zone_ids"></a>[remote\_zone\_ids](#input\_remote\_zone\_ids) | Vpc Id to be associated to the Remote Hosted Zones | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_region"></a>[region](#input\_region) | Region where the Vpc is created | `string` | No | null | `"ap-south-1"` |

## **Example Usage**

```hcl

module "eventbridge" {
  source                       = "tfe.axisb.com/ax-tfe/route53zonevpcassociation/aws"
  version                      = "X.X.X"

  vpc_id                       = "vpc-25fhdjh76hbshgs"
  remote_zone_ids              = [ ]
  region                       = "ap-south-1"

  
  tags                         = {
                                  Name = "Test"
                                  }

}

```