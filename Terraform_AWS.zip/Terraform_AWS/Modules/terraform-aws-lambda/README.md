# **AWS Lambda Module**

Terraform module to create Lambda Function on AWS

# **Description**
 
 This module is basically used to create Lambda Function on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `function_name`,`lambda_role_arn`,`kms_key_arn`,
 `desciption`,`s3_existing_package`,`package_type`,`runtime`,`handler`,`kms_key_arn` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_function_name"></a>[function\_name](#input\_function\_name) | Lambda Function Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_description"></a>[description](#input\_description) | Lambda Function description | `string` | No | null | `"lambda function descrption"` |
| <a name = "input_filename"></a>[filename](#input\_filename) | File name consist the zip code | `string` | No | null | `"example-file"` |
| <a name = "input_source_code_hash"></a>[source\_code\_hash](#input\_source\_code\_hash) | source code | `string` | No | null | `"enter your source code"` |
| <a name = "input_lambda_role_arn"></a>[lambda\_role\_arn](#input\_lambda\_role\_arn) | Lambda Function Role Arn | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_package_type"></a>[package\_type](#input\_package\_type) | Lambda Function Package type | `string` | No | "Zip" | `"Zip"` |
| <a name = "input_handler"></a>[handler](#input\_handler) | Lambda Function Handler Name | `string` | No | null | `"index.test"` |
| <a name = "input_memory_size"></a>[memory\_size](#input\_memory\_size) | Lambda Function Memory Size | `number` | No | 128 | `128` |
| <a name = "input_reserved_concurrent_executions"></a>[reserved\_concurrent\_executions](#input\_reserved\_concurrent\_executions) | Lambda Function Reserved Concurrent Executions | `number` | No | 0 | `0` |
| <a name = "input_runtime"></a>[runtime](#input\_runtime) | Lambda Function Runtime | `string` | No | null | `nodejs18.x` |
| <a name = "input_layers"></a>[layers](#input\_layers) | Lambda Function Layers | `list(string)` | No | [ ] | `["example-layers"]` |
| <a name = "input_timeout"></a>[timeout](#input\_timeout) | Lambda Function timeout | `number` | No | 3 | `3` |
| <a name = "input_publish"></a>[publish](#input\_publish) | Whether to publish creation/change of Lambda Function as a new version | `bool` | No | false | `false` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | Lambda Function Kms Key Arn | `string` | No | null | `"input your kms key arn here"` |
| <a name = "input_"></a>[](#input\_) | Lambda Function Kms Key Arn | `string` | No | null | `` |
| <a name = "input_s3_existing_package"></a>[s3_existing_package](#input\_s3_existing_package) | S3 bucket object with bucket, id and version pointing to an existing zip file | `map(string)` | No | { } | `{ "input s3_bucket or image uri" }` |
| <a name = "input_architectures"></a>[architectures](#input\_architectures) | Lambda Function Architectures | `list(string)` | No | [ ] | `["x86_64"]` |
| <a name = "input_ephemeral_storage_size"></a>[ephemeral\_storage\_size](#input\_ephemeral\_storage\_size) | Lambda Function Ephemeral Storage | `number` | No | null | `"input desired size here"` |
| <a name = "input_image_config"></a>[image\_config](#input\_image\_config) | Lambda Function Image Config | <pre><code>list(object({<br> command            = optional(list(string), [])<br> entry_point        = optional(list(string), [])<br> working_directory  = optional(string, null)<br> }))</code></pre> | No | null | `"input desired image configuration"` |
| <a name = "input_image_uri"></a>[image\_uri](#input\_image\_uri) | Lambda Function Image uri | `string` | No | null | `"input desired  ecr image containing uri here"` |
| <a name = "input_environment_variables"></a>[environment\_variables](#input\_environment\_variables) | Lambda Function Environment Variables | `map(string)` | No | null | `"input desired environment variables here"` |
| <a name = "input_dead_letter_target_arn"></a>[dead\_letter\_target\_arn](#input\_dead\_letter\_target\_arn) | Lambda Function Dead Letter Target Arn | `string` | No | null | `"input your dead letter target arn"` |
| <a name = "input_tracing_mode"></a>[tracing\_mode](#input\_tracing\_mode) | Lambda Function Tracing Mode | `string` | No | null | `"Active"` |
| <a name = "input_vpc_subnet_ids"></a>[vpc_subnet_ids](#input\_vpc\_subnet\_ids) | Lambda Function Subnet Ids | `list(string)` | No | null | `["subnet-367gvvdmghe384","subnet-10arvdmghe092"]` |
| <a name = "input_vpc_security_group_ids"></a>[vpc\_security\_group\_ids](#input\_vpc\_security\_group\_ids) | Lambda Function Security Group Ids | `list(string)` | No | null | `["sg-0eidhdqrtfpi2"]` |
| <a name = "input_file_system_local_mount_path"></a>[file\_system\_local\_mount\_path](#input\_file\_system\_local\_mount\_path) | Lambda Function file system path of local mount | `string` | No | null | `"input your file system path"` |
| <a name = "input_file_system_arn"></a>[file\_system\_arn](#input\_file\_system\_arn) | Lambda Function file system arn | `string` | No | null | `"input your file system arn here"` |
| <a name = "input_enable_code_signing_config"></a>[enable\_code\_signing\_config](#input\_enable\_code\_signing\_config) | Enable Code Signing Config for Lambda Function | `bool` | No | false | `false` |
| <a name = "input_enable_snap_start"></a>[enable\_snap\_start](#input\_enable\_snap\_start) | Enable Snap Start for Lambda Function | `bool` | No | false | `false` |
| <a name = "input_signing_profile_version_arns"></a>[signing\_profile\_version\_arns](#input\_signing\_profile\_version\_arns) | Lambda Function Signing Profile Version Arns | `list(string)` | No | [ ] | `["input list of signing profile version arns"]` |
| <a name = "input_untrusted_artifact_on_deployment"></a>[untrusted\_artifact\_on\_deployment](#input\_untrusted\_artifact\_on\_deployment) | Lambda Function Untrusted Artifact on Deployment | `string` | No | null | `"input untrusted lambda artifact"` |
| <a name = "input_code_signing_config_description"></a>[code\_signing\_config\_description](#input\_code\_signing\_config\_description) | Lambda Function Code Signing Config Description | `string` | No | null | `"input code signing config description"` |
| <a name = "input_create_alias"></a>[create\_alias](#input\_create\_alias) | Whether to create an alias of Lambda Function | `bool` | No | false | `false` |
| <a name = "input_alias_name"></a>[alias\_name](#input\_alias\_name) | Lambda Function Alias Name | `string` | No | null | `"example-alias"` |
| <a name = "input_alias_description"></a>[alias\_description](#input\_alias\_description) | Lambda Function Description | `string` | No | null | `"function description"` |
| <a name = "input_function_version"></a>[function\_version](#input\_function\_version) | Lambda Function Version for alias | `number` | No | null | `1` |
| <a name = "input_enable_routing_config"></a>[enable\_routing\_config](#input\_enable\_routing\_config) | Whether to Enable Routing Config for Lambda Function | `bool` | No | false | `false` |
| <a name = "input_additional_version_weights"></a>[additional\_version\_weights](#input\_additional\_version\_weights) | Lambda Function Additional Version Weights | `string` | No | null | `"input additional version weights"` |
| <a name = "input_provisioned_concurrent_executions"></a>[provisioned\_concurrent\_executions](#input\_provisioned\_concurrent\_executions) | Lambda Function Provisioned Concurrent Executions | `number` | Yes | `N/A` | `N/A` |
| <a name = "input_maximum_event_age_in_seconds"></a>[maximum\_event\_age\_in\_seconds](#input\_maximum\_event\_age\_in\_seconds) | Lambda Function Maximum Event Age in Seconds | `number` | No | null | `300` |
| <a name = "input_maximum_retry_attempts"></a>[maximum\_retry\_attempts](#input\_maximum\_retry\_attempts) | Lambda Function Maximum Retry Attempts | `number` | No | null | `3` |
| <a name = "input_destination_on_failure"></a>[destination\_on\_failure](#input\_destination\_on\_failure) | Lambda Function Destination Arn on Failure | `string` | No | null | `"input your destination arn"` |
| <a name = "input_destination_on_success"></a>[destination\_on\_success](#input\_destination\_on\_success) | Lambda Function Destination Arn on Success | `string` | No | null | `"input your desired destination"` |
| <a name = "input_create_lambda_function_url"></a>[create\_lambda\_function\_url](#input\_create\_lambda\_function\_url) | Whether to Create Lambda Function URL | `bool` | No | false | `false` |
| <a name = "input_authorization_type"></a>[authorization\_type](#input\_authorization\_type) | Type of Lambda Function URL Authorization | `string` | No | "NONE" | `"NONE"` |
| <a name = "input_invoke_mode"></a>[invoke\_mode](#input\_invoke\_mode) | Lambda Function URL Invoke Mode | `string` | No | "BUFFERED" | `"BUFFERED"` |
| <a name = "input_cors"></a>[cors](#input\_cors) | Lambda Function CORS Settings | <pre><code>list(object({<br> allow_credentials = optional(bool,false)<br> allow_headers     = optional(list(string),[])<br> allow_methods     = optional(list(string),[])<br> allow_origins     = optional(list(string),[])<br> expose_headers    = optional(list(string),[])<br> max_age           = optional(number,null) <br>}))</code></pre> | No | null | <pre><code>[<br>  {<br> allow_credentials = true<br> allow_headers     = ["date","keep-alive"]<br> allow_methods     = ["*"]<br> allow_origins     = ["*"]<br> expose_headers    = ["keep-alive","date"]<br> max_age           = 86400<br> }  <br>]</code></pre> |
| <a name = "input_allowed_triggers"></a>[allowed\_triggers](#input\_allowed\_triggers) | Map of allowed triggers to create Lambda Function Permissions | <pre><code>list(map(object({<br> statement_id       = optional(string,null)<br> action             = optional(string,"lambda:InvokeFunction")<br> principal          = optional(string,null)<br> principal_org_id   = optional(string,null)<br> source_arn         = optional(string,null)<br> source_account     = optional(string,null)<br> event_source_token = optional(string,null)<br> })))</code></pre> | No | null | <pre><code>[<br> {<br> "allow_triggers_details" = {<br> statement_id = "AllowExecutionFromCloudWatch"<br> action             = "lambda:InvokeFunction"<br> principal        = "event.amazonaws.com"<br> }<br>  }<br> ]</code></pre> |
| <a name = "input_add_lambda_permissions"></a>[add\_lambda\_permissions](#input\_add\_lambda\_permissions) | Whether to Add Lambda Function Permissions | `bool` | No | false | `false` |
| <a name = "input_create_layer"></a>[create\_layer](#input\_create\_layer) | Whether to Create Lambda Function Layer | `bool` | No | false | `false` |
| <a name = "input_layer_name"></a>[layer\_name](#input\_layer\_name) | Lambda Function layer Name | `string` | No | null | `"example-layer"` |
| <a name = "input_layer_description"></a>[layer_description](#input\_layer_description) | Lambda Function layer Description | `string` | No | null | `"example-description"` |
| <a name = "input_license_info"></a>[license\_info](#input\_license\_info) | Lambda Function Layer license info | `string` | No | null | `"example-info"` |
| <a name = "input_compatible_runtimes"></a>[compatible\_runtimes](#input\_compatible\_runtimes) | Lambda Function Layer Compatible Runtimes | `list(string)` | No | [ ] | `["nodejs16.x"]` |
| <a name = "input_compatible_architectures"></a>[compatible\_architectures](#input\_compatible\_architectures) | Lambda Function Layer Compatible Architectures | `list(string)` | No | [ ] | `["x86_64"]` |
| <a name = "input_layer_skip_destroy"></a>[layer\_skip\_destroy](#input\_layer\_skip\_destroy) | Lambda Function layer Skip Destroy | `bool` | No | false | `false` |
| <a name = "input_layer_version_permission"></a>[layer\_version\_permission](#input\_layer\_version\_permission) | Lambda Function URL Invoke Mode | `map(string)` | No | { } | `{"input desired permission here"}` |
| <a name = "input_enable_layer_permissions"></a>[enable\_layer\_permissions](#input\_enable\_layer\_permissions) | Wherther to enable layerd permmission or not | `bool` | No | false | `false` |
| <a name = "input_enable_event_invoke_config"></a>[enable\_event\_invoke\_config](#input\_enable\_event\_invoke\_config) | Whether to enable event invoke config or not | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "lambda" {
  source               = "tfe.axisb.com/ax-tfe/lambda/aws"
  version              = "X.X.X"

  function_name        = "test_lambda_poc_fun"
  lambda_role_arn      = "arn:aws:lambda:ap-south-1:1234567890:function:test_lambda_poc_fun"
  description          = "Test-Lambda-Function-Poc-597"
  s3_existing_package  = { bucket = "tfe-axe-poc-s3" key = "index.zip" object_version = null }
  package_type         = "Zip"
  runtime              = "nodejs18.x"
  handler              = "index.handler"
  publish              = true
  kms_key_arn          = "arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  provisioned_concurrent_executions = 1

  tags                  = {
                           Name = "Test"
                          }
}

```