# **AWS Security Groups Module**

Terraform module to create Security Groups on AWS

# **Description**
 
 This module is basically used to create Security Groups on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like .

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_security_group_rule_prefix"></a>[security\_group\_rule\_prefix](#input\_security\_group\_rule\_prefix) | list of ingress rule for the security group | <pre><code>list(object({<br> description = optional(string)<br> type      = string<br> from_port = number<br> to_port   = number<br> protocol  = string<br> prefix_list_ids = list(string)<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Description"<br> type      = "ingress"<br> from_port = 0<br> to_port   = 65535<br> protocol  = "tcp"<br> prefix_list_ids = ["pl-0c52f3d800caec59f"]<br> }<br>]</code></pre> |
| <a name = "input_security_group_rule_self"></a>[security\_group\_rule\_self](#input\_security\_group\_rule\_self) | list of ingress rule for the security group | <pre><code>list(object({<br> description = optional(string)<br> type      = string<br> from_port = number<br> to_port   = number<br> protocol  = string<br> self = bool<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Rule Self Description"<br> type      = "ingress"<br> from_port = 30<br> to_port   = 90<br> protocol  = "tcp"<br> self = true<br> }<br> ]</code></pre> |
| <a name = "input_source_security_group"></a>[source\_security\_group](#input\_source\_security\_group) | list of ingress rule for the security group | <pre><code>list(object({<br> description = optional(string)<br> type      = string<br> from_port = number<br> to_port   = number<br> protocol  = string<br> source_security_group_id = string<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Rule Self Description"<br> type      = "ingress"<br> from_port = 30<br> to_port   = 90<br> protocol  = "tcp"<br> source_security_group_id = "sg-389yeuihuiy389ey8"<br> }<br> ]</code></pre> |
| <a name = "input_custom_ingress_rules_for_source_security_group"></a>[custom\_ingress\_rules\_for\_source\_security\_group](#input\_custom\_ingress\_rules\_for\_source\_security\_group) | List of Ingress Rules (Source Security Group) for the Security Group | <pre><code>list(object({<br> description = optional(string)<br> from_port = number<br> to_port   = number<br> protocol  = string<br> source_security_group_id = string<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Rule Self Description"<br> from_port = 30<br> to_port   = 90<br> protocol  = "tcp"<br> source_security_group_id = "sg-389yeuihuiy389ey8"<br> }<br> ]</code></pre> |
| <a name = "input_custom_egress_rules_for_source_security_group"></a>[custom\_egress\_rules\_for\_source\_security\_group](#input\_custom\_egress\_rules\_for\_source\_security\_group) | List of Egress Rules (Source Security Group) for the Security Group | <pre><code>list(object({<br> description = optional(string)<br> from_port = number<br> to_port   = number<br> protocol  = string<br> source_security_group_id = string<br> }))</code></pre> | Yes | `N/A` |<pre><code>[<br> {<br> description = "Security Group Rule Self Description"<br> from_port = 0<br> to_port   = 0<br> protocol  = "-1"<br> source_security_group_id = "sg-389yeuihuiy389ey8"<br> }<br> ]</code></pre> |
| <a name = "input_ipv4_cidr_block_rules"></a>[ipv4\_cidr\_block\_rules](#input\_ipv4\_cidr\_block\_rules) | list of ingress rule for the security group | <pre><code>list(object({<br> description = optional(string)<br> type      = string<br> from_port = number<br> to_port   = number<br> protocol  = string<br> cidr_blocks = list(string)<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Description"<br> type      = "ingress"<br> from_port = 0<br> to_port   = 65535<br> protocol  = "tcp"<br> cidr_blocks = ["0.0.0.0/0"]<br> }<br>]</code></pre> |
| <a name = "input_ipv6_cidr_block_rules"></a>[ipv6\_cidr\_block\_rules](#input\_ipv6\_cidr\_block\_rules) | list of ingress rule for the security group | <pre><code>list(object({<br> description = optional(string)<br> type      = string<br> from_port = number<br> to_port   = number<br> protocol  = string<br> ipv6_cidr_blocks = list(string)<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> description = "Security Group Description"<br> type      = "ingress"<br> from_port = 0<br> to_port   = 65535<br> protocol  = "tcp"<br> ipv6_cidr_blocks = ["2001:db8::/64"]<br> }<br>]</code></pre> |
| <a name = "input_name"></a>[name](#input\_name) | The Name of the security group | `string` | No | null | `"sg"` |
| <a name = "input_description"></a>[description](#input\_description) | The description of the security group | `string` | No | null | `"sg-description"` |
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | The id of the vpc where the security group will be created | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_existing_security_group_id"></a>[existing\_security\_group\_id](#input\_existing\_security\_group\_id) | existing_security_group_id | `string` | No | null | `"sg-37ydhhuyy3u7yeh"` |
| <a name = "input_attach_security_group"></a>[attach\_security\_group](#input\_attach\_security\_group) | Attach Security Group Id | `bool` | No | false | `false` |
| <a name = "input_is_default_security_group"></a>[is\_default\_security\_group](#input\_is\_default\_security\_group) | Is Default Security Group | `bool` | No | false | `false` |
| <a name = "input_default_security_group_name"></a>[default\_security\_group\_name](#input\_default\_security\_group\_name) | The Name of the default security group | `string` | No | null | `null` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "sg" {
    source                     = "tfe.axisb.com/ax-tfe/securitygroup/aws"
    version                    = "1.0.0"

    name                       = "SECURITY-SERVICE-SG"
    description                = "Security Group Description" 
    vpc_id                     = "vpc-383u48y4hu4h44jh"

    ipv4_cidr_block_rules      = [
         {
            type                        = "egress"
            from_port                   = 0
            to_port                     = 0
            protocol                    = "-1"
            cidr_blocks                 = ["0.0.0.0/0"]
            description                 = "Security Group Description" 
        },
    ]

    source_security_group     = [
        {
            type                        = "ingress"
            from_port                   = 9443
            to_port                     = 9443
            protocol                    = "tcp"
            source_security_group_id    = "sg-389yeuihuiy389ey8"
            description                 = "Security Group Description"   
        }
    ]
 
  tags                        = {
                                 Name = "Test"
                                }

}

```