# **AWS Route53DNSResolverVPCAttachment Module**

Terraform module to create Route53DNSResolverVPCAttachment on AWS

# **Description**
 
 This module is basically used to create Route53DNSResolverVPCAttachment on Amazon Web Services(AWS).
 It requires only `type` attribute in order to be created on AWS.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_type"></a>[type](#input\_type) | List of resolver rule associations | <pre><code>list(object({<br> vpc_id           = string<br> resolver_rule_id = string<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> vpc_id           = "vpc-37eyu4yghg74d"<br> resolver_rule_id = "rslvr-37yehu333uhuhe"<br> }<br>]</code></pre> |

## **Example Usage**

```hcl

module "eventbridge" {
  source                       = "tfe.axisb.com/ax-tfe/route53dnsresolverattachment/aws"
  version                      = "X.X.X"

  type                         = [{
                                   vpc_id           = "vpc-37eyu4yghg74d"
                                   resolver_rule_id = "rslvr-37yehu333uhuhe"
                                 }]
  
  tags                         = {
                                  Name = "Test"
                                  }

}

```