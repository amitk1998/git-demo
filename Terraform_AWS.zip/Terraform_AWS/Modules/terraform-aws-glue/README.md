# **AWS  Glue Module**

Terraform module to create Glue on AWS

# **Description**
 
 This module is basically used to  create Glue on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `catalog_database_name`,`catalog_database_description`,`enable_glue_data_catalog_encryption_settings`,`connection_password_encryption`,`encryption_at_rest`,`enable_glue_security_configuration`,`security_configuration_name`,`cloudwatch_encryption`,`job_bookmarks_encryption`,`s3_encryption`,`connection_name`,`connection_properties`,`USERNAME`,`PASSWORD`,`crawler_name`,`crawler_description`,`database_name`,`role`,`schedule`,`dynamodb_target`,`worker_type`,`role_arn`,`command` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_catalog_database_name"></a>[catalog\_database\_name](#input\_catalog\_database\_name) | Glue catalog database name. The acceptable characters are lowercase letters, numbers, and the underscore character. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_catalog_database_description"></a>[catalog\_database\_description](#input\_catalog\_database\_description) | Glue catalog database description. | `string` | No | null | `"glue database through terraform"` |
| <a name="input_create_table_default_permission"></a>[create\_table\_default\_permission](#input\_create\_table\_default\_permission) | Creates a set of default permissions on the table for principals. | <pre><code>object({<br> permissions = optional(list(string))<br> data_lake_principal_identifier = optional(string)<br> })</code></pre> | No | null | `null` |
| <a name="input_location_uri"></a>[location\_uri](#input\_location\_uri) | Location of the database (for example, an HDFS path). | `string` | No | null | `null` |
| <a name="input_parameters"></a>[parameters](#input\_parameters) | Map of key-value pairs that define parameters and properties of the database. | `map(string)` | No | null | `null` |
| <a name="input_target_database"></a>[target\_database](#input\_target\_database) | Configuration block for a target database for resource linking. | <pre><code>object({<br> catalog_id    = string<br> database_name = string<br> })</code></pre> | No | null | `null` |
| <a name="input_crawler_name"></a>[crawler\_name](#input\_crawler\_name) | Glue crawler name. If not provided, the name will be generated from the context. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_crawler_description"></a>[crawler\_description](#input\_crawler\_description) | Glue crawler description. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_database_name"></a>[database\_name](#input\_database\_name) | Glue catalog database. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_role"></a>[role](#input\_role) | The IAM role friendly name (including path without leading slash), or ARN of an IAM role, used by the crawler to access other resources. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_schedule"></a>[schedule](#input\_schedule) | A cron expression for the schedule. | `string` | No | null | `null` |
| <a name="input_classifiers"></a>[classifiers](#input\_classifiers) | List of custom classifiers. By default, all AWS classifiers are included in a crawl, but these custom classifiers always override the default classifiers for a given classification. | `list(string)` | No | null | `"cron(0 0 * * ? *)"` |
| <a name="input_configuration"></a>[configuration](#input\_configuration) | JSON string of configuration information. | `string` | No | null | `null` |
| <a name="input_jdbc_target"></a>[jdbc\_target](#input\_jdbc\_target) | List of nested JBDC target arguments. | <pre><code>list(object({<br> connection_name = string<br> path            = string<br> exclusions      = optional(list(string))<br> }))</code></pre> | No | null | `null` |
| <a name="input_dynamodb_target"></a>[dynamodb\_target](#input\_dynamodb\_target) | List of nested DynamoDB target arguments. | <pre><code>list(object({<br> path      = string<br> scan_all  = optional(bool)<br> scan_rate = optional(number)<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> path      = "tfedynamotsable"<br> scan_all  = false<br> scan_rate = null<br> }<br>]</code></pre> |
| <a name="input_s3_target"></a>[s3\_target](#input\_s3\_target) | List of nested Amazon S3 target arguments. | <pre><code>list(object({<br> path                = string<br> connection_name     = string<br> exclusions          = optional(list(string))<br> sample_size         = optional(number)<br> event_queue_arn     = optional(string)<br> dlq_event_queue_arn = optional(string)<br> }))</code></pre> | No | null | `null` |
| <a name="input_mongodb_target"></a>[mongodb\_target](#input\_mongodb\_target) | List of nested MongoDB target arguments. | <pre><code>list(object({<br> connection_name = string<br> path            = string<br> scan_all        = optional(bool)<br> }))</code></pre> | No | null | `null` |
| <a name="input_catalog_target"></a>[catalog\_target](#input\_catalog\_target) | List of nested Glue catalog target arguments. | <pre><code>list(object({<br> database_name = string<br> tables        = list(string)<br> }))</code></pre> | No | null | `null` |
| <a name="input_delta_target"></a>[delta_target](#input\_delta\_target) | List of nested Delta target arguments. | <pre><code>list(object({<br> connection_name = optional(string)<br> delta_tables    = list(string)<br> write_manifest  = bool<br> }))</code></pre> | No | null | `null` |
| <a name="input_table_prefix"></a>[table\_prefix](#input\_table\_prefix) | The table prefix used for catalog tables that are created. | `string` | No | null | `"example-prefix"` |
| <a name="input_security_configuration"></a>[security\_configuration](#input\_security\_configuration) | The name of Security Configuration to be used by the crawler. | `string` | No | null | `null` |
| <a name="input_schema_change_policy"></a>[schema\_change\_policy](#input\_schema\_change\_policy) | Policy for the crawler's update and deletion behavior. | <pre><code>object({<br> delete_behavior = string<br> update_behavior = string<br> })</code></pre> | No | null | `null` |
| <a name="input_lineage_configuration"></a>[lineage\_configuration](#input\_lineage\_configuration) | Specifies data lineage configuration settings for the crawler. | <pre><code>object({<br> crawler_lineage_settings = string<br> })</code></pre> | No | null | `null` |
| <a name="input_recrawl_policy"></a>[recrawl\_policy](#input\_recrawl\_policy) | A policy that specifies whether to crawl the entire dataset again, or to crawl only folders that were added since the last crawler run. | <pre><code>object({<br> recrawl_behavior = string<br> })</code></pre> | No | null | `null` |
| <a name="input_catalog_id"></a>[catalog\_id](#input\_catalog\_id) | ID of the Glue Data Catalog | `string` | No | null | `null` |
| <a name="input_connection_name"></a>[connection\_name](#input\_connection\_name) | Connection name. If not provided, the name will be generated from the context. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_connection_description"></a>[connection\_description](#input\_connection\_description) | Connection description. | `string` | No | null | `"Connection Description"` |
| <a name="input_connection_type"></a>[connection\_type](#input\_connection\_type) | The type of the connection. Supported are: JDBC, MONGODB, KAFKA, and NETWORK. Defaults to JBDC. | `string` | No | `"JDBC"` | `"JDBC"` |
| <a name="input_connection_properties"></a>[connection\_properties](#input\_connection\_properties) | Map of connection properties. | `map(string)` | Yes | `N/A` | `N/A` |
| <a name="input_match_criteria"></a>[match\_criteria](#input\_match\_criteria) | A list of criteria that can be used in selecting this connection. | `list(string)` | No | null | `null` |
| <a name="input_physical_connection_requirements"></a>[physical\_connection\_requirements](#input\_physical\_connection\_requirements) | Physical connection requirements, such as VPC and SecurityGroup. | <pre><code>object({<br> availability_zone = string<br> security_group_id_list = list(string)<br> subnet_id = string<br> })</code></pre> | No | null | `null` |
| <a name="input_enable_glue_data_catalog_encryption_settings"></a>[enable\_glue\_data\_catalog\_encryption\_settings](#input\_enable\_glue\_data\_catalog\_encryption\_settings) | Enable or disable Glue Data Catalog encryption settings. | `bool` | No | false | `false` |
| <a name="input_enable_glue_security_configuration"></a>[enable\_glue\_security\_configuration](#input\_enable\_glue\_security\_configuration) | Enable or disable Glue Security Configuration. | `bool` | No | false | `false` |
| <a name="input_connection_password_encryption"></a>[connection\_password\_encryption](#input\_connection\_password\_encryption) | Configuration for encrypting connection passwords in the Glue Data Catalog. | <pre><code>object({<br> aws_kms_key                  = optional(string)<br> return_connection_password_encrypted = optional(bool)<br> })</code></pre> | No | { } | <pre><code>{<br> aws_kms_key                  = "arn:aws:kms:ap-south-1:695850308044:key/0136f743-da0a-4162-9bbb-518dad99193e"<br> return_connection_password_encrypted = true<br> }</code></pre> |
| <a name="input_encryption_at_rest"></a>[encryption\_at\_rest](#input\_encryption\_at\_rest) | Configuration for encryption at rest in the Glue Data Catalog. | <pre><code>object({<br> catalog_encryption_mode = optional(string)<br> aws_kms_key            = optional(string)<br> })</code></pre> | No | { } | <pre><code>{<br> catalog_encryption_mode = "SSE-KMS-KEY"<br> aws_kms_key            = "arn:aws:kms:ap-south-1:123456789:key/   0136f743-da0a-4162-9bbb-518dad99193e"<br> }</code></pre> |
| <a name="input_security_configuration_name"></a>[security\_configuration\_name](#input\_security\_configuration\_name) | The name of the Glue Security Configuration. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_cloudwatch_encryption"></a>[cloudwatch\_encryption](#input\_cloudwatch\_encryption) | Configuration for encrypting CloudWatch logs in the Glue Data Catalog. | <pre><code>object({<br> cloudwatch_encryption_mode = optional(string)<br> aws_kms_key                = optional(string)<br> })</code></pre> | Yes | `N/A` | <pre><code>{<br> cloudwatch_encryption_mode = "SSE-KMS"<br> aws_kms_key                = "arn:aws:kms:ap-south-1:123456789:key/   0136f743-da0a-4162-9bbb-518dad99193e"<br> }</code></pre> |
| <a name="input_job_bookmarks_encryption"></a>[job\_bookmarks\_encryption](#input\_job\_bookmarks\_encryption) | Configuration for encrypting job bookmarks in the Glue Data Catalog. | <pre><code>object({<br> job_bookmarks_encryption_mode = optional(string)<br> aws_kms_key                  = optional(string)<br> })</code></pre> | Yes | `N/A` | <pre><code>{<br> job_bookmarks_encryption_mode = "CSE-KMS"<br> aws_kms_key                  = "arn:aws:kms:ap-south-1:123456789:key/0136f743-da0a-4162-9bbb-518dad99193e"<br> }</code></pre> |
| <a name="input_s3_encryption"></a>[s3\_encryption](#input\_s3\_encryption) | Configuration for encrypting S3 data in the Glue Data Catalog. | <pre><code>object({<br> aws_kms_key          = optional(string)<br> s3_encryption_mode   = optional(string)<br> })</code></pre> | Yes | `N/A` | <pre><code>{<br> aws_kms_key          = "SSE-KMS"<br> s3_encryption_mode   = "arn:aws:kms:ap-south-1:123456789:key/0136f743-da0a-4162-9bbb-518dad99193e"<br> }</code></pre> |
| <a name="input_job_name"></a>[job\_name](#input\_job\_name) | Glue job name. If not provided, the name will be generated from the context. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_job_description"></a>[job\_description](#input\_job\_description) | Glue job description. | `string` | No | null | `null` |
| <a name="input_role_arn"></a>[role\_arn](#input\_role\_arn) | The ARN of the IAM role associated with this job. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_connections"></a>[connections](#input\_connections) | The list of connections used for this job. | `list(string)` | No | null | `null` |
| <a name="input_glue_version"></a>[glue\_version](#input\_glue\_version) | The version of Glue to use. | `string` | No | null | `null` |
| <a name="input_default_arguments"></a>[default\_arguments](#input\_default\_arguments) | The map of default arguments for the job. You can specify arguments here that your own job-execution script consumes, as well as arguments that AWS Glue itself consumes. | `map(string)` | No | null | `null` |
| <a name="input_non_overridable_arguments"></a>[non\_overridable\_arguments](#input\_non\_overridable\_arguments) | Non-overridable arguments for this job, specified as name-value pairs. | `map(string)` | No | null | `null` |
| <a name="input_timeout"></a>[timeout](#input\_timeout) | The job timeout in minutes. The default is 2880 minutes (48 hours) for `glueetl` and `pythonshell` jobs, and `null` (unlimited) for `gluestreaming` jobs. | `number` | No | `2880` | `2880` |
| <a name="input_max_capacity"></a>[max\_capacity](#input\_max\_capacity) | The maximum number of AWS Glue data processing units (DPUs) that can be allocated when the job runs. Required when `pythonshell` is set, accept either 0.0625 or 1.0. Use `number\_of\_workers` and `worker\_type` arguments instead with `glue\_version` 2.0 and above. | `number` | No | null | `null` |
| <a name="input_max_retries"></a>[max\_retries](#input\_max\_retries) | The maximum number of times to retry the job if it fails. | `number` | No | null | `null` |
| <a name="input_worker_type"></a>[worker\_type](#input\_worker\_type) | The type of predefined worker that is allocated when a job runs. Accepts a value of `Standard`, `G.1X`, or `G.2X`. | `string` | No | null | `null` |
| <a name="input_number_of_workers"></a>[number\_of\_workers](#input\_number\_of\_workers) | The number of workers of a defined `worker\_type` that are allocated when a job runs. | `number` | No | null | `null` |
| <a name="input_command"></a>[command](#input\_command) | Object containing job command details. | <pre><code>object({<br>name            = optional(string)<br> python_version  = optional(string)<br> script_location = string<br> })</code></pre> | Yes | `N/A` | `N/A` |
| <a name="input_execution_property_max_concurrent_runs"></a>[execution\_property\_max\_concurrent\_runs](#input\_execution\_property\_max\_concurrent\_runs) | Execution property for the max concurrent run of the job. | `number` | No | null | `null` |
| <a name="input_notification_property_notify_delay_after"></a>[notification\_property\_notify\_delay\_after](#input\_notification\_property\_notify\_delay\_after) | Notification property for notify delay after of the job. | `number` | No | null | `null` |
| <a name="input_glue_classifier_name"></a>[glue\_classifier\_name](#input\_glue\_classifier\_name) | Name of the Glue Classifier | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_classifier_csv_classifier"></a>[glue\_classifier\_csv\_classifier](#input\_glue\_classifier\_csv\_classifier) | CSV Classifier configuration | <pre><code>list(object({<br> allow_single_column        = optional(bool)<br> contains_header            = optional(bool)<br> custom_datatype_configured = optional(bool)<br> custom_datatypes           = optional(map(string))<br> delimiter                  = optional(string)<br> disable_value_trimming     = optional(bool)<br> header                     = optional(list(string))<br> quote_symbol               = optional(string)<br> }))</code></pre> | No | [ ] | <pre><code>{<br> allow_single_column        = false<br> contains_header            = "PRESENT"<br> custom_datatype_configured = null<br> custom_datatypes           = {}<br> delimiter                  = ","<br> disable_value_trimming     = false<br> header                     = ["example1","example2"]<br> quote_symbol               = "'"<br> }</code></pre> |
| <a name="input_glue_classifier_grok_classifier"></a>[glue\_classifier\_grok\_classifier](#input\_glue\_classifier\_grok\_classifier) | Grok Classifier configuration | <pre><code>list(object({<br> classification  = string<br> custom_patterns = optional(map(string))<br> grok_pattern    = string<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> classification  = "example"<br> custom_patterns = {}<br> grok_pattern    = "example"<br> }<br>]</code></pre> |
| <a name="input_glue_classifier_json_classifier"></a>[glue\_classifier\_json\_classifier](#input\_glue\_classifier\_json\_classifier) | JSON Classifier configuration | <pre><code>list(object({<br> json_path = string<br> }))</code></pre> | No | [ ] | <pre><code>list(object({<br> json_path = "example"<br> }))</code></pre> |
| <a name="input_glue_classifier_xml_classifier"></a>[glue\_classifier\_xml\_classifier](#input\_glue\_classifier\_xml\_classifier) | XML Classifier configuration | <pre><code>list(object({<br> classification = string<br> row_tag        = string<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> classification = "example"<br> row_tag        = "example"<br> }<br>]</code></pre> |
| <a name="input_glue_workflow_name"></a>[glue\_workflow\_name](#input\_glue\_workflow\_name) | Name of the Glue Workflow | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_workflow_description"></a>[glue\_workflow\_description](#input\_glue\_workflow\_description) | Description of the Glue Workflow | `string` | No | null | `null` |
| <a name="input_glue_workflow_default_run_properties"></a>[glue\_workflow\_default\_run\_properties](#input\_glue\_workflow\_default\_run\_properties) | Default run properties for the Glue Workflow | `map(string)` | No | { } | `{}` |
| <a name="input_glue_workflow_max_concurrent_runs"></a>[glue\_workflow\_max\_concurrent\_runs](#input\_glue\_workflow\_max\_concurrent\_runs) | Maximum concurrent runs for the Glue Workflow | `number` | No | 1 | `1` |
| <a name="input_glue_schema_name"></a>[glue\_schema\_name](#input\_glue\_schema\_name) | The name of the AWS Glue Schema. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_schema_registry_arn"></a>[glue\_schema\_registry\_arn](#input\_glue\_schema\_registry\_arn) | The Amazon Resource Name (ARN) of the Glue Schema Registry that contains the schema. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_schema_data_format"></a>[glue\_schema\_data\_format](#input\_glue\_schema\_data\_format) | The data format of the schema. Valid values: AVRO, JSON, ORC, or PARQUET. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_schema_compatibility"></a>[glue\_schema\_compatibility](#input\_glue\_schema\_compatibility) | The compatibility mode of the schema. Valid values: NONE, DISABLED, BACKWARD, FORWARD, FULL, or FULL\_ALL. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_schema_schema_definition"></a>[glue\_schema\_schema\_definition](#input\_glue\_schema\_schema\_definition) | The definition of the schema in the specified format. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_schema_description"></a>[glue\_schema\_description](#input\_glue\_schema\_description) | Description of the AWS Glue Schema. | `string` | No | null | `null` |
| <a name="input_glue_registry_name"></a>[glue\_registry\_name](#input\_glue\_registry\_name) | The name of the AWS Glue Data Catalog Registry. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_glue_registry_description"></a>[glue\_registry\_description](#input\_glue\_registry\_description) | Description of the AWS Glue Data Catalog Registry. | `string` | No | null | `null` |
| <a name="input_catalog_table_name"></a>[catalog\_table\_name](#input\_catalog\_table\_name) | Name of the table. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_catalog_table_description"></a>[catalog\_table\_description](#input\_catalog\_table\_description) | Description of the table. | `string` | No | null | `null` |
| <a name="input_table_catalog_id"></a>[table\_catalog\_id](#input\_table\_catalog\_id) | ID of the Glue Catalog and database to create the table in. If omitted, this defaults to the AWS Account ID plus the database name. | `string` | No | null | `null` |
| <a name="input_owner"></a>[owner](#input\_owner) | Owner of the table. | `string` | No | null | `null` |
| <a name="input_table_parameters"></a>[table\_parameters](#input\_table\_parameters) | Properties associated with this table, as a map of key-value pairs. | `map(string)` | No | { } | `{}` |
| <a name="input_partition_index"></a>[partition\_index](#input\_partition\_index) | Configuration block for a maximum of 3 partition indexes. | <pre><code>object({<br> index_name = string<br> keys       = list(string)<br> })</code></pre> | No | null | `null` |
| <a name="input_partition_keys"></a>[partition\_keys](#input\_partition\_keys) | Configuration block of columns by which the table is partitioned. Only primitive types are supported as partition keys. | `map(any)` | No | { } | `{}` |
| <a name="input_retention"></a>[retention](#input\_retention) | Retention time for the table. | `number` | No | null | `null` |
| <a name="input_table_type"></a>[table\_type](#input\_table\_type) | Type of this table (`EXTERNAL\_TABLE`, `VIRTUAL\_VIEW`, etc.). While optional, some Athena DDL queries such as `ALTER TABLE` and `SHOW CREATE TABLE` will fail if this argument is empty. | `string` | No | `null` | `null` |
| <a name="input_target_table"></a>[target\_table](#input\_target\_table) | Configuration block of a target table for resource linking. | <pre><code>object({<br> catalog_id    = string<br> database_name = string<br> name          = string<br> })</code></pre> | No | null | `null` |
| <a name="input_view\_expanded\_text"></a>[view\_expanded\_text](#input\_view\_expanded\_text) | If the table is a view, the expanded text of the view; otherwise null. | `string` | No | null | `null` |
| <a name="input_view\_original\_text"></a>[view\_original\_text](#input\_view\_original\_text) | If the table is a view, the original text of the view; otherwise null. | `string` | No | null | `null` |
| <a name="input_storage\_descriptor"></a>[storage\_descriptor](#input\_storage\_descriptor) | Configuration block for information about the physical storage of this table. | `any` | No | null | `null` |
| <a name="input_tags"></a>[tags](#input\_tags) | A map of key-value pairs used as tags for the Glue Resource. | `map(string)` | No | { } | `{}` |


## **Example Usage**

```hcl

module "glue" {
  source                                       = "tfe.axisb.com/ax-tfe/glue/aws"
  version                                      = "X.X.X"
  
  catalog_database_name                        = "tfe_glue_database"
  catalog_database_description                 = "glue database through terraform"
  enable_glue_data_catalog_encryption_settings = true
  connection_password_encryption               = {
                                                  aws_kms_key                          = "arn:aws:kms:ap-south-1:695850308044:key/0136f743-da0a-4162-9bbb-518dad99193e"
                                                  return_connection_password_encrypted = true
                                                 }
  encryption_at_rest                           = {
                                                  catalog_encryption_mode        =  "SSE-KMS"
                                                  aws_kms_key                    = "arn:aws:kms:ap-south-1:695850308044:key/   0136f743-da0a-4162-9bbb-518dad99193e"
                                                 }
  enable_glue_security_configuration          = true
  security_configuration_name                 = "security-configuration-name"
  cloudwatch_encryption                       = {
                                                 cloudwatch_encryption_mode = "SSE-KMS"
                                                 aws_kms_key                = "arn:aws:kms:ap-south-1:695850308044:key/0136f743-da0a-4162-9bbb-518dad99193e"
                                                 }
  job_bookmarks_encryption                    = {
                                                 job_bookmarks_encryption_mode = "CSE-KMS"  
                                                 aws_kms_key                   = "arn:aws:kms:ap-south-1:695850308044:key/0136f743-da0a-4162-9bbb-518dad99193e"
                                                 }
  s3_encryption                               = {
                                                 aws_kms_key         =  "arn:aws:kms:ap-south-1:695850308044:key/0136f743-da0a-4162-9bbb-518dad99193e"  
                                                 s3_encryption_mode  = "SSE-KMS"
                                                 }
  connection_name                             = "terraform_test_con"
  connection_properties                       = {
                                                 JDBC_CONNECTION_URL = "jdbc:mongodb://docdb-2023-10-12-09-59-29.cluster-cc5esrzderws.ap-south-1.docdb.amazonaws.com:27017/docdb-2023-10-12-09-59-29"
                                                 USERNAME            = "test_user"
                                                 PASSWORD            = "test1234"
                                                }
  crawler_name                                = "terraform_test_crawler"
  crawler_description                         = "Terraform DynamoDB Crawler"
  database_name                               = "testdbname"
  role                                        = "arn:aws:iam::1234567890:role/glue_Script_terraform"
  schedule                                    = "cron(0 0 * * ? *)"
  dynamodb_target                             = [
                                                 {
                                                  path      = "tfedynamotsable"    
                                                 }
                                                ]
  glue_registry_name                          = "registry_tfe_poc"
  glue_registry_description                   = "glue_registry  through terraform"
  glue_workflow_name                          = "glue_workflow-tfe"
  glue_workflow_description                   = "glue workflow through terraform" 
  glue_workflow_max_concurrent_runs           = 5
  job_name                                    = "terraform_srcript-job"
  job_description                             = "Glue Job Description"
  connections                                 = []
  default_arguments                           = {}
  non_overridable_arguments                   = {}
  glue_version                                = "2.0"
  timeout                                     = 60
  number_of_workers                           = 10
  worker_type                                 = "G.1X"
  max_capacity                                = 5
  role_arn                                    = "arn:aws:iam::1234567890:role/glue_Script_terraform"
  max_retries                                 = 3
  command                                     = {
                                                 name            = "glueetl"
                                                 python_version  = "3"
                                                 script_location = "s3://pythonscriptforterraform/pythons.py"
                                                 }
  notification_property_notify_delay_after    = 30 
  execution_property_max_concurrent_runs      = 5 
 }

```

```hcl

module "glue_schema" {
  source                                      = "tfe.axisb.com/ax-tfe/glue/aws"
  version                                     = "X.X.X"

  glue_schema_name                            = "tfe-schema-test"
  glue_schema_registry_arn                    = "arn:aws:glue:ap-south-1:1234567890:registry/registry_tfe_poc"  
  glue_schema_data_format                     = "AVRO"
  glue_schema_compatibility                   = "NONE"
  glue_schema_schema_definition               = "{\"type\": \"record\", \"name\": \"r1\", \"fields\": [ {\"name\": \"f1\", \"type\": \"int\"}, {\"name\": \"f2\", \"type\": \"string\"} ]}"
  glue_schema_description                     = "Schema Description"
}

```
 
```hcl

module "glue_connection" {
  source                                      = "tfe.axisb.com/ax-tfe/glue/aws"
  version                                     = "X.X.X"

  connection_name                             = "terraform_test_con"
  connection_properties                       = {
                                                JDBC_CONNECTION_URL    = "jdbc:mongodb://automation-docdb.cluster-ro-cyzukcc5tkm4.ap-south-1.docdbamazonaws.com/automation-docdb"
                                                USERNAME               = "test_user"
                                                PASSWORD               = "test1234"
                                                }
}

```