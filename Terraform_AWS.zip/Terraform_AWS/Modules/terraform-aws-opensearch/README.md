# **AWS Opensearch Module**

Terraform module to create Opensearch on AWS

# **Description**
 
 This module is basically used to create Opensearch on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `region`,`account_id`,`domain_name`,`cluster_version`,`auto_software_update_enabled`,`cluster_subnet_ids`,`cluster_sg_ids`,`data_node_instance_type`,`master_node_instance_type`,`warm_node_instance_type`,`cluster_index_slow_log_group_arn` etc. .

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_region"></a>[region](#input\_region) | AWS Region for your Infrastructure | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_account_id"></a>[account\_id](#input\_account\_id) | OpenSearch Domain Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_domain_name"></a>[domain\_name](#input\_domain\_name) | OpenSearch Domain Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_cluster_version"></a>[cluster\_version](#input\_cluster\_version) | OpenSearch Version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_multiaz_deployment_enabled"></a>[multiaz\_deployment\_enabled](#input\_multiaz\_deployment\_enabled) | OpenSearch MultiAZ Deployment Enabled | `bool` | No | true | `true` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | OpenSearch KMS Key ARN for Encryption At Rest | `string` | No | null | `"input kms key arn"` |
| <a name = "input_data_node_instance_type"></a>[data\_node\_instance\_type](#input\_data\_node\_instance\_type) | OpenSearch Data Node Instance Type | `string` | No | `"t3.small.search"` | `"t3.small.search"` |
| <a name = "input_data_node_instance_count"></a>[data\_node\_instance\_count](#input\_data\_node\_instance\_count) | OpenSearch Data Node Instance Count | `number` | No | 3 | `3` |
| <a name = "input_data_node_volume_type"></a>[data\_node\_volume\_type](#input\_data\_node\_volume\_type) | OpenSearch Data Node Volume Type | `string` | No | "gp3" | `"gp3"` |
| <a name = "input_master_node_instance_count"></a>[master\_node\_instance\_count](#input\_master\_node\_instance\_count) | OpenSearch Master Node Instance Count | `number` | No | 0 | `0` |
| <a name = "input_master_node_instance_type"></a>[master\_node\_instance\_type](#input\_master\_node\_instance\_type) | OpenSearch Master Node Instance Type | `string` | No | "t3.small.search" | `"t3.small.search"` |
| <a name = "input_warm_enabled"></a>[warm\_enabled](#input\_warm\_enabled) | OpenSearch Warm Node Enabled | `bool` | No | false | `false` |
| <a name = "input_warm_node_instance_type"></a>[warm\_node\_instance\_type](#input\_warm\_node\_instance\_type) | OpenSearch Warm Node Instance Types | `string` | No | "ultrawarm1.medium.search" | `"ultrawarm1.medium.search"` |
| <a name = "input_warm_node_instance_count"></a>[warm\_node\_instance\_count](#input\_warm\_node\_instance\_count) | OpenSearch Warm Node Instance Count | `number` | No | 7 | `7` |
| <a name = "input_warm_node_cold_storage_enabled"></a>[warm\_node\_cold\_storage\_enabled](#input\_warm\_node\_cold\_storage\_enabled) | OpenSearch Warm Node Cold Storage Enabled | `bool` | No | false | `false` |
| <a name = "input_data_node_volume_size"></a>[data\_node\_volume\_size](#input\_data\_node\_volume\_size) | OpenSearch EBS Volume Size | `number` | No | 20 | `20` |
| <a name = "input_data_node_volume_iops"></a>[data\_node\_volume\_iops](#input\data\_node\_volume\_iops) | OpenSearch EBS IOPS | `number` | No | 3000 | `3000` |
| <a name = "input_data_node_volume_throughput"></a>[data\_node\_volume\_throughput](#input\_data\_node\_volume\_throughput) | OpenSearch EBS Throughput | `number` | No | 125 | `125` |
| <a name = "input_cluster_subnet_ids"></a>[cluster\_subnet\_ids](#input\_cluster\_subnet\_ids) | OpenSearch Cluster Subnet IDs | `list(string)` | No | [ ] | `["subnet-08ehu3hu3d33u38u","subnet-2ehu0hu3d39u31u"]` |
| <a name = "input_cluster_sg_ids"></a>[cluster\_sg\_ids](#input\_cluster\_sg\_ids) | OpenSearch Cluster SG Ids | `list(string)` | No | [ ] | `["sg-83eh38333ij9e"]` |
| <a name = "input_cluster_index_slow_log_group_arn"></a>[cluster\_index\_slow\_log\_group\_arn](#input\_cluster\_index\_slow\_log\_group\_arn) | OpenSearch Cluster Index Slow Log Group ARN | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_cluster_search_slow_log_group_arn"></a>[cluster\_search\_slow\_log\_group\_arn](#input\_cluster\_search\_slow\_log\_group\_arn) | OpenSearch Cluster Search Slow Log Group ARN | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_cluster_audit_log_group_arn"></a>[cluster\_audit\_log\_group\_arn](#input\_cluster\_audit\_log\_group\_arn) | OpenSearch Cluster Error Log Group ARN | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_auto_software_update_enabled"></a>[auto\_software\_update\_enabled](#input\_auto\_software\_update\_enabled) | Is OpenSearch Cluster Auto Software Update Enabled | `bool` | No | true | `true` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "opensearch_cluster" {
  source                            = "tfe.axisb.com/ax-tfe/opensearch/aws"
  version                           = "X.X.X"

  region                            = "ap-south-1"
  account_id                        = "input your account id"
  domain_name                       = "input your domain name"
  cluster_version                   = "Elasticsearch_7.10"
  auto_software_update_enabled      = true
  multiaz_deployment_enabled        = true
  cluster_subnet_ids                = ["subnet-37yh3h3yyh3u3ueu38","subnet-12yh6h3yyh8u3ueu0"]
  cluster_sg_ids                    = ["sg-3iyt36teu737e84s"]
  kms_key_arn                       = "input kms key arn"
  data_node_instance_type           = "t3.small.search"
  data_node_instance_count          = 3
  data_node_volume_type             = "gp3"
  master_node_instance_count        = 0
  master_node_instance_type         = "t3.small.search"
  warm_enabled                      = false
  warm_node_instance_type           = "ultrawarm1.medium.search"
  warm_node_instance_count          = 10
  warm_node_cold_storage_enabled    = false
  data_node_volume_size             = 20
  data_node_volume_iops             = 3000
  data_node_volume_throughput       = 125
  cluster_index_slow_log_group_arn  = "input index log group arn"
  cluster_search_slow_log_group_arn = "input search log group arn"
  cluster_audit_log_group_arn       = "input audit log group arn"
  cluster_error_log_group_arn       = "input error log group arn"

  tags                              = {
                                       Name = "Test"
                                      }
}

```