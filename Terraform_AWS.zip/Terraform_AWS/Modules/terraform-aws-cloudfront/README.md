# **AWS Cloudfront Module**

Terraform module to create Cloudfront on AWS

# **Description**
 
 This module is basically used to create Cloudfront on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `description`,`enabled`,`enabled`,`http_version`,`price_class`,`cache_behaviors`,`function_associations`,`origin_specifications` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_description"></a>[description](#input\_description) | Cloudfront Distribution Description | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_aliases"></a>[aliases](#input\_aliases) | Cloudfront Distribution Aliases | `list(string)` | No | `null` | `["input aliases"]` |
| <a name = "input_enabled"></a>[enabled](#input\_enabled) | Cloudfront Distribution Enabled | `bool` | Yes | `N/A` | `N/A` |
| <a name = "input_default_root_object"></a>[default\_root\_object](#input\_default\_root\_object) | Cloudfront Distribution Default Root Object | `string` | No | `null` | `"input default root object"` |
| <a name = "input_http_version"></a>[http\_version](#input\_http\_version) | Cloudfront Distribution Maximum HTTP Version to support. Valid values are http1.1, http2, http2and3, or http3 | `string` | No | `"http1.1"` | `"http1.1"` |
| <a name = "input_price_class"></a>[price\_class](#input\_price\_class) | Cloudfront Distribution Price Class. Valid values are PriceClass_All, PriceClass_100 or PriceClass_200 | `string` | No | `"PriceClass_All"` | `"PriceClass_All"` |
| <a name = "input_waf_id"></a>[waf\_id](#input\_waf\_id) | Cloudfront Distribution WAF ID for Association | `string` | No | `"input waf id"` | `"input waf id"` |
| <a name = "input_enable_ipv6"></a>[enable\_ipv6](#input\_enable\_ipv6) | Cloudfront Distribution Enable IPV6 | `bool` | No | `null` | `null` |
| <a name = "input_enable_geo_restrictions"></a>[enable\_geo\_restrictions](#input\_enable\_geo\_restrictions) | Cloudfront Distribution Enable Geo Restriction | `bool` | No | `false` | `false` |
| <a name = "input_geo_restriction_list_type"></a>[geo\_restriction\_list\_type](#input\_geo\_restriction\_list\_type) | Cloudfront Distribution Geo Restriction Countries List Type if Restriction is enabled. Valid values are whitelist or blacklist | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_countries_list"></a>[countries_list](#input\_countries_list) | Cloudfront Distribution Countries List for Geo Restriction | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_acm_certificate_arn"></a>[acm\_certificate\_arn](#input\_acm\_certificate\_arn) | Cloudfront Distribution ACM Certificate ARN | `string` | No | `"specify cloudfront default certificate or iam_certificate_id"` | `"specify cloudfront default certificate or iam_certificate_id"` |
| <a name = "input_minimum_ssl_protocol_version"></a>[minimum\_ssl\_protocol\_version](#input\_minimum\_ssl\_protocol\_version) | Cloudfront Distribution Minimum SSL Protocal Version. Only applicable if using ACM Certificate | `string` | No | `"TLSv1"` | `"TLSv1"` |
| <a name = "input_enable_logging"></a>[enable\_logging](#input\_enable\_logging) | Cloudfront Distribution Enable Logging | `bool` | No | `false` | `false` |
| <a name = "input_logging_bucket_name"></a>[logging\_bucket\_name](#input\_logging\_bucket\_name) | Cloudfront Distribution Logging Bucket Name | `string` | No | `"example-bucket-597"` | `"example-bucket-597"` |
| <a name = "input_logging_bucket_prefix"></a>[logging\_bucket\_prefix](#input\_logging\_bucket\_prefix) | Cloudfront Distribution Logging Bucket Path Prefix | `string` | No | `null` | `"input logging bucket path prefix"` |
| <a name = "input_logging_include_cookies"></a>[logging\_include\_cookies](#input\_logging\_include\_cookies) | Cloudfront Distribution Include Cookies for Logging | `bool` | No | `false` | `false` |
| <a name = "input_custom_error_response_specifications"></a>[custom\_error\_response\_specifications](#input\_custom\_error\_response\_specifications) | Cloudfront Distribution Custom Error Response Sepcifications | <pre><code>list(object({<br> error_code = number<br> response_code = optional(number, null)<br> error_caching_min_ttl = optional(number, null)<br> response_page_path = optional(string, null)<br> }))</code></pre> | No | <pre><code>[<br> {<br> error_code = N/A<br> response_code = 404<br> error_caching_min_ttl = null<br> response_page_path = "/customr_404.html"<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> error_code = N/A<br> response_code = 404<br> error_caching_min_ttl = null<br> response_page_path = "/customr_404.html"<br> }<br> ]</code></pre> |
| <a name = "input_cache_behaviors"></a>[cache\_behaviors](#input\_cache\_behaviors) | Cloudfront Distribution Cache Behaviors (Includes Default Cache Behavior & Ordered Cache Behavior). Atleast 1 Item with Default Cache Behavior Specification is required | <pre><code>list(object({<br> is_default_cache_behavior 		= bool<br> origin_name						= string<br> enable_compression				= optional(bool, false)<br> viewer_protocol_policy			= string<br> allowed_methods					= list(string)<br> cached_methods					= list(string)<br> enable_smooth_streaming			= optional(bool, false)<br> cache_policy_name				= string<br> origin_request_policy_name		= optional(string, null)<br> response_headers_policy_name	= optional(string, null)<br> function_associations			= optional(list(object({<br> is_edge_function 	= bool<br> event_type			= string<br> arn					= string<br> include_body		= optional(bool, false)<br> })), [])<br> }))</code></pre> | No | <pre><code>[<br> {<br> is_default_cache_behavior 		= N/A<br> origin_name						= N/A<br> enable_compression				= false<br> viewer_protocol_policy			= N/A<br> allowed_methods					= N/A<br> cached_methods					= N/A<br> enable_smooth_streaming			= false<br> cache_policy_name				= N/A<br>  function_associations			= [<br> {<br> is_edge_function 	= true<br> event_type			= "viewer-request"<br> arn					= "arn:aws:lambda:us-east-1:123456789:function:cloudfront-test-lambda-function:1"<br> include_body		= true<br> }<br> ]<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> is_default_cache_behavior 		= N/A<br> origin_name						= N/A<br> enable_compression				= false<br> viewer_protocol_policy			= N/A<br> allowed_methods					= N/A<br> cached_methods					= N/A<br> enable_smooth_streaming			= false<br> cache_policy_name				= N/A<br>  function_associations			= [<br> {<br> is_edge_function 	= true<br> event_type			= "viewer-request"<br> arn					= "arn:aws:lambda:us-east-1:123456789:function:cloudfront-test-lambda-function:1"<br> include_body		= true<br> }<br> ]<br> }<br> ]</code></pre> |
| <a name = "input_signing_behavior"></a>[signing\_behavior](#input\_signing\_behavior) | Sign Behavior for Cloudfront  always,never and non-override | `string` | No | `"always"` | `"always"` |
| <a name = "input_origin_specifications"></a>[origin_specifications](#input\_origin_specifications) | Cloudfront Distribution Origin Specifications | `string` | No | <pre><code>list(object({<br> is_custom_origin 						= bool<br> name									= string<br> path									= optional(string, null)<br> domain_name								= string<br> connection_attempts						= optional(number, null)<br> connection_timeout						= optional(number, null)<br> custom_header							= optional(list(object({<br> name 	= string<br> value	= string<br> })), null)<br> enable_origin_shield					= optional(bool, false)<br> origin_shield_region					= optional(string, null)<br> custom_origin_http_port					= optional(number, null)<br> custom_origin_https_port				= optional(number, null)<br> custom_origin_origin_protocol_policy	= optional(string, null)<br> custom_origin_origin_ssl_protocols		= optional(list(string), null)<br> custom_origin_origin_keepalive_timeout	= optional(number, null)<br> custom_origin_origin_read_timeout		= optional(number, null)<br> }))</code></pre> | <pre><code>[<br> {<br> is_custom_origin 						= false<br> name									= N/A<br> path									= "input origin path"<br> domain_name								= N/A<br> connection_attempts						= 5<br> connection_timeout						= 30<br> custom_header							= [<br> {<br> name 	= N/A<br> value	= N/A<br> }<br> ]<br> enable_origin_shield					= false<br> origin_shield_region					= "input region"<br> custom_origin_http_port					= N/A<br> custom_origin_https_port				= N/A<br> custom_origin_origin_protocol_policy	= match-viewer<br> custom_origin_origin_ssl_protocols		= ["SSLv3"]<br> custom_origin_origin_keepalive_timeout	= 15<br> custom_origin_origin_read_timeout		= 20<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> is_custom_origin 						= false<br> name									= N/A<br> path									= "input origin path"<br> domain_name								= N/A<br> connection_attempts						= 5<br> connection_timeout						= 30<br> custom_header							= [<br> {<br> name 	= N/A<br> value	= N/A<br> }<br> ]<br> enable_origin_shield					= false<br> origin_shield_region					= "input region"<br> custom_origin_http_port					= N/A<br> custom_origin_https_port				= N/A<br> custom_origin_origin_protocol_policy	= match-viewer<br> custom_origin_origin_ssl_protocols		= ["SSLv3"]<br> custom_origin_origin_keepalive_timeout	= 15<br> custom_origin_origin_read_timeout		= 20<br> }<br> ]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "cloudfront" {
  source                    = "tfe.axisb.com/ax-tfe/cloudfront/aws"
  version                   = "X.X.X"
 
   description              = "CloudFront Description POC AXWS TEST"
   enabled                  = true 
   http_version             = "http1.1"
   enable_ipv6              = true 
   price_class              = "PriceClass_100"
   cache_behaviors          = [{
  is_default_cache_behavior = true
    allowed_methods         = ["GET","HEAD","OPTIONS","POST","PUT","DELETE","PATCH"]
    cached_methods          = ["GET","HEAD"]
    cache_policy_name       = "CachingOptimized"
    origin_name             = "S3Origin"
    target_origin_id        = "S3Origin"
    compress                = false
    viewer_protocol_policy  = "redirect-to-https"

    function_associations = [{
      is_edge_function      = true
      event_type            = "viewer-request"
      arn                   = "arn:aws:lambda:us-east-1:1234567890:function:cloudfront-test-lambda-function:1"
      include_body          = true
    }]
   }]

   origin_specifications    = [{
    is_custom_origin        = false
    name                    = "S3Origin"
    domain_name             = "domain.s3.amazonaws.com"
    origin_id               = "S3Origin"
   }]
  
    tags                    = {
                               Name = "Test"
                              }
}


```