# **AWS Amplify Module**

Terraform module to create Amplify on AWS

# **Description**
 
 This module is basically used to create Amplify on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `existing_amplify_app_id`,`name`,`enable_auto_branch_creation`,`app_backend_environments`,`app_branches` etc.

 # **Variable Defination**


| <a name = "input_name"></a>[name](#input\_name) | Existing Amplify App Name | `string` | No | null | `[]` |



| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_existing_amplify_app_id"></a>[existing\_amplify\_app\_id](#input\_existing\_amplify\_app\_id) | Existing Amplify App Name | `string` | No | null | `"example-existing-amplify"` |
| <a name = "input_name"></a>[name](#input\_name) | Amplify App Name | `string` | No | null | `"example-amplify"` |
| <a name = "input_description"></a>[description](#input\_description) | Amplify App Description | `string` | No | null | `"Amplify App description"` |
| <a name = "input_repository"></a>[repository](#input\_repository) | Amplify App Repository | `string` | No | null | `"example-repository"` |
| <a name = "input_platform"></a>[platform](#input\_platform) | Amplify App Platform. Valid values are WEB or WEB_COMPUTE | `string` | No | null | `"input repository"` |
| <a name = "input_app_role_arn"></a>[app\_role\_arn](#input\_app\_role\_arn) | Amplify App Role ARN. Default Role will be created if not passed | `string` | No | null | `"input app role arn"` |
| <a name = "input_access_token"></a>[access\_token](#input\_access\_token) | Personal Access Token for a third-party source control system for Amplify App. This token is used to create a webhook and a read-only deploy key | `string` | No | null | `"input app access token"` |
| <a name = "input_oauth_token"></a>[oauth\_token](#input\_oauth\_token) | OAuth Token for a third-party source control system for Amplify App. This token is used to create a webhook and a read-only deploy key | `string` | No | null | `"input oauth token"` |
| <a name = "input_enable_basic_auth"></a>[enable\_basic\_auth](#input\_enable\_basic\_auth) | Enable Basic Authorization for Amplify App | `bool` | No | null | `"input basic authorization for your app"` |
| <a name = "input_basic_auth_credentials"></a>[basic\_auth\_credentials](#input\_basic\_auth\_credentials) | Amplify App Basic Auth Credentials | `string` | No | null | `"input basic auth credentials"` |
| <a name = "input_environment_variables"></a>[environment\_variables](#input\_environment\_variables) | Amplify App Environment Variables | `map(string)` | No | null | `{{name = "test_env"}}` |
| <a name = "input_build_specification"></a>[build\_specification](#input\_build\_specification) | Amplify App Build Specifications. Visit - https://docs.aws.amazon.com/amplify/latest/userguide/build-settings.html | `string` | No | null | `"input build specification here"` |
| <a name = "input_enable_auto_branch_creation"></a>[enable_auto_branch_creation](#input\_enable_auto_branch_creation) | Enable Automated Branch Creation for Amplify App | `bool` | No | null | `false` |
| <a name = "input_enable_auto_branch_build"></a>[enable\_auto\_branch\_build](#input\_enable\_auto\_branch\_build) | Enable Automated Building of branches for Amplify App | `bool` | No | null | `false` |
| <a name = "input_enable_branch_auto_deletion"></a>[enable\_branch\_auto\_deletion](#input\_enable\_branch\_auto\_deletion) | Enable Auto Deletion of Branch for Amplify App when a branch is deleted from the Git Repository | `bool` | No | null | `false` |
| <a name = "input_auto_branch_creation_patterns"></a>[auto\_branch\_creation\_patterns](#input\_auto\_branch\_creation\_patterns) | Automated Branch Creation Patterns | `list(string)` | No | null | `["input auto branch creation pattern"]` |
| <a name = "input_app_custom_rules"></a>[app_custom_rules](#input\_app_custom_rules) | Amplify App Custom Rules | <pre><code>list(object({<br> condition = optional(string, null)<br> source    = string<br> status    = optional(string, null)<br> target    = string<br> }))</code></pre> | No | [ ] | <pre><code>[<br>  {<br> source = ["/api/<*>"]<br> status    = "200"<br> target  = "https://api.example.com/api/<*>"<br>  }<br> ]</code></pre> |
| <a name = "input_app_auto_branch_creation_configurations"></a>[app\_auto\_branch\_creation\_configurations](#input\_app\_auto\_branch\_creation\_configurations) | Amplify App Auto Branch Creation Configuration | <pre><code>object({<br> basic_auth_credentials 			= optional(string, null)<br>  build_spec 						= optional(string, null)<br> enable_auto_build 				= optional(bool, null)<br> enable_basic_auth 				= optional(bool, null)<br> enable_performance_mode 		= optional(bool, null)<br> enable_pull_request_preview 	= optional(bool, null)<br> environment_variables 			= optional(map(string), null)<br> framework 						= optional(string, null)<br> stage 							= optional(string, null)<br> pull_request_environment_name 	= optional(string, null)<br> })</code></pre> | No | null | <pre><code>{<br> basic_auth_credentials 			= base64encode("username1:password1")<br> enable_auto_build 				= true<br> enable_basic_auth          = true<br> enable_performance_mode 		= true<br> enable_pull_request_preview 	= true<br> environment_variables 			= { "_CUSTOM_IMAGE_" = "node:16"}<br> stage 							= "DEVELOPMENT"<br> }</code></pre> |
| <a name = "input_app_backend_environments"></a>[app\_backend\_environments](#input\_app\_backend\_environments) | Amplify App Backend Environment | <pre><code>list(object({<br> name 					= string<br> deployment_artifacts	= string<br> stack_name    			= string<br> }))</code></pre> | No | null | <pre><code>[<br>  { name 					 = "apptestpoc"<br> deployment_artifacts	 = "amplify-test-poc-artifacts"<br> stack_name    	     = "amplify-app-test-poc-stack"<br> }<br>  ]</code></pre> |
| <a name = "input_app_branches"></a>[app\_branches](#input\_app\_branches) | Amplify App Branch Configuration | <pre><code>list(object({<br> name 							= string<br> display_name 					= optional(string, null)<br> description 					= optional(string, null)<br> enable_auto_build 				= optional(bool, null)<br> enable_basic_auth 				= optional(bool, null)<br> enable_notification 			= optional(bool, null)<br> enable_performance_mode 		= optional(bool, null)<br> enable_pull_request_preview		= optional(bool, null)<br> environment_variables 			= optional(map(string))<br> framework			 			= optional(string, null)<br> pull_request_environment_name	= optional(string, null)<br> basic_auth_credentials 			= optional(string, null)<br> stage 							= optional(string, null)<br> ttl 							= optional(number, null)<br> }))</code></pre> | No | null | <pre><code>[<br>  {<br> name 			         = "appbranch"<br> display_name            = "amplifytestpocdisplay"<br> description             = "Aws Amplify App Description Test Poc"<br> stage                   = "DEVELOPMENT"<br> }<br>  ]</code></pre> |
| <a name = "input_app_domains"></a>[app\_domains](#input\_app\_domains) | Amplify App Backend Domain Associations | <pre><code>list(object({<br> domain_name 				= string<br> enable_auto_sub_domain		= optional(bool, null)<br> wait_for_verification		= optional(bool, null)<br> sub_domain_conigurations	= optional(list(object({<br> branch_name = string<br> prefix		= string<br> })),[])<br> }))</code></pre> | No | [ ] | <pre><code>[{<br> domain_name 				= "example.com"<br> enable_auto_sub_domain		= false<br> wait_for_verification		= false<br> [{<br> branch_name = "dev"<br> prefix		= "example-prefix"<br> }]<br> }]</code></pre> |
| <a name = "input_app_webhooks"></a>[app\_webhooks](#input\_app\_webhooks) | Amplify App Webhooks | <pre><code>list(object({<br> branch_name	= string<br> description	= string<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> branch_name	= "dev"<br> description	= "web hook description"<br> }<br> ]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "amplify" {
  source                      = "tfe.axisb.com/ax-tfe/amplify/aws"
  version                     = "X.X.X"

  name                        = "test_poc_amplify"
  enable_auto_branch_creation = true
  app_backend_environments    = [{
		                          name 					 = "apptestpoc"
		                          deployment_artifacts	 = "amplify-test-poc-artifacts"
		                          stack_name    	     = "amplify-app-test-poc-stack" 
                                }]

 app_branches                = [{
                                 name 			         = "appbranch"
                                 display_name            = "amplifytestpocdisplay"
                                 description             = "Aws Amplify App Description Test Poc"
                                 stage                   = "DEVELOPMENT"
                               }]

  tags                      = {
                               Name = "Test"
                              }

}

```