# **AWS Datasyncloc Module**

Terraform module to create Datasyncloc on AWS

# **Description**
 
 This module is basically used to create Datasyncloc on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `location_type`,`s3_example_bucket_arn`,`subdirectory`,`s3_example_bucket_access_role_arn` etc.

# **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_subdirectory"></a>[subdirectory](#input\_subdirectory) | Subdirectory for the location resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_location_type"></a>[location\_type](#input\_location\_type) | Type of DataSync Location | `string` | Yes | `N/A` | `"locs3"` |
| <a name="input_s3_example_bucket_arn"></a>[s3\_example\_bucket\_arn](#input\_s3\_example\_bucket\_arn) | S3 Bucket ARN for the S3 location resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_s3_example_bucket_access_role_arn"></a>[s3\_example\_bucket\_access\_role\_arn](#input\_s3\_example\_bucket\_access\_role\_arn) | ARN of the IAM Role used to connect to the S3 Bucket | `string` | Yes | `N/A` | `N/A` |
| <a name="input_s3_example_storage_class"></a>[s3\_example\_storage\_class](#input\_s3\_example\_storage\_class) | S3 storage class for the S3 location resource | `string` | No | null | `null` |
| <a name="input_datasync_agent_arns"></a>[datasync\_agent\_arns](#input\_datasync\_agent\_arns) | A list of DataSync Agent ARNs with which this location will be associated | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_datasync_container_url"></a>[datasync\_container\_url](#input\_datasync\_container\_url) | The URL of the Azure Blob Storage container involved in your transfer | `string` | No | null | `null` |
| <a name="input_datasync_sas_token"></a>[datasync\_sas\_token](#input\_datasync\_sas\_token) | A SAS token that provides permissions to access your Azure Blob Storage | `string` | No | null | `null` |
| <a name="input_datasync_authentication_type"></a>[datasync\_authentication\_type](#input\_datasync\_authentication\_type) | The authentication method DataSync uses to access your Azure Blob Storage | `string` | Yes | `N/A` | `"SAS"` |
| <a name="input_datasync_access_tier"></a>[datasync\_access\_tier](#input\_datasync\_access\_tier) | The access tier that you want your objects or files transferred into | `string` | No | `"HOT"` | `"HOT"` |
| <a name="input_datasync_blob_type"></a>[datasync\_blob\_type](#input\_datasync\_blob\_type) | The type of blob that you want your objects or files to be when transferring them into Azure Blob Storage | `string` | No | `"BLOCK"` | `"BLOCK"` |
| <a name="input_datasync_sas_configuration_token"></a>[datasync\_sas\_configuration\_token](#input\_datasync\_sas\_configuration\_token) | The SAS token in the SAS configuration | `string` | Yes | `N/A` | `N/A` |
| <a name="input_efs_file_system_arn"></a>[efs\_file\_system\_arn](#input\_efs\_file\_system\_arn) | EFS File System ARN | `string` | Yes | `N/A` | `N/A` |
| <a name="input_access_point_arn"></a>[access\_point\_arn](#input\_access\_point\_arn) | Access Point ARN | `string` | No | null | `null` |
| <a name="input_file_system_access_role_arn"></a>[file\_system\_access\_role\_arn](#input\_file\_system\_access\_role\_arn) | File System Access Role ARN (Optional) | `string` | No | null | `null` |
| <a name="input_in_transit_encryption"></a>[in\_transit\_encryption](#input\_in\_transit\_encryption) | In Transit Encryption (Optional) | `string` | No | null | `null` |
| <a name="input_ec2_security_group_arns"></a>[ec2\_security\_group\_arns](#input\_ec2\_security\_group\_arns) | List of EC2 Security Group ARNs | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_ec2_subnet_arn"></a>[ec2\_subnet\_arn](#input\_ec2\_subnet\_arn) | EC2 Subnet ARN | `string` | Yes | `N/A` | `N/A` |
| <a name="input_fsx_filesystem_arn"></a>[fsx\_filesystem\_arn](#input\_fsx\_filesystem\_arn) | The ARN of the FSx for Lustre file system | `string` | Yes | `N/A` | `N/A` |
| <a name="input_security_group_arns"></a>[security\_group\_arns](#input\_security\_group\_arns) | The ARN of the security groups for the FSx for Lustre file system | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_storage_virtual_machine_arn"></a>[storage\_virtual\_machine\_arn](#input\_storage\_virtual\_machine\_arn) | FSx ONTAP Storage Virtual Machine ARN | `string` | Yes | `N/A` | `N/A` |
| <a name="input_smb_domain"></a>[smb\_domain](#input\_smb\_domain) | SMB Domain Name | `string` | No | null | `null` |
| <a name="input_mount_options_version"></a>[mount\_options\_version](#input\_mount\_options\_version) | SMB Mount Options | `string` | No | null | `null` |
| <a name="input_smb_mount_options_version"></a>[smb\_mount\_options\_version](#input\_smb\_mount\_options\_version) | SMB Mount Options | `string` | No | null | `"AUTOMATIC"` |
| <a name="input_smb_password"></a>[smb\_password](#input\_smb\_password) | SMB Password | `string` | Yes | `N/A` | `N/A` |
| <a name="input_smb_user"></a>[smb\_user](#input\_smb\_user) | SMB Username | `string` | Yes | `N/A` | `N/A` |
| <a name="input_mount_options_nfs_version"></a>[mount\_options\_nfs\_version](#input\_mount\_options\_nfs\_version) | NFS Mount Options version | `string` | No | `N/A` | `"AUTOMATIC"` |
| <a name="input_user"></a>[user](#input\_user) | User for FSx Windows File System | `string` | Yes | `N/A` | `N/A` |
| <a name="input_password"></a>[password](#input\_password) | Password for FSx Windows File System | `string` | Yes | `N/A` | `N/A` |
| <a name="input_domain"></a>[domain](#input\_domain) | Windows Domain Name | `string` | No | null | `null` |
| <a name="input_agent_arns"></a>[agent\_arns](#input\_agent\_arns) | List of DataSync Agent ARNs | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_authentication_type"></a>[authentication\_type](#input\_authentication\_type) | Authentication type | `string` | Yes | `N/A` | `"SIMPLE"` |
| <a name="input_simple_user"></a>[simple\_user](#input\_simple\_user) | Username for SIMPLE authentication | `string` | No | `null` | `"example"` |
| <a name="input_name_node_hostname"></a>[name\_node\_hostname](#input\_name\_node\_hostname) | Hostname of the NameNode | `string` | Yes | `N/A` | `N/A` |
| <a name="input_name_node_port"></a>[name\_node\_port](#input\_name\_node\_port) | Port of the NameNode | `number` | Yes | `N/A` | `N/A` |
| <a name="input_block_size"></a>[block\_size](#input\_block\_size) | Block size in bytes (e.g., 134217728 for 128 MiB) | `number` | No | null | `512` |
| <a name="input_replication_factor"></a>[replication\_factor](#input\_replication\_factor) | Replication factor for HDFS | `number` | No |nul | `null` |
| <a name="input_kerberos_keytab"></a>[kerberos\_keytab](#input\_kerberos\_keytab) | Path to the Kerberos keytab file | `string` | No |nul | `null` |
| <a name="input_kerberos_krb5_conf"></a>[kerberos\_krb5\_conf](#input\_kerberos\_krb5\_conf) | Path to the krb5.conf file | `string` | No |nul | `null` |
| <a name="input_kerberos_principal"></a>[kerberos\_principal](#input\_kerberos\_principal) | Kerberos principal | `string` | No | null | `null` |
| <a name="input_kms_key_provider_uri"></a>[kms\_key\_provider\_uri](#input\_kms\_key\_provider\_uri) | KMS key provider URI | `string` | No | null | `null` |
| <a name="input_qop_configuration"></a>[qop\_configuration](#input\_qop\_configuration) | QOP configuration for HDFS | <pre><code>object({<br> data_transfer_protection = string<br> rpc_protection   = string<br> })</code></pre> | No | null | `null` |
| <a name="input_nfs_example_server_hostname"></a>[nfs\_example\_server\_hostname](#input\_nfs\_example\_server\_hostname) | NFS server hostname for the first NFS resource | `string` | No | `null` | `"example-nsf-server"` |
| <a name="input_nfs_mount_options_version"></a>[nfs\_mount\_options\_version](#input\_nfs\_mount\_options\_version) | Mount options for the first NFS resource | `string` | No | `null` | `"AUTOMATIC"` |
| <a name="input_nfs_example_agent_arns"></a>[nfs\_example\_agent\_arns](#input\_nfs\_example\_agent\_arns) | Agent ARNs for the first NFS resource | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_object_storage_example_agent_arns"></a>[object\_storage\_example\_agent\_arns](#input\_object\_storage\_example\_agent\_arns) | Agent ARNs for the object storage resource | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_object_storage_example_server_hostname"></a>[object\_storage\_example\_server\_hostname](#input\_object\_storage\_example\_server\_hostname) | Server hostname for the object storage resource | `string` | No | null | `"object-server-hostname"` |
| <a name="input_object_storage_example_bucket_name"></a>[object\_storage\_example\_bucket\_name](#input\_object\_storage\_example\_bucket\_name) | Bucket name for the object storage resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_object_storage_example_access_key"></a>[object\_storage\_example\_access\_key](#input\_object\_storage\_example\_access\_key) | Access key for the object storage resource | `string` | No | null | `"input access key"` |
| <a name="input_object_storage_example_secret_key"></a>[object\_storage\_example\_secret\_key](#input\_object\_storage\_example\_secret\_key) | Secret key for the object storage resource | `string` | No | null | `"input secret key"` |
| <a name="input_object_storage_example_server_certificate"></a>[object\_storage\_example\_server\_certificate](#input\_object\_storage\_example\_server\_certificate) | Server certificate for the object storage resource (Optional) | `string` | No | null | `"input server certificate"` |
| <a name="input_object_storage_example_server_protocol"></a>[object\_storage\_example\_server\_protocol](#input\_object\_storage\_example\_server\_protocol) | Server protocol for the object storage resource (Optional) | `string` | No | null | `"http"` |
| <a name="input_object_storage_example_server_port"></a>[object\_storage\_example\_server\_port](#input\_object\_storage\_example\_server\_port) | Server port for the object storage resource (Optional) | `number` | No | null | `80` |
| <a name="input_smb_example_server_hostname"></a>[smb\_example\_server\_hostname](#input\_smb\_example\_server\_hostname) | Server hostname for the SMB location resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_smb_example_user"></a>[smb\_example\_user](#input\_smb\_example\_user) | User for the SMB location resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_smb_example_password"></a>[smb\_example\_password](#input\_smb\_example\_password) | Password for the SMB location resource | `string` | Yes | `N/A` | `N/A` |
| <a name="input_smb_example_agent_arns"></a>[smb\_example\_agent\_arns](#input\_smb\_example\_agent\_arns) | List of DataSync Agent ARNs for the SMB location resource | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_smb_example_domain"></a>[smb\_example\_domain](#input\_smb\_example\_domain) | Domain for the SMB location resource (Optional) | `string` | No | null | `null` |
| <a name="input_smb_example_mount_options_version"></a>[smb\_example\_mount\_options\_version](#input\_smb\_example\_mount\_options\_version) | Mount options for the SMB location resource | `string` | No | `"AUTOMATIC"` | `Optional: Replace with your desired SMB version (AUTOMATIC, SMB2, or SMB3)"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "datasyncloc" {
  source                            = "tfe.axisb.com/ax-tfe/datasyncloc/aws"
  version                           = "X.X.X"

  location_type                     = "locs3"
  s3_example_bucket_arn             = "arn:aws:s3:::tfe-axe-poc-s3"
  subdirectory                      = "/example/source"
  s3_example_bucket_access_role_arn = "arn:aws:iam::12345678912:role/service-role/AWSDataSyncS3BucketAccess-athenas3badli"
 
  tags                              = {
                                       Name = "Test"
                                      }

}

```