
# **AWS Subnet Module**

Terraform module to create Subnet on AWS

# **Description**
 
 This module is basically used to create and manage subnets on Amazon Web Services(AWS).
 It provides the flexibility to create new subnets with various configuration options like `VPC ID`,`CIDR Block` ,`Availabilityn Zone` or Optionally, you can associate `existing subnet` to VPC. For managing existing Subnet you can use `existing_subnet_id`.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_vpc_id"></a>[vpc\_id](#input\_vpc\_id) | The Existing VPC Id used for new Subnet or existing Subnet | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_existing_subnet_ids"></a>[existing\_subnet\_ids](#input\existing\_subnet\_ids) | The List of Existing Subnet Id used to associate with VPC | `list(string)` | No | null | `["subnet-006b5962d4288dc7a","subnet-7eb5862d4481dc80"]` |
| <a name = "input_subnet_details"></a>[subnet\_details](#input\_subnet\_details) | The List of subnet details including CIDR , availability_zone and tags | <pre><code>list(object({<br> cidr = string<br> availability_zone = string<br> tags = map(string)<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> cidr = "10.0.1.0/24",<br> availability_zone = "ap-south-1",<br> tags = { <br>  Name = "test" <br>   }<br> }<br>]</code></pre> |

## **Example Usage**

```hcl

module "subnet" {
  source         = "tfe.axisb.com/ax-tfe/subnets/aws"
  version        = "X.X.X"

  vpc_id         = "your existing vpc id comes here"
  subnet_details = [
        {
            cidr              = "10.0.1.0/24"
            availability_zone = "ap-south-1"
            tags = {
                      Name    = "Test"
                   }
        }
    ]

}

```