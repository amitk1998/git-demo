# **AWS S3 Module**

Terraform module to create S3 on AWS

# **Description**
 
 This module is basically used to create S3 on Amazon Web Services(AWS).
 It requires some attributes in order to be created on AWS like `bucket_name`,`account_id`,`object_ownership`,`bucket_allowed_headers`,`bucket_allowed_methods`,`bucket_allowed_origins`,`tiering_config`,`tiering_config_filter`,`logging_target_bucket_id`,`index_document`,`error_document`,`bucket_policy` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_account_id"></a>[account\_id](#input\_account\_id) | Account id | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_existing_bucket_name"></a>[existing\_bucket\_name](#input\_existing\_bucket\_name) | Existing Bucket Name | `string` | No | null | `"input existing bucket name"` |
| <a name = "input_bucket_name"></a>[bucket\_name](#input\_bucket\_name) | Bucket Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_object_ownership"></a>[object\_ownership](#input\_object\_ownership) | Bucket Object Ownership | `string` | No | "BucketOwnerEnforced" | `"BucketOwnerEnforced"` |
| <a name = "input_bucket_object_lock_enabled"></a>[bucket\_object\_lock\_enabled](#input\_bucket\_object\_lock\_enabled) | Bucket Object Lock Enabled | `bool` | No | false | `false` |
| <a name = "input_bucket_force_destroy"></a>[bucket\_force\_destroy](#input\_bucket\_force\_destroy) | Bucket Force Destroy | `bool` | No | false | `false` |
| <a name = "input_enable_bucket_accelerate_configuration"></a>[enable\_bucket\_accelerate\_configuration](#input\_enable\_bucket\_accelerate\_configuration) | Enable bucket accelerate configuration | `bool` | No | false | `false` |
| <a name = "input_bucket_allowed_headers"></a>[bucket\_allowed\_headers](#input\_bucket\_allowed\_headers) | Bucket allowed headers | `list(string)` | No | [ ] | `["*"]` |
| <a name = "input_bucket_allowed_methods"></a>[bucket\_allowed\_methods](#input\_bucket\_allowed\_methods) | Bucket allowed methods | `list(string)` | No | [ ] | `["GET","PUT","POST","DELETE","HEAD"]` |
| <a name = "input_bucket_allowed_origins"></a>[bucket\_allowed\_origins](#input\_bucket\_allowed\_origins) | Bucket allowed origins | `list(string)` | No | [ ] | `["https://example.com]` |
| <a name = "input_bucket_expose_headers"></a>[bucket\_expose\_headers](#input\_bucket\_expose\_headers) | Bucket expose headers | `list(string)` | No | [ ] | `["ETag"]` |
| <a name = "input_bucket_max_age_seconds"></a>[bucket\_max\_age\_seconds](#input\_bucket\_max\_age\_seconds) | Bucket max age seconds | `number` | No | null | `3000` |
| <a name = "input_enable_bucket_cors_config"></a>[enable\_bucket\_cors\_config](#input\_enable\_bucket\_cors\_config) | Enable Bucket CORS Configuration | `bool` | No | false | `false` |
| <a name = "input_enable_object_encryption"></a>[enable\_object\_encryption](#input\_enable\_object\_encryption) | Enable Bucket object encryption | `bool` | No | false | `false` |
| <a name = "input_enable_intelligent_tiering"></a>[enable\_intelligent\_tiering](#input\_enable\_intelligent\_tiering) | Enable Bucket Intelligent Tiering | `bool` | No | false | `false` |
| <a name = "input_tiering_config_name"></a>[tiering\_config\_name](#input\_tiering\_config\_name) | Tiering Configuration Name | `string` | No | null | `"example-config"` |
| <a name = "input_tiering_config_status"></a>[tiering_config_status](#input\_tiering_config_status) | Tiering Configuration Status | `bool` | No | false | `false` |
| <a name = "input_tiering_config"></a>[tiering\_config](#input\_tiering\_config) | Tiering Configuration Status | `bool` | No | false | `false` |
| <a name = "input_tiering_config"></a>[tiering\_config](#input\_tiering\_config) | Tiering Configuration | <pre><code>list(object({<br> access_tier = string<br> days = number<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> access_tier = ARCHIVE_ACCESS<br> days = 125<br> }<br>]</code></pre> |
| <a name = "input_tiering_config_filter"></a>[tiering\_config\_filter](#input\_tiering\_config\_filter) | Tiering Configuration Filter | <pre><code>list(object({<br> prefix = string<br> tags = map(string)<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> prefix = "documents/"<br> tags = {<br> <br> priority = "high"<br> class    = "blue"<br> }<br>}<br>]</code></pre> |
| <a name = "input_enable_logging"></a>[enable\_logging](#input\_enable\_logging) | Enable bucket Logging | `bool` | No | false | `false` |
| <a name = "input_logging_target_bucket_id"></a>[logging\_target\_bucket\_id](#input\_logging\_target\_bucket\_id) | logging Target Bucket Id | `string` | No | null | `"exmple-bucket-597"` |
| <a name = "input_logging_target_bucket_prefix"></a>[logging/_target/_bucket/_prefix](#input\_logging/_target/_bucket/_prefix) | logging Target Bucket prefix | `string` | No | null | `"log/"` |
| <a name = "input_expected_bucket_owner_account_id"></a>[expected\_bucket\_owner\_account\_id](#input\_expected\_bucket\_owner\_account\_id) | Account Id of the Target Bucket | `string` | No | null | `"input bucket owner account id"` |
| <a name = "input_enable_bucket_versioning"></a>[enable\_bucket\_versioning](#input\_enable\_bucket\_versioning) | Enable bucket versioning | `bool` | No | true | `true` |
| <a name = "input_enable_website_configuration"></a>[enable\_website\_configuration](#input\_enable\_website\_configuration) | Enable website configuration | `bool` | No | false | `false` |
| <a name = "input_attach_policy"></a>[attach\_policy](#input\_attach\_policy) | Attach policy to the Bucket | `bool` | No | false | `false` |
| <a name = "input_bucket_policy"></a>[bucket\_policy](#input\_bucket\_policy) | Bucket Policy in json | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_object_lock_rule"></a>[object\_lock\_rule](#input\_object\_lock\_rule) | Bucket Object Lock Rule | <pre><code>object({<br> mode = string<br> days = number<br> years = number<br> })</code></pre> | No | null | <pre><code>{<br> mode = "GOVERNANCE"<br> days = 1<br> years = 1<br> }</code></pre> |
| <a name = "input_object_lock_token"></a>[object\_lock\_token](#input\_object\_lock\_token) | Bucket Object Lock token | `string` | No | null | `"input token"` |
| <a name = "input_metric_config"></a>[metric\_config](#input\_metric\_config) | Metric Configuration | `any` | No | { } | `{ }` |
| <a name = "input_analytics_config_name"></a>[analytics\_config\_name](#input\_analytics\_config\_name) | Enable Bucket Analytics Configuration | `bool` | No | false | `false` |
| <a name = "input_analytics_config_filter"></a>[analytics\_config\_filter](#input\_analytics\_config\_filter) | Bucket Analytics Configuration Filter | <pre><code>object({<br> prefix = string<br> tags = map(string)<br> })</code></pre> | No | { } | <pre><code>{<br> prefix = "documents/"<br> tags = {<br> <br> priority = "high"<br> class    = "blue"<br> }<br>}</code></pre> |
| <a name = "input_storage_class_analysis"></a>[storage\_class\_analysis](#input\_storage\_class\_analysis) | Bucket Analytics Configuration Storage class analysis | <pre><code>object({<br> bucket_arn = string<br> account_id = number<br> format = string<br> prefix = string<br> })</code></pre> | No | { } | <pre><code>{<br> bucket_arn = "arn:aws:s3:::example-bucket-597"<br> account_id = 1234567890<br> format = null<br> prefix = "example_prefix"<br> }</code></pre> |
| <a name = "input_lifecycle_rules_name"></a>[lifecycle\_rules\_name](#input\_lifecycle\_rules\_name) | Lifecycle rule name of Bucket | `string` | No | null | `"example-rule"` |
| <a name = "input_lifecycle_rules_status"></a>[lifecycle\_rules\_status](#input\_lifecycle\_rules\_status) | lifecycle rule status of Bucket | `bool` | No | false | `false` |
| <a name = "input_enable_lifecycle_rules"></a>[enable\_lifecycle\_rules](#input\_enable\_lifecycle\_rules) | Enable lifecycle rule | `bool` | No | false | `false` |
| <a name = "input_lifecycle_rules"></a>[lifecycle\_rules](#input\_lifecycle\_rules) | Bucket Inventory filter | <pre><code>object({<br> id = string<br> status_enabled = bool<br> })</code></pre> | No | <pre><code>object({<br> id = null<br> status_enabled = true<br> })</code></pre> | <pre><code>object({<br> id = "log"<br> status_enabled = true<br> })</code></pre> |
| <a name = "input_days_after_initiation"></a>[days\_after\_initiation](#input\_days\_after\_initiation) | Abort incomplete multipart upload days | `number` | No | 1 | `1` |
| <a name = "input_lifecycle_expiration"></a>[lifecycle\_expiration](#input\_lifecycle\_expiration) | Lifecycle expiration | <pre><code>object({<br> date = string<br> days = number<br> expired_object_delete_marker = bool<br> })</code></pre> | No | <pre><code>{<br> date = null<br> days = null<br> expired_object_delete_marker = false<br> }</code></pre> | <pre><code>{<br> date = ""<br> days = 90<br> expired_object_delete_marker = false<br> }</code></pre> |
| <a name = "input_lifecycle_transition"></a>[lifecycle\_transition](#input\_lifecycle\_transition) | Lifecycle transition | <pre><code>object({<br> date = string<br> days = number<br> storage_class = string<br> })</code></pre> | No | { } | <pre><code>{<br> date = nulll<br> days = 60<br> storage_class = "GLACIER"<br> }</code></pre> |
| <a name = "input_lifecycle_noncurrent_version_expiration"></a>[lifecycle\_noncurrent\_version\_expiration](#input\_lifecycle\_noncurrent\_version\_expiration) | Lifecycle noncurrent version expiration | <pre><code>object({<br> newer_noncurrent_versions = number<br> noncurrent_days = number<br> })</code></pre> | No | { } | <pre><code>{<br> newer_noncurrent_versions = null<br> noncurrent_days = null<br> }</code></pre> |
| <a name = "input_lifecycle_noncurrent_version_transition"></a>[lifecycle\_noncurrent\_version\_transition](#input\_lifecycle\_noncurrent\_version\_transition) | Lifecycle noncurrent version transition | <pre><code>object({<br> newer_noncurrent_versions = number<br> noncurrent_days = number<br> storage_class = string<br> })</code></pre> | No | { } | <pre><code>{<br> newer_noncurrent_versions = null<br> noncurrent_days = 30<br> storage_class = "GLACIER"<br> }</code></pre> |
| <a name = "input_lifecycle_rules_filter"></a>[lifecycle\_rules\_filter](#input\_lifecycle\_rules\_filter) | Bucket lifecycle rules filter | <pre><code>object({<br> object_size_greater_than = number<br> object_size_less_than = number<br> prefix = string<br> })</code></pre> | No | { } | <pre><code>{<br> object_size_greater_than = 1<br> object_size_less_than = 3<br> tags = { }<br> }</code></pre> |
| <a name = "input_index_document"></a>[index\_document](#input\_index\_document) | Website Configuration index document | `string` | No | "index.html" | `"index.html"` |
| <a name = "input_error_document"></a>[error\_document](#input\_error\_document) | Website Configuration error document | `string` | No | "error.html" | `"error.html"` |
| <a name = "input_routing_rules"></a>[routing\_rules](#input\_routing\_rules) | Website Configuration routing rules | `string` | No | null | `"input routing rules"` |
| <a name = "input_enable_bucket_inventory_encryption"></a>[enable\_bucket\_inventory\_encryption](#input\_enable\_bucket\_inventory\_encryption) | Enable bucket inventory encryption | `bool` | No | false | `false` |
| <a name = "input_bucket_tags"></a>[bucket\_tags](#input\_bucket\_tags) | Bucket tags | `map(string)` | No | { } | `{ }` |
| <a name = "input_redirect_all_requests_to"></a>[redirect\_all\_requests\_to](#input\_redirect\_all\_requests\_to) | Redirection Policy for Website Configuration | <pre><code>object({<br> host_name = string<br>  protocol = string<br> })</code></pre> | No | { } | <pre><code>{<br> host_name = "input host name"<br>  protocol = "http"<br> }</code></pre> |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | KMS Key ARN | `string` | No | null | `"input kms key arn"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "s3" {
  source                                 = "tfe.axisb.com/ax-tfe/s3/aws"
  version                                = "X.X.X"

  account_id                             = "1234567890"
  existing_bucket_name                   = ""
  bucket_name                            = "exmple-bucket-597"
  object_ownership                       = "BucketOwnerEnforced"
  bucket_force_destroy                   = false
  bucket_object_lock_enabled             = false
  object_lock_rule                       = null
  object_lock_token                      = null
  enable_bucket_accelerate_configuration = false
  enable_bucket_cors_config              = false
  bucket_allowed_headers                 = ["*"]
  bucket_allowed_methods                 = ["GET","PUT","POST","DELETE","HEAD"]
  bucket_allowed_origins                 = ["https://example.com]
  bucket_expose_headers                  = ["ETag"]
  bucket_max_age_seconds                 = 3000
  enable_object_encryption               = false
  enable_intelligent_tiering             = false
  tiering_config_name                    = "exampleconfig"
  tiering_config_status                  = false
  tiering_config                         = [{access_tier = "ARCHIVE_ACCESS",125}]
  tiering_config_filter                  = {
                                            prefix = "documents/"
                                            tags =  = {
                                                       priority = "high",
                                                       class    = "blue"
                                                      }
                                           }
  enable_logging                        = false
  logging_target_bucket_id              = "exmple-bucket-597"
  logging_target_bucket_prefix          = "log/"
  expected_bucket_owner_account_id      = null
  enable_bucket_versioning              = true
  enable_website_configuration          = false
  index_document                        = "index.html"
  error_document                        = "error.html"
  routing_rules                         = null
  redirect_all_requests_to              = null
  attach_policy                         = true
  bucket_policy                         = "input desired bucket policy (required)"
  kms_key_arn                           = "input kms key arn"
  bucket_tags                           = {
                                           Name = "S3"
                                          }
}

```