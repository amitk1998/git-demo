# **AWS APIGateway Rule Module**

Terraform module to create APIGateway on AWS

# **Description**
 
 This module is basically used to create APIGateway on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `api_gateway_type`,`name`,`description`,`api_gateway_rest_api_type`,`rest_api_gateway_api_key_source`,`api_gateway_stage_settings` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_api_gateway_type"></a>[api\_gateway\_type](#input\_api\_gateway\_type)| API Gateway Type. Supported values are REST, HTTP and WEBSOCKET. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_name"></a>[name](#input\_name)| API Gateway Name. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_description"></a>[description](#input\_description)| API Gateway Description. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_binary_media_types"></a>[binary\_media\_types](#input\_binary\_media\_types)| API Gateway Supported Binary Media Types for REST APIs. | `list(string)` | No | `[ ]` | `["input binary media type"]` |
| <a name="input_open_api_specifications"></a>[open\_api\_specifications](#input\_open\_api\_specifications)| API Gateway Open API Specifications. | `string` | No | `null` | `null` |<pre><code>jsonencode({<br> openapi = "3.0.1"<br> info = {<br> title   = "example"<br> version = "1.0"<br> }<br> paths = {<br> "/path1" = {<br> get = {<br> x-amazon-apigateway-integration = {<br> httpMethod           = "GET"<br> payloadFormatVersion = "1.0"<br> type                 = "HTTP_PROXY"<br> uri                  = "https://ip-ranges.amazonaws.com/ip-ranges.json"<br> }<br> }<br> }<br> }<br> })<code></pre> |
| <a name="input_disable_default_api_gateway_endpoint"></a>[disable\_default\_api\_gateway\_endpoint](#input\_disable\_default\_api\_gateway\_endpoint)| Description. | `bool` | No | `false` | `false` |
| <a name="input_api_gateway_rest_api_type"></a>[api\_gateway\_rest\_api\_type](#input\_api\_gateway\_rest\_api\_type)| API Gateway REST API Type. Supported values are REGIONAL, EDGE, and PRIVATE. | `string` | No | `"REGIONAL"` | `"REGIONAL"` |
| <a name="input_rest_api_gateway_api_key_source"></a>[rest\_api\_gateway\_api\_key\_source](#input\_rest\_api\_gateway\_api\_key\_source)| REST API Gateway API Key Source. Supported values are HEADER and AUTHORIZER. | `string` | No | `"HEADER"` | `"HEADER"` |
| <a name="input_vpc_endpoint_ids"></a>[vpc\_endpoint\_ids](#input\_vpc\_endpoint\_ids)| List of VPC Endpoint IDs for Private REST API Gateway. | `list(string)` | No | `[ ]` | `["input list of vpc endpoint ids"]` |
| <a name="input_rest_api_minimum_body_size_for_compression"></a>[rest\_api\_minimum\_body\_size\_for\_compression](#input\_rest\_api\_minimum\_body\_size\_for\_compression)| Minimum Body Size required for Compression for REST API Gateway in bytes. | `number` | No | `null` | `20` |
| <a name="input_websocket_api_gateway_route_selection_expression"></a>[websocket\_api\_gateway\_route\_selection\_expression](#input\_websocket\_api\_gateway\_route\_selection\_expression) | Route Selection Expression for Websocket API Gateway | `string` | No | `"$request.header.x-api-key"` | `"$request.header.x-api-key"` |
| <a name="input_websocket_api_gateway_route_selection_expression"></a>[websocket\_api\_gateway\_route\_selection\_expression](#input\_websocket\_api\_gateway\_route\_selection\_expression)| Route Selection Expression for Websocket API Gateway. | `string` | No | `"$request.body.action"` | `"$request.body.action"` |
| <a name="input_websocket_api_gateway_api_selection_expression"></a>[websocket\_api\_gateway\_api\_selection\_expression](#input\_websocket_api_gateway_api_selection_expression)| API Selection Expression for Websocket API Gateway. | `string` | No | `"$request.header.x-api-key"` | `"$request.header.x-api-key"` |
| <a name="input_http_api_gateway_cors_configurations"></a>[http\_api\_gateway\_cors\_configurations](#input\_http\_api\_gateway\_cors\_configurations)| CORS Configuration for HTTP API Gateway. | <pre><code>object({<br> allow_credentials = optional(bool, null)<br> allow_headers	  = optional(list(string), null)<br> allow_methods	  = optional(list(string), null)<br> allow_origins	  = optional(list(string), null)<br> expose_headers	  = optional(list(string), null)<br> max_age			  = optional(number, null)<br> })</code></pre> | No | `null` | <pre><code>{<br> allow_credentials = true<br> allow_headers	  = ["content-type","x-amz-date"]<br> allow_methods	  = ["GET","OPTIONS","POST"]<br> allow_origins	  = ["*"]<br> expose_headers	  = [ ]<br> max_age			  = 5<br> }</code></pre> |
| <a name="input_rest_api_gateway_policy"></a>[rest\_api\_gateway\_policy](#input\_rest\_api\_gateway\_policy)| REST API Gateway Policy. | `string` | Yes | `N/A` | `N/A` |
| <a name="input_api_gateway_models"></a>[api\_gateway\_models](#input\_api\_gateway\_models)| API Gateway Model Definations. | <pre><code>list(object({<br> name 			= string<br> description 	= string<br> content_type 	= string<br> schema 			= string<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name="input_api_gateway_stage_settings"></a>[api\_gateway\_stage\_settings](#input\_api\_gateway\_stage\_settings)| API Gateway Stage Settings | <pre><code>list(object({<br> name						= string<br> enable_xray_tracing			= optional(bool, false)<br> enable_caching				= optional(bool, false)<br> cache_size					= optional(number, null)<br> stage_variables				= optional(map(string), null)<br> access_log_format			= optional(string, "CLF")<br> enable_canary_deployment	= optional(bool, false)<br> logging_level				= optional(string, "ERROR")<br> throttling_burst_limit		= optional(number, 5000)<br> throttling_rate_limit		= optional(number, 10000)<br> cache_ttl_in_seconds		= optional(number, null)<br> cache_control_strategy		= optional(string, "SUCCED_WITH_RESPONSE_HEADER")<br> auto_deploy					= optional(bool, false)<br> canary_deployment_settings	= optional(object({<br> percentage_of_traffic_to_redirect_to_canary = number<br> overridden_stage_variables					= optional(map(string), null)<br> use_stage_cache								= optional(bool, false)<br> }), null)<br> }))</code></pre> | No | <pre><code>[<br> {<br> name						= N/A<br> enable_xray_tracing			= false<br> enable_caching				= false<br> cache_size					= 100<br> stage_variables				= { }<br> access_log_format			= "CLF"<br> enable_canary_deployment	= false<br> logging_level				= "ERROR"<br> throttling_burst_limit		= 5000<br> throttling_rate_limit		= 10000<br> cache_ttl_in_seconds		= 60<br> cache_control_strategy		= "SUCCED_WITH_RESPONSE_HEADER"<br> auto_deploy					= false<br> canary_deployment_settings	= op[<br> {<br> percentage_of_traffic_to_redirect_to_canary = N/A<br> overridden_stage_variables					= { }<br> use_stage_cache								= false<br> }<br> ]<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> name						= N/A<br> enable_xray_tracing			= false<br> enable_caching				= false<br> cache_size					= 100<br> stage_variables				= { }<br> access_log_format			= "CLF"<br> enable_canary_deployment	= false<br> logging_level				= "ERROR"<br> throttling_burst_limit		= 5000<br> throttling_rate_limit		= 10000<br> cache_ttl_in_seconds		= 60<br> cache_control_strategy		= "SUCCED_WITH_RESPONSE_HEADER"<br> auto_deploy					= false<br> canary_deployment_settings	= op[<br> {<br> percentage_of_traffic_to_redirect_to_canary = N/A<br> overridden_stage_variables					= { }<br> use_stage_cache								= false<br> }<br> ]<br> }<br> ]</code></pre> |
| <a name="input_api_key_specifications"></a>[api\_key\_specifications](#input\_api\_key\_specifications)| API Gateway API Keys Specifications | <pre><code>list(object({<br> name 			= N/A<br> description 	= optional(string, "Managed by Terraform.")<br> is_enabled 		= optional(bool, true)<br> value 			= optional(string, null)<br> }))</code></pre> | No | <pre><code>[<br> {<br> name 			= N/A<br> description 	= "Managed by Terraform"<br> is_enabled 		= true<br> value 			= null<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> name 			= N/A<br> description 	= "Managed by Terraform"<br> is_enabled 		= true<br> value 			= null<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> name 			= N/A<br> description 	= "Managed by Terraform"<br> is_enabled 		= true<br> value 			= null<br> }<br> ]</code></pre> |
| <a name="input_vpc_link_specifications"></a>[vpc\_link\_specifications](#input\_vpc\_link\_specifications)| API Gateway API VPC Link Specifications. | <pre><code>list(object({<br> name 				= string<br> description 		= optional(string, "Managed by Terraform.")<br> target_nlb_arn 		= optional(string, null)<br> security_group_ids 	= optional(list(string), [])<br> subnet_ids  		= optional(list(string), [])<br> }))</code></pre> | No | `null` | <pre><code>[<br> {<br> name 				= N/A<br> description 		= "Managed by Terraform."<br> target_nlb_arn 		= null<br> security_group_ids 	= []<br> subnet_ids  		= ["subnet-1eyyeyy4743uhy0","subnet-2eyyeyy4743uhy0"]<br> }<br> ]</code></pre> |
| <a name="input_api_gateway_enable_certificates"></a>[api\_gateway\_enable\_certificates](#input\_api\_gateway\_enable\_certificates)| REST API Gateway Enable Certificates. | `bool` | No | `false` | `false` |
| <a name="input_domain_name_specifications"></a>[domain\_name\_specifications](#input\_domain\_name\_specifications)| API Gateway Custom Domain Name Specifications | `string` | Yes | `N/A` | `N/A` |
| <a name="input_domain_name_mapping_specifications"></a>[domain\_name\_mapping\_specifications](#input\_domain\_name\_mapping\_specifications) | API Gateway Custom Domain Name API Mapping Specifications. | <pre><code>list(object({<br> domain_name 		= string<br> security_policy 	= optional(string, "TLS_1_2")<br> acm_certificate_arn = string }))</code></pre> | Yes | `null` | <pre><code>[<br> {<br> domain_name 		= N/A<br> security_policy 	= optional(string, "TLS_1_2")<br> acm_certificate_arn = N/A }<br> ]</code></pre> |
| <a name="input_domain_name_mapping_specifications"></a>[domain\_name\_mapping\_specifications](#input\_domain\_name\_mapping\_specifications)| API Gateway Custom Domain Name API Mapping Specifications. | <pre><code>list(object({<br> domain_name = string<br> stage_name	= string<br> base_path	= string<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name="input_log_group_kms_key_arn"></a>[log\_group\_kms\_key\_arn](#input\_log\_group\_kms\_key\_arn)| REST API Gateway Log Group KMS Key ARN.. | `string` | No | `null` | `"input kms key arn"` |
| <a name="input_log_group_retention_period"></a>[log\_group\_retention\_period](#input\_log\_group\_retention\_period)| REST API Gateway Log Group Retention Period. | `number` | No | `7` | `7` |
| <a name="input_log_group_skip_destroy"></a>[log\_group\_skip\_destroy](#input\_log\_group\_skip\_destroy)| REST API Gateway Log Group Skip Destroy. | `bool` | No | `false` | `false` |
| <a name="input_web_acl_arn"></a>[web\_acl\_arn](#input\_web\_acl\_arn)| Web ACL ARN for Association with API Gateway. | `bool` | No | `false` | `false` |
| <a name="input_fail_on_warnings"></a>[fail\_on\_warnings](#input\_fail\_on\_warnings)| Fail on warnings. | `bool` | No | `false` | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "apigateway_cloudwatch_global_iam_role" {
  source    = "tfe.axisb.com/ax-tfe/iam/aws"
  version   = "X.X.X"

  role_name = "APIGateway-Cloudwatch-Role" 
  trust_relationship_policy = jsonencode({
    "Version" : "2012-10-17",
    "Statement" : [
      {
        "Effect" : "Allow",
        "Principal" : {
            "Service" : "apigateway.amazonaws.com"
        },
        "Action" : "sts:AssumeRole"
      }
    ]
  })
  
  policy_arn    = [
    "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs"
  ] 
  attach_policy = true
  
  tags          = {
                   Name = "Test"
                  }
}

module "apigateway_rest" {
  source                          = "tfe.axisb.com/ax-tfe/apigateway/aws"
  version                         = "X.X.X"
  
  api_gateway_type                = "REST"
  name                            = "Terraform-Test-REST"
  description                     = "API Gateway Testing Using Terraform"
  api_gateway_rest_api_type       = "REGIONAL" 
  rest_api_gateway_api_key_source = "HEADER"
  api_gateway_stage_settings      = [{ name = "Test-POC-Terraform" enable_xray_tracing = false enable_caching = false cache_size = null stage_variables = null access_log_format = "CLF" enable_canary_deployment = false logging_level = "ERROR" throttling_burst_limit = 5000 throttling_rate_limit = 10000 cache_ttl_in_seconds = null cache_control_strategy = "SUCCED_WITH_RESPONSE_HEADER" auto_deploy = false }]
  tags                            = {
                                     Name = "Test"
                                    }
}

module "apigateway_http" {
  source                          = "tfe.axisb.com/ax-tfe/apigateway/aws"
  version                         = "X.X.X"
  
  api_gateway_type                = "HTTP"
  name                            = "Terraform-Test-HTTP"
  description                     = "API Gateway Testing Using Terraform" 
  rest_api_gateway_api_key_source = "HEADER"
  tags                            = {
                                     Name = "Test"
                                    }
}

module "apigateway_websocket" {
  source                           = "tfe.axisb.com/ax-tfe/apigateway/aws"
  version                          = "X.X.X"
  
  api_gateway_type                 = "WEBSOCKET"
  name                             = "Terraform-Test-WEBSOCKET"
  description                      = "API Gateway Testing Using Terraform"
  rest_api_gateway_api_key_source  = "HEADER"
  tags                             = {
                                      Name = "Test"
                                     }
}

```




  [
{
	virtual_machine_type                   = "WINDOWS"
        os_flavor                        = "windows"
        virtual_machine_name             = "std-win-blpts"
        source_image_reference = { 
  publisher = "MicrosoftWindowsServer" 
  offer = "WindowsServer" 
  sku = "2019-Datacenter" 
  version = "latest" 
  }
  enable_encryption_at_host = false
	nic_name = "wd-nic-one-rg"
	ip_configuration = [{
		name = "wd-nic-one-rg-ipconfig"
		private_ip_address_allocation = "Dynamic"
	}
	]
	admin_username = "windowsadminuser"
	admin_password = "New@testpassword112"
},
{
	virtual_machine_type = "LINUX"
        os_flavor                        = "linux"
        virtual_machine_name              = "std-linux-blpts"
   
        enable_encryption_at_host = false
	nic_name = "li-nic-one-rg"
	ip_configuration = [{
		name = "li-nic-one-rg-ipconfig"
		private_ip_address_allocation = "Dynamic"
	}]
}
]