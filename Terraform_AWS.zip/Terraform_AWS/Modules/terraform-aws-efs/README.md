# **AWS EFS Module**

Terraform module to create EFS on AWS

# **Description**
 
 This module is basically used to create Elastic File System on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `vpc_id`,`subnet_ids`,`performance_mode`,`encrypted`,`throughput_mode` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_availability_zone_name"></a>[availability\_zone\_name](#input\_availability\_zone\_name) | The availability zone name | `string` | No | null | `"ap-south-1"` |
| <a name = "input_performance_mode"></a>[performance\_mode](#input\_performance\_mode) | The performance mode for the EFS | `string` | No | null | `"generalPurpose"` |
| <a name = "input_encrypted"></a>[encrypted](#input\_encrypted) | If true, the disk will be encrypted | `bool` | No | false | `false` |
| <a name = "input_provisioned_throughput_in_mibps"></a>[provisioned\_throughput\_in\_mibps](#input\_provisioned\_throughput\_in\_mibps) | The throughput, measured in MiB/s, that you want to provision for the fle system.Only applicable with `throughput_mode` set to `provisioned` | `string` | No | null | `null` |
| <a name = "input_throughput_mode"></a>[throughput\_mode](#input\_throughput\_mode) | The throughput mode for the EFS | `string` | No | "bursting" | `"bursting"` |
| <a name = "input_lifecycle_policy_transition_to_ia_days"></a>[lifecycle\_policy\_transition\_to\_ia\_days](#input\_lifecycle\_policy\_transition\_to\_ia\_days) | The number of days to transition files to IA Storage Class | `number` | No | null | `30` |
| <a name = "input_policy"></a>[policy](#input\_policy) | Policy to be attached to the file system | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_bypass_policy_lockout_safety_check"></a>[bypass\_policy\_lockout\_safety\_check](#input\_bypass\_policy\_lockout\_safety\_check) | A flag to indicate whether to bypass the aws_efs_file_system lockout safety check.Defaults to false | `bool` | No | true | `true` |
| <a name = "input_enable_backup_policy"></a>[enable\_backup\_policy](#input\_enable\_backup\_policy) | Determines whether a backup policy is ENABLED or DISABLED | `bool` | No | false | `false` |
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | The id of the vpc where the security group will be created | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_efs_subnet_ids"></a>[efs\_subnet\_ids](#input\_efs\_subnet\_ids) | Subnet ids for EFS | `list(string)` | No | [ ] | `["subnet-28y3uh3uyb83o3"]` |
| <a name = "input_source_security_sg_ids"></a>[source\_security\_sg\_ids](#input\_source\_security\_sg\_ids) | EKS Worker Node Group Security Group Ids | `list(string)` | No | [ ] | `["sg-2c9yuyu2adhue3q8"]` |
| <a name = "input_prefix_list_ids"></a>[prefix\_list\_ids](#input\_prefix\_list\_ids) | Prefix List Ids | `list(string)` | No | [ ] | `[ ]` |
| <a name = "input_ipv4_cidr_blocks"></a>[ipv4\_cidr\_blocks](#input\_ipv4\_cidr\_blocks) | IPV4 CIDR Blocks | `list(string)` | No | [ ] | `[ ]` |
| <a name = "input_efs_sg_tags"></a>[efs\_sg\_tags](#input\_efs\_sg\_tags) | A map of tags to add to EFS Security Group | `map(string)` | No | { } | `{ }` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | KMS Key Arn | `string` | No | null | `"input your kms key arn"` |
| <a name = "input_metadata"></a>[metadata](#input\_metadata) | A Map of Metadata | `map(string)` | No | { } | `{ }` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "efs" {
  source                                 = "tfe.axisb.com/ax-tfe/efs/aws"
  version                                = "X.X.X"

  availability_zone_name                 = null
  performance_mode                       = "generalPurpose"                      
  encrypted                              = true
  provisioned_throughput_in_mibps        = null      
  throughput_mode                        = "bursting"                     
  lifecycle_policy_transition_to_ia_days = 30 
  enable_backup_policy                   = false
  efs_subnet_ids                         = ["subnet-83ehu3hy833jnrhy"]
  policy                                 = null
  bypass_policy_lockout_safety_check     = false
  kms_key_arn                            = "input kms key arn"
  vpc_id                                 = "vpc-38y3uy8h3h33ue"

  tags                                   = {
                                            Name = "Test"
                                           }

}

```