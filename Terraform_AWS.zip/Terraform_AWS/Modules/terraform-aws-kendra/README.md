# **AWS Kendra Module**

Terraform module to create Kendra on AWS

# **Description**
 
 This module is basically used to create Kendra on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `index_name`,`index_description`,`index_iam_role_arn`,`enterprise_edition_index` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_region"></a>[region](#input\_region) | AWS Region | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_account_id"></a>[account\_id](#input\_account\_id) | AWS Account ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_create_index"></a>[create\_index](#input\_create\_index) | Create Index | `bool` | No | `true` | `true` |
| <a name = "input_index_name"></a>[index\_name](#input\_index\_name) | Index Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_index_description"></a>[index_description](#input\_index_description) | Index Description | `string` | No | `"example"` | `"example"` |
| <a name = "input_enterprise_edition_index"></a>[enterprise\_edition\_index](#input\_enterprise\_edition\_index) | Enterprise Edition Kendra Index Required | `bool` | No | `false` | `false` |
| <a name = "input_index_iam_role_arn"></a>[index\_iam\_role\_arn](#input\_index\_iam\_role\_arn) | Index IAM Role ARN for Logging | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_kms_key_id"></a>[kms\_key\_id](#input\_kms\_key\_id) | Index KMS Key ID | `string` | No | `null` | `"input kms key id"` |
| <a name = "input_query_capacity_units"></a>[query\_capacity\_units](#input\_query\_capacity\_units) | Query Capacity Units. Only applicable for Enterprise Indexes | `number` | No | `null` | `10` |
| <a name = "input_storage_capacity_units"></a>[storage\_capacity\_units](#input\_storage\_capacity\_units) | Storage Capacity Units. Only applicable for Enterprise Indexes | `number` | No | `null` | `20` |
| <a name = "input_enable_token_based_access_control"></a>[enable\_token\_based\_access\_control](#input\_enable\_token\_based\_access\_control) | Enable Token Based Access Control | `bool` | No | `false` | `false` |
| <a name = "input_enable_sso"></a>[enable\_sso](#input\_enable\_sso) | Enable SSO Integration | `bool` | No | `false` | `false` |
| <a name = "input_enable_json_type_token_configuration"></a>[enable\_json\_type\_token\_configuration](#input\_enable\_json\_type\_token\_configuration) | Token Configuration. Only applicable when Token based access control is enabled | <pre><code>object({<br> group_attribute_field = optional(string, null)<br> user_name_attribute_field = optional(string, null)<br> url = optional(string, null)<br> issuer = optional(string, null)<br> claim_regex = optional(string, null)<br> key_location = optional(string, null)<br> secret_manager_arn = optional(string, null)<br> })</code></pre> | No | <pre><code>{<br> group_attribute_field = "example"<br> user_name_attribute_field = "example"<br> url = "input url"<br> issuer = "input issuer"<br> claim_regex = "example"<br> secret_manager_arn = "input secret manager arn"<br> }</code></pre> | <pre><code>{<br> group_attribute_field = "example"<br> user_name_attribute_field = "example"<br> url = "input url"<br> issuer = "input issuer"<br> claim_regex = "example"<br> secret_manager_arn = "input secret manager arn"<br> }</code></pre> |
| <a name = "input_document_metadata_configurations"></a>[document\_metadata\_configurations](#input\_document\_metadata\_configurations) | Document Metadata Configuration | <pre><code>list(object({<br> name 		= string<br> type 		= string<br> search 		= object({<br> displayable = optional(bool, true)<br> facetable = optional(bool, false)<br> searchable = optional(bool, true)<br> sortable = optional(bool, false)<br> })<br> relevance 	= object({<br> freshness = optional(bool, null)<br> duration = optional(string, null)<br> importance = optional(number, null)<br> rank_order = optional(string, null)<br> values_important_map = optional(map(string), {})<br> })<br> }))</code></pre> | No | <pre><code>[<br> {<br> name 		= "N/A"<br> type 		= "N/A"<br> search 		= {<br> displayable = true<br> facetable = false<br> searchable = true<br> sortable = false<br> }<br> relevance 	= {<br> freshness = null<br> duration = null<br> importance = null<br> rank_order = null<br> values_important_map = { } }<br> }<br> ]</code></pre> | <pre><code>[<br> {<br> name 		= "N/A"<br> type 		= "N/A"<br> search 		= {<br> displayable = true<br> facetable = false<br> searchable = true<br> sortable = false<br> }<br> relevance 	= {<br> freshness = null<br> duration = null<br> importance = null<br> rank_order = null<br> values_important_map = { } }<br> }<br> ]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "kendra_iam_role" {
  source     = "tfe.axisb.com/ax-tfe/iam/aws"
  version    = "X.X.X"
  
  role_name  = "TEST-POC-Kendra-Role"
  
  trust_relationship_policy = jsonencode({
      "Version" : "2012-10-17",
      "Statement" : [
          {
            "Effect" : "Allow",
              "Principal" : {
                "Service" : "ec2.amazonaws.com"
            },
            "Action" : "sts:AssumeRole"
          }
        ]
  })
  
  policy_arn = [
    "arn:aws:iam::aws:policy/AmazonKendraFullAccess",
    "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
  ]

  attach_policy           = true
  create_instance_profile = false
  tags                    = {
                             Name = "Test"
                            }
}

module "kendra" {
  source                   = "tfe.axisb.com/ax-tfe/kendra/aws"
  version                  = "X.X.X"
  
  index_name               = "example"
  index_description        = "example"
  index_iam_role_arn       = "input iam role here"
  enterprise_edition_index = false

  tags                     = {
                              Name = "Test"
                             }

}


```