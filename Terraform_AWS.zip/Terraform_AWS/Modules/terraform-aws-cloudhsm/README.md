# **AWS  CloudHSM Module**

Terraform module to create  CloudHSM on AWS

# **Description**
 
 This module is basically used to  create cloud hsm on Amazon Web Services(AWS).
 To create  cloud hsm it requires only `cluster_subnet_ids` attributes

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_cluster_subnet_ids"></a>[cluster\_subnet\_ids](#input\_cluster\_subnet\_ids) | CLoudHSM Cluster Subnet Ids | `list(string)` | Yes | `N/A` | `N/A` |
| <a name="input_tags"></a>[tags](#input\_tags) | Route53 Hosted Zone Resource Tags. | `map(string)` | Yes | `{}` | `N/A` |

## **Example Usage**

```hcl

module "cloudhsm" {
  source                     = "tfe.axisb.com/ax-tfe/cloudhsm/aws"
  version                    = "X.X.X"
  
  cluster_subnet_ids         = ["subnet-367yd7y6d3ydg","subnet-7yi3g733u3b3dkn"]
  tags                       = {
                                Name = "Test"
                               }
 
}

```