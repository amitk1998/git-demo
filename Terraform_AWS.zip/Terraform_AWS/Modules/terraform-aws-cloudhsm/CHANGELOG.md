| <a name="variable_cluster_type"></a>[cluster_type](#variable_cluster_type) | The cluster type you want to create. Possible values are serverless, Provisioned | `string` | No | `null` | `null` |
| <a name="variable_name"></a>[name](#variable_name) | The name of the MSK cluster | `string` | No | `null` | `null` |
| <a name="variable_storage_mode"></a>[storage_mode](#variable_storage_mode) | The storage mode for the MSK cluster | `string` | No | `null` | `null` |
| <a name="variable_enhanced_monitoring"></a>[enhanced_monitoring](#variable_enhanced_monitoring) | Enhanced monitoring configuration | `string` | No | `null` | `null` |
| <a name="variable_kafka_version"></a>[kafka_version](#variable_kafka_version) | The Kafka version for the MSK cluster | `string` | No | `null` | `null` |

...

## Broker Node Group Info

| <a name="variable_broker_node_group_info"></a>[broker_node_group_info](#variable_broker_node_group_info) | Broker node group information | `object` | No | `null` | `null` |

...

## Client Authentication

| <a name="variable_client_authentication"></a>[client_authentication](#variable_client_authentication) | Client authentication configuration | `object` | No | `null` | `null` |

...

| <a name="variable_encryption_at_rest_kms_key_arn"></a>[encryption_at_rest_kms_key_arn](#variable_encryption_at_rest_kms_key_arn) | KMS key ARN for encryption at rest | `string` | No | `null` | `null` |
| <a name="variable_encryption_in_transit_client_broker"></a>[encryption_in_transit_client_broker](#variable_encryption_in_transit_client_broker) | Enable encryption for client-to-broker communication | `string` | No | `null` | `null` |
| <a name="variable_encryption_in_transit_in_cluster"></a>[encryption_in_transit_in_cluster](#variable_encryption_in_transit_in_cluster) | Enable encryption within the cluster | `bool` | No | `null` | `null` |
| <a name="variable_enable_logging_info"></a>[enable_logging_info](#variable_enable_logging_info) | A flag to enable logging information | `bool` | No | `false` | `false` |

...

## CloudWatch Logs

| <a name="variable_cloudwatch_logs"></a>[cloudwatch_logs](#variable_cloudwatch_logs) | CloudWatch logs configuration | `object` | No | `null` | `null` |

...

| <a name="variable_serverless_cluster_name"></a>[serverless_cluster_name](#variable_serverless_cluster_name) | The name for the AWS MSK Serverless Cluster. | `string` | No | `null` | `null` |
| <a name="variable_subnet_ids"></a>[subnet_ids](#variable_subnet_ids) | A list of subnet IDs where the MSK Serverless Cluster will be deployed. | `list(string)` | No | `[]` | `[]` |
| <a name="variable_security_group_ids"></a>[security_group_ids](#variable_security_group_ids) | A list of security group IDs to associate with the MSK Serverless Cluster. | `list(string)` | No | `[]` | `[]` |
| <a name="variable_enable_iam_authentication"></a>[enable_iam_authentication](#variable_enable_iam_authentication) | Set to true to enable IAM-based authentication for the MSK Serverless Cluster. | `bool` | No | `true` | `true` |
| <a name="variable_cluster_arn"></a>[cluster_arn](#variable_cluster_arn) | The ARN of the MSK cluster. | `string` | No | `null` | `null` |
| <a name="variable_server_properties"></a>[server_properties](#variable_server_properties) | The server properties for the MSK cluster. | `string` | No | `null` | `null` |