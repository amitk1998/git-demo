# **AWS SSM Module**

Terraform module to create System Manager Parameter Store 

# **Description**
 
This module is used to create and manage parameter values securely within the AWS Systems Manager Parameter Store.
This module is usefull for securely storing and managing senstive data,configuration values or any parameters needed by your applications.
It requires few parameters in order to create parameter store like `name`,`description`,`type`,`value` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_parameter_names_to_be_read"></a>[parameter\_names\_to\_be\_read](#input\_parameter\_names\_to\_be\_read) | Parameter Name to retrieve details. | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_paramater_name"></a>[paramater_name](#input\_paramater\_name) | Paramater Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_paramater_description"></a>[paramater\_description](#input\_paramater\_description) | Paramater Description | `string` | No | null | `"Parameter descriptiion"` |
| <a name = "input_paramater_type"></a>[paramater\_type](#input\_paramater\_type) | Paramater Type | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_paramater_value"></a>[paramater\_value](#input\_paramater\_value) | Paramater Value | `string` | No | null | `"your database master password comes here"` |
| <a name = "input_allowed_pattern"></a>[allowed\_pattern](#input\allowed\_pattern) | Parameter Regex Pattern to validate paramater value | `string` | No | null | `"example_pattern"` |
| <a name = "input_paramater_data_type"></a>[paramater\_data\_type](#input\_paramater\_data\_type) | Parameter Data Type. Valid values are text, aws:ssm:integration, or aws:ec2:image | `string` | No | null | `"text"` |
| <a name = "input_paramater_kms_key_id"></a>[paramater\_kms\_key\_id](#input\_paramater\_kms\_key\_id) | Parameter KMS Key ID for Encrypting Paramater Value of type SecureString. Only applicable when parameter type is SecureString | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"` |
| <a name = "input_paramater_tier"></a>[paramater\_tier](#input\_paramater\_tier) | Parameter Tier. Valid values are Standard, Advanced, or Intelligent-Tiering | `string` | No | null | `"Standard"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ssm" {
  source                = "tfe.axisb.com/ax-tfe/ssm/aws"
  version               = "X.X.X"

  create_paramater      = true
  paramater_name        = "tfe_ssm_parameter_testing"
  paramater_description = "ssm_parameter module testing through terraform"
  paramater_type        = "String"
  paramater_value       = "bar"

  tags                  = {
                           Name = "Test"
                          }

}

```