# **AWS RDS Module**

Terraform module to create RDS on AWS

# **Description**
 
 This module is basically used to create RDS on Amazon Web Services(AWS).
 It requires some attributes in order to be created on AWS like `region`,`account_id`,`rds_subnet_ids`,`rds_db_identifier`,`availability_zones`,`snapshot_identifier`,`rds_db_vpc_security_group_ids`,`rds_db_engine`,`rds_db_engine_version`,`rds_db_instance_class`,`rds_db_port`,`rds_db_username`,`rds_db_password`,`kms_key_arn`,`parameter_details` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_region"></a>[region](#input\_region) | AWS Region | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_availability_zones"></a>[availability\_zones](#input\_availability\_zones) | List of Availability Zones for Cluster. Only Applicable for Aurora Clusters | `list(string)` | No | [ ] | `["ap-south-1a","ap-south-1b"]` |
| <a name = "input_account_id"></a>[account\_id](#input\_account\_id) | AWS Account ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_rds_db_multi_az_enabled"></a>[rds\_db\_multi\_az\_enabled](#input\_rds\_db\_multi\_az\_enabled) | Enbale RDS DB Multi AZ Deployment | `bool` | No | null | `false` |
| <a name = "input_rds_db_replicas_count"></a>[rds\_db\_replicas\_count](#input\_rds\_db\_replicas\_count) | RDS DB Replicas Count | `number` | No | 0 | `0` |
| <a name = "input_rds_db_cluster_instance_count"></a>[rds\_db\_cluster\_instance\_count](#input\_rds\_db\_cluster\_instance\_count) | RDS DB Cluster Instances Count. Only Applicable for Aurora Clusters | `number` | No | null | `2` |
| <a name = "input_rds_db_publicly_accessible"></a>[rds\_db\_publicly\_accessible](#input\_rds\_db\_publicly\_accessible) | Is RDS DB Publicly Available | `bool` | No | false | `false` |
| <a name = "input_rds_db_vpc_security_group_ids"></a>[rds\_db\_vpc\_security\_group\_ids](#input\_rds\_db\_vpc\_security\_group\_ids) | RDS DB Vpc Security Group Ids | `list(string)` | Yes | [ ] | `["sg-s6gdh4eybey7ey8eu"]` |
| <a name = "input_rds_db_identifier"></a>[rds\_db\_identifier](#input\_rds\_db\_identifier) | RDS DB Identifier | `string` | No | null | `"example-instance` |
| <a name = "input_rds_db_engine"></a>[rds\_db\_engine](#input\_rds\_db\_engine) | RDS DB Engine Name. Valid values are mysql, mariadb, postgres, aurora-mysql, aurora-postgresql,  custom-oracle-ee, custom-oracle-ee-cdb, oracle-ee, oracle-ee-cdb, oracle-se2, oracle-se2-cdb, sqlserver-ee, sqlserver-se, sqlserver-ex, sqlserver-web, custom-sqlserver-ee, custom-sqlserver-se, and custom-sqlserver-web | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_rds_db_engine_family"></a>[rds\_db\_engine\_family](#input\_rds\_db\_engine\_family) | RDS DB Engine Family | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_engine_mode"></a>[engine\_mode](#input\_engine\_mode) | RDS DB Engine Mode. Only Applicable for Aurora Clusters. Valid values are global, multimaster, parallelquery, provisioned, and serverless | `string` | No | "provisioned" | `"provisioned"` |
| <a name = "input_rds_db_enable_http_endpoint"></a>[rds\_db\_enable\_http\_endpoint](#input\_rds\_db\_enable\_http\_endpoint) | RDS DB Enable HTTP Endpoint. Only Applicable for Aurora Serverless Clusters | `bool` | No | false | `false` |
| <a name = "input_rds_db_engine_version"></a>[rds\_db\_engine\_version](#input\_rds\_db\_engine\_version) | RDS DB Engine Version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_rds_db_major_engine_version"></a>[rds\_db\_major\_engine\_version](#input\_rds\_db\_major\_engine\_version) | RDS DB Major Engine Version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_rds_db_instance_class"></a>[rds\_db\_instance\_class](#input\_rds\_db\_instance\_class) | RDS DB Instance Class | `string` | No | "db.r6g.2xlarge" | `"db.r6g.2xlarge"` |
| <a name = "input_rds_subnet_ids"></a>[rds\_subnet\_ids](#input\_rds\_subnet\_ids) | RDS DB Subnet IDs | `list(string)` | Yes | [ ] | `["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]` |
| <a name = "input_rds_db_port"></a>[rds_db_port](#input\_rds_db_port) | RDS DB Port | `string` | No | null | `"2405"` |
| <a name = "input_rds_db_cluster_scaling_max_capacity"></a>[rds\_db\_cluster\_scaling\_max\_capacity](#input\_rds\_db\_cluster\_scaling\_max\_capacity) | RDS DB Cluster Scaling Max Capacity. Only Applicable for Aurora Clusters and when Engine Mode is either serverless or provisioned | `number` | No | null | `5` |
| <a name = "input_rds_db_cluster_scaling_min_capacity"></a>[rds\_db\_cluster\_scaling\_min\_capacity](#input\_rds\_db\_cluster\_scaling\_min\_capacity) | RDS DB Cluster Scaling Min Capacity. Only Applicable for Aurora Clusters and when Engine Mode is either serverless or provisioned | `number` | No | null | `3` |
| <a name = "input_rds_db_cluster_scaling_auto_pause"></a>[rds\_db\_cluster\_scaling\_auto\_pause](#input\_rds\_db\_cluster\_scaling\_auto\_pause) | RDS DB Cluster Scaling Enable Auto Pause. Only Applicable for Aurora Clusters and when Engine Mode is serverless | `bool` | No | true | `true` |
| <a name = "input_rds_db_cluster_scaling_seconds_until_auto_pause"></a>[rds\_db\_cluster\_scaling\_seconds\_until\_auto\_pause](#input\_rds\_db\_cluster\_scaling\_seconds\_until\_auto\_pause) | RDS DB Cluster Scaling Time in seconds before serverless mode is paused. Only Applicable for Aurora Clusters and when Engine Mode is serverless | `number` | No | 300 | `300` |
| <a name = "input_rds_db_cluster_scaling_timeout_action"></a>[rds\_db\_cluster\_scaling\_timeout\_action](#input\_rds\_db\_cluster\_scaling\_timeout\_action) | RDS DB Cluster Scaling Min Capacity. Only Applicable for Aurora Clusters and when Engine Mode is serverless. Valid values are ForceApplyCapacityChange, and RollbackCapacityChange | `string` | No | "RollbackCapacityChange" | `"RollbackCapacityChange"` |
| <a name = "input_character_set_name"></a>[character\_set\_name](#input\_character\_set\_name) | RDS DB Character Set Name to be used for DB Encoding. Only Applicable for Oracle and Microsoft SQL Instances | `string` | No | null | `"example-characterset"` |
| <a name = "input_nchar_character_set_name"></a>[nchar\_character\_set\_name](#input\_nchar\_character\_set\_name) | RDS DB National Character Set Name. Only Applicable for Oracle Instances | `string` | No | null | `"example-ncharacterset"` |
| <a name = "input_rds_db_iam_authentication_enabled"></a>[rds\_db\_iam\_authentication\_enabled](#input\_rds\_db\_iam\_authentication\_enabled) | Enable RDS DB IAM Authentication | `bool` | No | true | `true` |
| <a name = "input_rds_db_storage_type"></a>[rds\_db\_storage\_type](#input\_rds\_db\_storage\_type) | RDS DB Storage Type | `string` | No | null | `"gp3"` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | RDS DB Storage Encryption KMS Key ARN | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"` |
| <a name = "input_rds_db_iops"></a>[rds\_db\_iops](#input\_rds\_db\_iops) | RDS DB IOPS | `number` | No | null | `10` |
| <a name = "input_rds_db_throughput"></a>[rds\_db\_throughput](#input\_rds\_db\_throughput) | RDS DB Storage Throughput | `number` | No | null | `100` |
| <a name = "input_rds_db_storage_encrypted"></a>[rds\_db\_storage\_encrypted](#input\_rds\_db\_storage\_encrypted) | Enable RDS DB Storage Encryption | `bool` | No | true | `true` |
| <a name = "input_rds_db_allocated_storage"></a>[rds\_db\_allocated\_storage"](#input\_rds\_db\_allocated\_storage") | RDS DB Allocated Storage | `number` | No | null | `100` |
| <a name = "input_rds_db_max_allocated_storage"></a>[rds\_db\_max\_allocated\_storage](#input\_rds\_db\_max\_allocated\_storage) | RDS DB Max Allocated Storage | `number` | No | null | `200` |
| <a name = "input_rds_db_monitoring_interval"></a>[rds\_db\_monitoring\_interval](#input\_rds\_db\_monitoring\_interval) | RDS DB Monitoring Interval | `number` | No | null | `10` |
| <a name = "input_rds_db_maintenance_window"></a>[rds\_db\_maintenance\_window](#input\_rds\_db\_maintenance\_window) | RDS DB Maintenance Window | `string` | No | null | `10` |
| <a name = "input_rds_db_enabled_cloudwatch_logs_exports"></a>[rds\_db\_enabled\_cloudwatch\_logs\_exports](#input\_rds\_db\_enabled\_cloudwatch\_logs\_exports) | RDS DB Cloudwatch Logging types to be enabled | `list(string)` | No | [ ] | `[]` |
| <a name = "input_rds_db_copy_tags_to_snapshot"></a>[rds\_db\_copy\_tags\_to\_snapshot](#input\_rds\_db\_copy\_tags\_to\_snapshot) | RDS DB Copy Tags to Snapshot | `bool` | No | true | `true` |
| <a name = "input_rds_db_backup_retention_period"></a>[rds\_db\_backup\_retention\_period](#input\_rds\_db\_backup\_retention\_period) | RDS DB Backup Retention Period | `number` | No | null | `7` |
| <a name = "input_rds_db_backup_window"></a>[rds\_db\_backup\_window](#input\_rds\_db\_backup\_window) | RDS DB Backup Window | `string` | No | null | `10` |
| <a name = "input_rds_db_allow_major_version_upgrade"></a>[rds\_db\_allow\_major\_version\_upgrade](#input\_rds\_db\_allow\_major\_version\_upgrade) | Enable RDS DB Major Version Upgrade | `bool` | No | true | `true` |
| <a name = "input_rds_db_auto_minor_version_upgrade"></a>[rds\_db\_auto\_minor\_version\_upgrade](#input\_rds\_db\_auto\_minor\_version\_upgrade) | Enable RDS DB Auto minor Version Upgrade | `bool` | No | true | `true` |
| <a name = "input_rds_db_apply_immediately"></a>[rds\_db\_apply\_immediately](#input\_rds\_db\_apply\_immediately) | RDS DB Apply Changes Immediately | `bool` | No | true | `true` |
| <a name = "input_enable_performance_insights"></a>[enable\_performance\_insights](#input\_enable\_performance\_insights) | RDS DB Enable Performance Insights | `bool` | No | false | `false` |
| <a name = "input_performance_insights_retention_period"></a>[performance\_insights\_retention\_period](#input\_performance\_insights\_retention\_period) | RDS DB Performance Insights Retention Period | `number` | No | null | `5` |
| <a name = "input_rds_db_delete_automated_backups_after_deletion"></a>[rds\_db\_delete\_automated\_backups\_after\_deletion](#input\_rds\_db\_delete\_automated\_backups\_after\_deletion) | RDS DB Remove Automated Backups After Instance Deletion | `bool` | No | true | `true` |
| <a name = "input_rds_db_skip_final_snapshot"></a>[rds\_db\_skip\_final\_snapshot](#input\_rds\_db\_skip\_final\_snapshot) | RDS DB Skip Final Snapshot | `bool` | No | false | `false` |
| <a name = "input_rds_db_deletion_protection"></a>[rds\_db\_deletion\_protection](#input\_rds\_db\_deletion\_protection) | Enable RDS DB Deletion Protection | `bool` | No | false | `false` |
| <a name = "input_rds_db_option_group_name"></a>[rds\_db\_option\_group\_name](#input\_rds\_db\_option\_group\_name) | RDS DB Option Group Name | `string` | No | null | `example-optiongrp` |
| <a name = "input_use_default_option_group"></a>[use\_default\_option\_group](#input\_use\_default\_option\_group) | RDS DB Use Default Option Group. If True then AWS Managed Default Option Group will be used to create database instance | `bool` | No | false | `false` |
| <a name = "input_option_details"></a>[option\_details](#input\_option\_details) | RDS DB Default Options Configuration List | `list(map(string))` | No | [ ] | `[]` |
| <a name = "input_snapshot_identifier"></a>[snapshot\_identifier](#input\_snapshot\_identifier) | Snapshot Name or ARN to create RDS DB from a Snapshot | `string` | No | null | `null` |
| <a name = "input_rds_db_parameter_group_name"></a>[rds\_db\_parameter\_group\_name](#input\_rds\_db\_parameter\_group\_name) | RDS DB Parameter Group Name | `string` | No | null | `"example-rds-parameter-grp` |
| <a name = "input_rds_db_cluster_parameter_group_name"></a>[rds\_db\_cluster\_parameter\_group\_name](#input\_rds\_db\_cluster\_parameter\_group\_name) | RDS DB Cluster Parameter Group Name. Only Applicable for Aurora Clusters | `string` | No | null | `example-parameter-grp` |
| <a name = "input_use_default_parameter_group"></a>[use\_default\_parameter\_group](#input\_use\_default\_parameter\_group) | RDS DB Use Default Parameter Group. If True then AWS Managed Default Parameter Group will be used to create database instance | `bool` | No | false | `false` |
| <a name = "input_use_default_cluster_parameter_group"></a>[use\_default\_cluster\_parameter\_group](#input\_use\_default\_cluster\_parameter\_group) | Desc | `bool` | No | false | `false` |
| <a name = "input_parameter_details"></a>[parameter\_details](#input\_parameter\_details) | RDS DB Default Paramter Configuration List | `list(map(string))` | No | [ ] | `[{ name = "tls" value = "enabled" }]` |
| <a name = "input_cluster_parameter_details"></a>[cluster\_parameter\_details](#input\_cluster\_parameter\_details) | RDS DB Default Cluster Paramter Configuration List. Only Applicable for Aurora Clusters | `list(map(string))` | No | [ ] | `[]` |
| <a name = "input_timezone"></a>[timezone](#input\_timezone) | Desc | `string` | No | null | `null` |
| <a name = "input_custom_iam_instance_profile"></a>[custom\_iam\_instance\_profile](#input\_custom\_iam\_instance\_profile) | RDS DB Custom IAM Instance Profile Name. Only applicable for RDS Custom DB Instance | `string` | No | null | `null` |
| <a name = "input_domain_id"></a>[domain\_id](#input\_domain\_id) | ID of Directory Service Active Directory Domain to create instance in | `string` | No | null | `"example.com"` |
| <a name = "input_replica_mode"></a>[replica\_mode](#input\_replica\_mode) | Replica Mode for Replicas. Only applicable for Oracle Instances. Valid values are mounted and open-read-only | `string` | No | null | `"mounted"` |
| <a name = "input_backtrack_window"></a>[backtrack\_window](#input\_backtrack\_window) | Backtrack Window in seconds. Only Available for aurora-mysql Engine | `string` | No | null | `null` |
| <a name = "input_license_model"></a>[license\_model](#input\_license\_model) | License Model | `string` | No | null | `null` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "rds" {
  source                                         = "tfe.axisb.com/ax-tfe/rds/aws"
  version                                        = "X.X.X"

  region                                         = "ap-south-1"
  account_id                                     = "1234567890"
  rds_subnet_ids                                 = ["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]
  rds_db_identifier                              = Test-A-P-M-Dev-TestRDS-DB"
  availability_zones                             = ["ap-south-1a","ap-south-1b"]
  snapshot_identifier                            = null
  rds_db_multi_az_enabled                        = false
  rds_db_publicly_accessible                     = false
  rds_db_vpc_security_group_ids                  = ["sg-s6gdh4eybey7ey8eu"]
  rds_db_engine                                  = "aurora-mysql"
  rds_db_engine_version                          = "8.0.aurora_mysql.3.03.0"
  rds_db_instance_class                          = "db.r6g.2xlarge"
  rds_db_port                                    = 2405
  character_set_name                             = null
  rds_db_iam_authentication_enabled              = true
  rds_db_name                                    = "axawstest"
  rds_db_username                                = "axistest"
  rds_db_password                                = "Axistest123##"
  rds_db_storage_type                            = null
  rds_db_iops                                    = null
  rds_db_throughput                              = null
  rds_db_storage_encrypted                       = true
  kms_key_arn                                    = "arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"
  rds_db_allocated_storage                       = 100
  rds_db_max_allocated_storage                   = 120
  rds_db_monitoring_interval                     = null
  use_default_option_group                       = false
  rds_db_option_group_name                       = null
  use_default_parameter_group                    = false
  rds_db_parameter_group_name                    = null
  timezone                                       = null
  performance_insights_retention_period          = null
  enable_performance_insights                    = false
  rds_db_enabled_cloudwatch_logs_exports         = ["error"]
  rds_db_backup_retention_period                 = null
  rds_db_backup_window                           = null
  rds_db_copy_tags_to_snapshot                   = true
  rds_db_allow_major_version_upgrade             = true
  rds_db_auto_minor_version_upgrade              = true
  rds_db_delete_automated_backups_after_deletion = true
  rds_db_skip_final_snapshot                     = false
  rds_db_apply_immediately                       = true
  rds_db_deletion_protection                     = false
  rds_db_major_engine_version                    = "8.0"
  rds_db_engine_family                           = "aurora-mysql8.0"
  rds_db_maintenance_window                      = null
  rds_db_replicas_count                          = 0
  engine_mode                                    = "provisioned"
  nchar_character_set_name                       = null
  custom_iam_instance_profile                    = null
  domain_id                                      = null
  rds_db_cluster_parameter_group_name            = null
  use_default_cluster_parameter_group            = false
  option_details                                 = [] 
  parameter_details                              = [{ name = "tls" value = "enabled" }]
  cluster_parameter_details                      = []
  rds_db_cluster_scaling_max_capacity            = null
  rds_db_cluster_scaling_min_capacity            = null
  rds_db_cluster_scaling_auto_pause              = true 
  rds_db_cluster_scaling_seconds_until_auto_pause = 300
  rds_db_cluster_scaling_timeout_action          = "RollbackCapacityChange"
  rds_db_cluster_instance_count                  = null
  rds_db_enable_http_endpoint                    = false
  replica_mode                                   = null
  backtrack_window                               = null
  license_model                                  = null
  
  tags                                          = {
                                                   Name = "Test"
                                                  }
}

```