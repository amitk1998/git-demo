# **AWS KMS Module**

Terraform module to create KMS on AWS

# **Description**
 
 This module is basically used to create KMS on Amazon Web Services(AWS).
 It requires some attributes in order to be created on AWS like `description`,`key_usage`,`is_enabled`,`enabled_key_rotation`,`policy`,`key_alias_name`,`create_alias` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create_alias"></a>[create\_alias](#input\_create\_alias) | can you want to create kms_key alias | `bool` | No | true | `true` |
| <a name = "input_custom_key_store_id"></a>[custom\_key\_store\_id](#input\_custom\_key\_store\_id) | Enter custom_key_store_id | `string` | No | null | `"input customer key store id"` |
| <a name = "input_deletion_window_in_days"></a>[deletion\_window\_in\_days](#input\_deletion\_window\_in\_days) | Enter deletion_window_in_days | `number` | No | null | `10` |
| <a name = "input_key_id"></a>[key\_id](#input\_key\_id) | Enter key_id for update policy | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_create"></a>[create](#input\_create) | Do you want to create kms_key | `bool` | No | false | `false` |
| <a name = "input_customer_master_key_spec"></a>[customer\_master\_key\_spec](#input\_customer\_master\_key\_spec) | Enter specific the tuype of CMK | `string` | No | "SYMMETRIC_DEFAULT" | `"SYMMETRIC_DEFAULT"` |
| <a name = "input_description"></a>[description](#input\_description) | Description for the kms key | `string` | No | null | `"Example KMS KEY for all Resources"` |
| <a name = "input_key_usage"></a>[key\_usage](#input\_key\_usage) | Specifies the intended use of the key | `string` | No | "ENCRYPT_DECRYPT" | `"ENCRYPT_DECRYPT"` |
| <a name = "input_is_enabled"></a>[is\_enabled](#input\_is\_enabled) | Determine whether the key is enabled | `bool` | No | true | `true` |
| <a name = "input_enabled_key_rotation"></a>[enabled\_key\_rotation](#input\_enabled\_key\_rotation) | Enable key rotation | `bool` | No | true | `true` |
| <a name = "input_multi_region"></a>[multi\_region](#input\_multi\_region) | Key is multi_region | `bool` | No | false | `false` |
| <a name = "input_policy"></a>[policy](#input\_policy) | Desc | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_key_alias_name"></a>[key\_alias\_name](#input\_key\_alias\_name) | key alias name | `string` | No | null | `"alias/my-key-alias"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "kms_key" {
    source                   = "tfe.axisb.com/ax-tfe/kms/aws"
    version                  = "X.X.X"
    description              = "Example KMS KEY for all Resources"
    custom_key_store_id      = null
    customer_master_key_spec = "SYMMETRIC_DEFAULT"
    key_usage                = "ENCRYPT_DECRYPT"
    is_enabled               = true
    multi_region             = false
    enabled_key_rotation     = true
    policy                   = "input desired kms key policy here"
    key_alias_name           = "alias/my-key-alias"
    create_alias             = true
                               

    tags                     = {
                                 Name = "Test"
                                }
}

```