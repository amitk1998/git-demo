# **AWS RouteTable Module**

Terraform module to create RouteTable on AWS

# **Description**
 
 This module is basically used to create RouteTable on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `vpc_id`,`prefix_routes`,`subnet_id_association` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | vpc_id to associate with route table | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_ipv6_routes"></a>[ipv6_routes](#input\_ipv6_routes) | A map of destination my_ipv6_routes and theire target | `list(map(string))` | Yes | `N/A` | `N/A` |
| <a name = "input_cidr_block_routes"></a>[cidr\_block\_routes](#input\_cidr\_block\_routes) | A map of destination route and theire target | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_existing_route_table_id"></a>[existing\_route\_table\_id](#input\_existing\_route\_table\_id) | Route table id | `string` | No | null | `null` |
| <a name = "input_subnet_id_association"></a>[subnet\_id\_association](#input\_subnet\_id\_association) | list of subnet_ids to associate with rout table | `list(string)` | No | null | `["subnet-38y3g4y7i64h4a","subnet-38ueuhuy8yh3c"]` |
| <a name = "input_default_route_table_id"></a>[default\_route\_table\_id](#input\_default\_route\_table\_id) | Default route table id | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_is_default_route_table"></a>[is\_default\_route\_table](#input\_is\_default\_route\_table) | IS Default Route Table | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "routetable" {
  source                        = "tfe.axisb.com/ax-tfe/routetable/aws"
  version                       = "X.X.X"

  vpc_id                       = "vpc-0apq2w7dg92uiw3c"
  existing_route_table_id      = ""
  prefix_routes                = [{
                                   destination_prefix_list_id = "pl-0c52f3d800caec59f"
                                   transit_gateway_id = "tgw-026155c27a092ff48"
                                 }]
  subnet_id_association        = ["subnet-38y3g4y7i64h4a","subnet-38ueuhuy8yh3c"]

  tags                         = {
                                  Name = "Test"
                                 }

}

```