# **AWS Transitgateway Attachment Module**

Terraform module to create Transitgateway Attachment on AWS

# **Description**
 
 This module is basically used to create Transitgateway Attachment on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `transit_gateway_id`,`attachment_vpc_id`,`subnet_ids`,`attachment_dns_support`,`attachment_default_route_table_association`,`attachment_default_route_table_propagation`,`attach_vpc`  etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_transit_gateway_id"></a>[transit\_gateway\_id](#input\_transit\_gateway_id) | Transit Gateway ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_attachment_vpc_id"></a>[attachment\_vpc\_id](#input\_attachment\_vpc\_id) | Attachment vpc IDS | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | List of Subnet ids | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_attachment_dns_support"></a>[attachment\_dns\_support](#input\_attachment\_dns\_support) | Attachment DNS Support | `bool` | No | true | `true` |
| <a name = "input_attachment_ipv6_support"></a>[attachment\_ipv6\_support](#input\_attachment\_ipv6\_support) | Attachment ipv6 Support | `bool` | No | false | `false` |
| <a name = "input_attachment_appliance_mode_support"></a>[attachment\_appliance\_mode\_support](#input\_attachment\_appliance\_mode\_support) | Attachment Appliance Mode Support | `bool` | No | false | `false` |
| <a name = "input_attachment_default_route_table_association"></a>[attachment\_default\_route\_table\_association](#input\_attachment\_default\_route\_table\_association) | Attachment Default Route Table Association | `bool` | No | true | `true` |
| <a name = "input_attachment_default_route_table_propagation"></a>[attachment\_default\_route\_table\_propagation](#input\_attachment\_default\_route\_table\_propagation) | Attachment Default Route Table Propagation | `bool` | No | true | `true` |
| <a name = "input_peer_account_id"></a>[peer\_account\_id](#input\_peer\_account\_id) | peer_account_id for peering attachment | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_peer_region"></a>[peer_region](#input\_peer_region) | Peer region for peering attachment | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_vpn_connection_id"></a>[vpn\_connection\_id](#input\_vpn\_connection\_id) | vpn connection id for vpn attachment | `string` | No | null | `"input vpn connection id"` |
| <a name = "input_transport_attachment_id"></a>[transport\_attachment\_id](#input\_transport\_attachment\_id) | Attachment VPC IDS | `string` | No | null | `"tgw-attch-123456"` |
| <a name = "input_peer_transit_gateway_id"></a>[peer\_transit\_gateway\_id](#input\_peer\_transit\_gateway\_id) | Peer Transir Gateway ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_attach_vpc"></a>[attach\_vpc](#input\_attach\_vpc) | Attach VPC | `bool` | No | false | `false` |
| <a name = "input_attach_peer_transit_gateway"></a>[attach\_peer\_transit\_gateway](#input\_attach\_peer\_transit\_gateway) | Attach Peer Trasnit Gateway | `bool` | No | false | `false` |
| <a name = "input_attach_vpn"></a>[attach\_vpn](#input\_attach\_vpn) | Attach VPN | `bool` | No | false | `false` |
| <a name = "input_connect_transport_attachment"></a>[connect\_transport\_attachment](#input\_connect\_transport\_attachment) | Connect Transport Attachment | `bool` | No | false | `false` |

| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "transitgatewayattachment" {
  source                                     = "tfe.axisb.com/ax-tfe/transitgatewayattachment/aws"
  version                                    = "X.X.X"

  transit_gateway_id                         = "tgw-7yu3h3yyee83ueu3ji"
  attachment_vpc_id                          = "vpc-8uh3e38u8eu3is1c"
  subnet_ids                                 = ["subnet-387e3uy37yh3usa","subnet-op2e3uy37yh3usa"]
  attachment_dns_support                     = true
  attachment_ipv6_support                    = false
  attachment_appliance_mode_support          = false
  attachment_default_route_table_association = true
  attachment_default_route_table_propagation = true
  attach_vpc                                 = true
  attach_peer_transit_gateway                = false
  attach_vpn                                 = false
  connect_transport_attachment               = false

  tags                                       = {
                                                Name = "Test"
                                               }
}

```