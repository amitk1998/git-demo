# **AWS EC2 Module**

Terraform module to create Elastic Compute Cloud on AWS

# **Description**
 
 This module is basically used to create Elastic Compute Cloud on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `create_ec2`,`ec2_availability_zone`,`ec2_subnet_id`,`ec2_instance_profile_name`,`ec2_ssh_key_name`,`ec2_vpc_security_group_ids`,`ec2_associate_public_ip_address`,`ec2_tenancy`,`ec2_instance_type`,`ec2_monitoring`,`ec2_ami`,`kms_key_arn`,`ec2_root_block_device` etc.

 # **Variable Defination**
 ``

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_jump_server_root_block_device"></a>[jump_server\_root\_block\_device](#input\_jump\_server\_root\_block\_device) | Create Jump Server | `string` | No | null | `` |

| <a name = "input_jump_server_root_block_device"></a>[jump\_server\_root\_block\_device](#input\_jump\_server\_root\_block\_device) | Customize details about the root block device of the instance | <pre><code>object({<br> encrypted   = bool<br> delete_on_termination = bool<br> iops = number<br> volume_size = number<br> volume_type = string<br> throughput = string<br> })</code></pre> | No | <pre><code>{<br> encrypted = false<br> delete_on_termination = false<br> iops = null<br> volume_size = null<br> volume_type = null<br> throughput = null<br> }</code></pre> | <pre><code>{<br> encrypted = false<br> delete_on_termination = false<br> iops = null<br> volume_size = null<br> volume_type = null<br> throughput = null<br> }</code></pre> |
| <a name = "input_jump_server_ami"></a>[jump\_server\_ami](#input\_jump\_server\_ami) | ID of AMI to use for the instance | `string` | No | null | `"ami-xxxxxxxxxxxx"` |
| <a name = "input_jump_server_availability_zone"></a>[jump\_server\_availability\_zone](#input\_jump\_server\_availability\_zone) | AZ to start the instance in | `string` | No | null | `"ap-south-1"` |
| <a name = "input_jump_server_instance_type"></a>[jump\_server\_instance\_type](#input\_jump\_server\_instance\_type) | The type of instance to start | `string` | No | null | `"t2.micro"` |
| <a name = "input_jump_server_ebs_optimized"></a>[jump\_server\_ebs\_optimized](#input\_jump\_server\_ebs\_optimized) | If true, the launched EC2 instance will be EBS-optimized | `bool` | No | null | `false` |
| <a name = "input_jump_server_instance_profile_name"></a>[jump\_server\_instance\_profile\_name](#input\_jump\_server\_instance\_profile\_name) | IAM Instance Profile to launch the instance with. Specified as the name of the Instance Profile | `string` | No | null | `"example-profile"` |
| <a name = "input_jump_server_associate_public_ip_address"></a>[jump\_server\_associate\_public\_ip\_address](#input\_jump\_server\_associate\_public\_ip\_address) | Whether to associate a public IP address with an instance in a VPC | `bool` | No | false | `false` |
| <a name = "input_jump_server_subnet_id"></a>[jump\_server\_subnet\_id](#input\_jump\_server\_subnet\_id) | The VPC Subnet ID to launch in | `string` | No | null | `"subnet-3uudj8u8u1hbh"` |
| <a name = "input_jump_server_vpc_security_group_ids"></a>[jump\_server\_vpc\_security\_group\_ids](#input\_jump\_server\_vpc\_security\_group_ids) | A list of security group IDs to associate with | `list(string)` | No | null | `["sg-76y47grfhvdsd"]` |
| <a name = "input_jump_server_private_ip"></a>[jump\_server\_private\_ip](#input\_jump\_server\_private\_ip) | Private IP address to associate with the instance in a VPC | `string` | No | null | `"input your private ips here"` |
| <a name = "input_jump_server_ssh_key_name"></a>[jump\_server\_ssh\_key\_name](#input\jump\_server\_ssh\_key\_name) | SSH Key name | `string` | No | null | `"example-ssh-key"` |
| <a name = "input_jump_server_monitoring"></a>[jump\_server\_monitoring](#input\_jump\_server\_monitoring) | If true, the launched EC2 instance will have detailed monitoring enabled | `bool` | No | false | `false` |
| <a name = "input_jump_server_hibernation"></a>[jump\_server\_hibernation](#input\_jump\_server\_hibernation) | If true, the launched EC2 instance will support hibernation | `bool` | No | null | `false` |
| <a name = "input_jump_server_user_data_replace_on_change"></a>[jump\_server\_user\_data\_replace\_on\_change](#input\_jump\_server\_user\_data\_replace\_on\_change) | When used in combination with user_data or user_data_base64 will trigger a destroy and recreate when set to true. Defaults to false if not set | `bool` | No | null | `false` |
| <a name = "input_jump_server_get_password_data"></a>[jump\_server\_get\_password\_data](#input\_jump\_server\_get\_password\_data) | If true, wait for password data to become available and retrieve it | `bool` | No | null | `false` |
| <a name = "input_jump_server_user_data"></a>[jump\\_server\_user\_data](#input\_jump\_server\_user\_data) | The user data to provide when launching the instance. Do not pass gzip-compressed data via this argument; see user_data_base64 instead | `string` | No | null | `"input jump server user data"` |
| <a name = "input_jump_server_tenancy"></a>[jump\_server\_tenancy](#input\_jump\_server\_tenancy) | The tenancy of the instance (if the instance is running in a VPC). Available values: default, dedicated, host | `string` | No | null | `"default"` |
| <a name = "input_jump_server_disable_api_stop"></a>[jump\_server\_disable\_api\_stop](#input\_jump\_server\_disable\_api\_stop) | If true, enables EC2 Instance Stop Protection | `bool` | No | null | `false` |
| <a name = "input_jump_server_disable_api_termination"></a>[jump\_server\_disable\_api\_termination](#input\_jump\_server\_disable\_api\_termination) | If true, enables EC2 Instance Termination Protection |`bool` | No | null | `false` |
| <a name = "input_jump_server_instance_initiated_shutdown_behavior"></a>[jump\_server\_instance\_initiated\_shutdown\_behavior](#input\_jump\_server\_instance\_initiated\_shutdown\_behavior) | Shutdown behavior for the instance. Amazon defaults this to stop for EBS-backed instances and terminate for instance-store instances. Cannot be set on instance-store instance | `string` | No | null | `"example-behaviour"` |
| <a name = "input_jump_server_placement_group"></a>[jump\_server\_placement\_group](#input\_jump\_server\_placement\_group) | The Placement Group to start the instance in | `string` | No | null | `"input placegroup for instance"` |
| <a name = "input_jump_server_host_id"></a>[jump\_server\_host\_id](#input\_jump\_server\_host\_id) | ID of a dedicated host that the instance will be assigned to. Use when an instance is to be launched on a specific dedicated host | `string` | No | null | `"input host id of the instance"` |
| <a name = "input_jump_server_host_resource_group_arn"></a>[jump\_server\_host\_resource\_group\_arn](#input\_jump\_server\_host\_resource\_group\_arn) | ARN of a dedicated host resource group | `string` | No | null | `"input host group arn here"` |
| <a name = "input_jump_server_use_launch_template"></a>[jump\_server\_use\_launch\_template](#input\_jump\_server\_use\_launch\_template) | Use Launch Template | `bool` | No | false | `false` |
| <a name = "input_jump_server_launch_template_id"></a>[jump\_server\_launch\_template\_id](#input\_jump\_server\_launch\_template\_id) | Launch Template ID | `string` | No | null | `"input launch template id"` |
| <a name = "input_jump_server_launch_template_version"></a>[jump\_server\_launch\_template\_version](#input\_jump\_server\_launch\_template\_version) | Launch Template Version | `string` | No | "$Latest" | `"$Latest"` |
| <a name = "input_jump_server_enable_auto_recovery"></a>[jump\_server\_enable\_auto\_recovery](#input\_jump\_server\_enable\_auto\_recovery) | jump_server_enable_auto_recovery | `bool` | No | false | `false` |
| <a name = "input_jump_server_enable_enclave_options"></a>[jump\_server\_enable\_enclave\_options](#input\_jump\_server\_enable\_enclave\_options) | Enable Enclave Options | `bool` | No | false | `false` |
| <a name = "input_jump_server_volume_tags"></a>[jump\_server\_volume\_tags](#input\_jump\_server\_volume\_tags) | A mapping of tags to assign to the resource | `map(string)` | No | { } | `{ "name"="test"}` |
| <a name = "input_create_ec2"></a>[create\_ec2](#input\_create\_ec2) | Create ec2 | `bool` | No | false | `false` |
| <a name = "input_ec2_root_block_device"></a>[ec2\_root\_block\_device](#input\_ec2\_root\_block\_device) | Customize details about the root block device of the instance | <pre><code>object({<br> encrypted = bool<br> delete_on_termination = bool<br> iops = number<br> volume_size = number<br> volume_type = string<br> throughput = string<br>  })</code></pre> | No | null | <pre><code>{<br> encrypted = false<br> delete_on_termination = false<br> iops = null<br> volume_size = null<br> volume_type = null<br> throughput = null<br>  }</code></pre> |
| <a name = "input_ec2_ami"></a>[ec2\_ami](#input\_ec2\_ami) | ID of AMI to use for the instance | `string` | No | null | `"input your ec2 ami"` |
| <a name = "input_ec2_availability_zone"></a>[ec2\_availability\_zone](#input\_ec2\_availability\_zone) | AZ to start the instance in | `string` | No | null | `"ap-south-1"` |
| <a name = "input_ec2_instance_type"></a>[ec2\_instance\_type](#input\_ec2\_instance\_type) | The type of instance to start | `string` | No | null | `"t2.micro"` |
| <a name = "input_ec2_ebs_optimized"></a>[ec2\_ebs\_optimized](#input\_ec2\_ebs\_optimized) | If true, the launched EC2 instance will be EBS-optimized | `bool` | No | null | `false` |
| <a name = "input_ec2_instance_profile_name"></a>[ec2\_instance\_profile\_name](#input\_ec2\_instance\_profile\_name) | IAM Instance Profile to launch the instance with. Specified as the name of the Instance Profile | `string` | No | null | `"example-profile"` |
| <a name = "input_ec2_associate_public_ip_address"></a>[ec2\_associate\_public\_ip\_address](#input\_ec2\_associate\_public\_ip\_address) | Whether to associate a public IP address with an instance in a VPC | `bool` | No | null | `false` |
| <a name = "input_ec2_subnet_id"></a>[ec2\_subnet\_id](#input\_ec2\_subnet\_id) | The VPC Subnet ID to launch in | `string` | No | null | `"subnet-7648yrhbdnwk348"` |
| <a name = "input_ec2_vpc_security_group_ids"></a>[ec2\_vpc\_security\_group\_ids](#input\_ec2\_vpc\_security\_group\_ids) | A list of security group IDs to associate with | `list(string)` | No | [ ] | `["sg-874r7yuhbdjnop"]` |
| <a name = "input_ec2_private_ip"></a>[ec2\_private\_ip](#input\_ec2\_private\_ip) | Private IP address to associate with the instance in a VPC | `string` | No | null | `"100.0.0.64"` |
| <a name = "input_ec2_ssh_key_name"></a>[ec2\_ssh\_key\_name](#input\_ec2\_ssh\_key\_name) | SSH Key name | `string` | No | null | `"example-ssh-key"` |
| <a name = "input_ec2_monitoring"></a>[ec2\_monitoring](#input\_ec2\_monitoring) | If true, the launched EC2 instance will have detailed monitoring enabled | `bool` | No | false | `false` |
| <a name = "input_ec2_hibernation"></a>[ec2\_hibernation](#input\_ec2\_hibernation) | If true, the launched EC2 instance will support hibernation | `bool` | No | null | `false` |
| <a name = "input_ec2_user_data_replace_on_change"></a>[ec2\_user\_data\_replace\_on\_change](#input\_ec2\_user\_data\_replace\_on\_change) | When used in combination with user_data or user_data_base64 will trigger a destroy and recreate when set to true. Defaults to false if not set | `bool` | No | null | `false` |
| <a name = "input_ec2_get_password_data"></a>[ec2\_get\_password\_data](#input\_ec2\_get\_password\_data) | Description | `bool` | No | null | `false` |
| <a name = "input_ec2_user_data"></a>[ec2\_user\_data](#input\_ec2\_user\_data) | The user data to provide when launching the instance. Do not pass gzip-compressed data via this argument; see user_data_base64 instead | `string` | No | null | `"input-desired-user-data"` |
| <a name = "input_ec2_tenancy"></a>[ec2\_tenancy](#input\_ec2\_tenancy) | The tenancy of the instance (if the instance is running in a VPC). Available values: default, dedicated, host | `string` | No | null | `"default"` |
| <a name = "input_ec2_disable_api_stop"></a>[ec2\_disable\_api\_stop](#input\_ec2\_disable\_api\_stop) | If true, enables EC2 Instance Stop Protection | `bool` | No | null | `false` |
| <a name = "input_ec2_disable_api_stop"></a>[ec2\_disable\_api\_stop](#input\_ec2\_disable\_api\_stop) | If true, enables EC2 Instance Stop Protection | `bool` | No | null | `false` | 
| <a name = "input_ec2_disable_api_termination"></a>[ec2\_disable\_api\_termination](#input\_ec2\_disable\_api\_termination) | If true, enables EC2 Instance Termination Protection | `bool` | No | null | `false` |
| <a name = "input_ec2_instance_initiated_shutdown_behavior"></a>[ec2\_instance\_initiated\_shutdown_\behavior](#input\_ec2\_instance\_initiated\_shutdown\_behavior) | Shutdown behavior for the instance. Amazon defaults this to stop for EBS-backed instances and terminate for instance-store instances. Cannot be set on instance-store instance" | `string` | No | null | `"input shutdown behaviour for the instance"` |
| <a name = "input_ec2_placement_group"></a>[ec2\_placement\_group](#input\_ec2\_placement\_group) | The Placement Group to start the instance in | `string` | No | null | `"input desired placegroup"` |
| <a name = "input_ec2_host_id"></a>[ec2\_host\_id](#input\_ec2\_host\_id) | ID of a dedicated host that the instance will be assigned to. Use when an instance is to be launched on a specific dedicated host | `string` | No | null | `"input instance host id"` |
| <a name = "input_ec2_host_resource_group_arn"></a>[ec2\_host\_resource\_group\_arn](#input\_ec2\_host\_resource\_group\_arn) | ARN of a dedicated host resource group | `string` | No | null | `"input instance resource group arn"` |
| <a name = "input_ec2_host_resource_group_arn"></a>[ec2\_host\_resource\_group\_arn](#input\_ec2\_host\_resource\_group\_arn) | ARN of a dedicated host resource group | `string` | No | null | `"input host resource group arn"` |
| <a name = "input_ec2_use_launch_template"></a>[ec2_use_launch_template](#input\_ec2_use_launch_template) | Description | `bool` | No | false | `false` |
| <a name = "input_ec2_launch_template_id"></a>[ec2\_launch\_template\_id](#input\_ec2\_launch\_template\_id) | Launch Template ID | `string` | No | null | `"input launch template id"` |
| <a name = "input_ec2_launch_template_version"></a>[ec2\_launch\_template\_version](#input\_ec2\_launch\_template\_version) | Launch Template Version | `string` | No | "$Latest" | `"$Latest"` |
| <a name = "input_ec2_enable_auto_recovery"></a>[ec2_enable\_auto\_recovery](#input\_ec2\_enable\_auto\_recovery) | Description | `bool` | No | false | `false` |
| <a name = "input_ec2_enable_enclave_options"></a>[ec2\_enable\_enclave\_options](#input\_ec2\_enable\_enclave\_options) | Enable Enclave Options | `bool` | No | false | `false` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | KMS KEY ARN | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"` |
| <a name = "input_ec2_volume_tags"></a>[ec2\_volume\_tags](#input\_ec2\_volume\_tags) | A mapping of tags to assign to the resource | `map(string)` | No | { } | `{{ "name"="test" }}` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ec2" {
  source                          = "tfe.axisb.com/ax-tfe/ec2/aws"
  version                         = "X.X.X"

  create_ec2                      = true
  ec2_availability_zone           = "ap-south-1"
  ec2_subnet_id                   = "subnet-74yduegdevd37y"
  ec2_instance_profile_name       = "example-profile"
  ec2_ssh_key_name                = "Test-Poc-Ssh"
  ec2_vpc_security_group_ids      = ["sg-87yi3ehde99jejn"]
  ec2_associate_public_ip_address = false
  ec2_tenancy                     = "default"
  ec2_instance_type               = "t2.micro"
  ec2_monitoring                  = true
  ec2_ami                         = "ami-0fb974a4772b174a5"      
  kms_key_arn                     = "arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  ec2_root_block_device           = {
    encrypted                     = true
    delete_on_termination         = true
    iops                          = "gp3"
    throughput                    = 50
    volume_size                   = 20
    volume_type                   = "gp3"
  }

  tags                            = {
                                     Name = "Test"
                                    }

  ec2_volume_tags                 = {
                                    Name = "Test-Volume"
                                    }

}

```