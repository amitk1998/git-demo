# **AWS Athena Module**

Terraform module to create Athena on AWS

# **Description**
 
 This module is basically used to create Athena on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `database_name`,`s3bucket_id`,`encryption_option`,`kms_key`,`query_name`,`description`,`query`,`workgroup_name`,`output_location`,`query_output_buckets_kms_key`,`catalog_name`,`catalog_description`,`type_data_catalog`,`parameters` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create_database"></a>[create\_database](#input\_create\_database) | Boolean flag to create the Athena database | `bool` | No | true | `true` |
| <a name = "input_database_name"></a>[database\_name](#input\_database\_name) | Name of the Athena database | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_s3bucket_id"></a>[s3bucket\_id](#input\_s3bucket\_id) | Name of the S3 bucket for Athena | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_database_force_destroy"></a>[database\_force\_destroy](#input\_database\_force\_destroy) | Flag to force destroy the Athena database | `bool` | No | false | `false` |
| <a name = "input_encryption_option"></a>[encryption\_option](#input\_encryption\_option) | Encryption option for the Athena database, possible values are SSE_S3, SSE_KMS, CSE_KMS | `string` | No | "SSE_KMS" | `"SSE_KMS"` |
| <a name = "input_kms_key"></a>[kms\_key](#input\_kms\_key) | KMS key ARN for Athena database encryption | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"` |
| <a name = "input_query_name"></a>[query\_name](#input\_query\_name) | Name of the Athena named query | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_description"></a>[description](#input\_description) | Description for the Athena named query | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_query"></a>[query](#input\_query) | SQL query for the Athena named query | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_workgroup_name"></a>[workgroup\_name](#input\_workgroup\_name) | Name of the Athena workgroup | `string` | No | "primary" | `"primary"` |
| <a name = "input_state"></a>[state](#input\_state) | State of the Athena workgroup | `string` | No | "ENABLED" | `"ENABLED"` |
| <a name = "input_force_destroy"></a>[force\_destroy](#input\_force\_destroy) | Flag to force destroy the Athena workgroup | `bool` | No | false | `false` |
| <a name = "input_enforce_workgroup_configuration"></a>[enforce\_workgroup\_configuration](#input\_enforce\_workgroup\_configuration) | Flag to enforce workgroup configuration | `bool` | No | true | `true` |
| <a name = "input_query_output_buckets_kms_key"></a>[query\_output\_buckets\_kms_key](#input\_query\_output\_buckets\_kms_key) | Query output bucket KMS key | `string` | No | null | `"input query output bucket kms key"` |
| <a name = "input_output_location"></a>[output\_location](#input\_output\_location) | Query output Location | `string` | No | null | `"input output locaation"` |
| <a name = "input_create_catalog"></a>[create_catalog](#input\_create_catalog) | Flag to to create  athena catalog | `bool` | No | false | `false` |
| <a name = "input_catalog_name"></a>[catalog\_name](#input\_catalog\_name) | Name  for te athena Catalog | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_type_data_catalog"></a>[type\_data\_catalog](#input\_type\_data\_catalog) | Type for te athena Catalog | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_catalog_description"></a>[catalog\_description](#input\_catalog\_description) | Description  for te athena Catalog | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_parameters"></a>[parameters](#input\_parameters) | Typee for te athena Catalog | `map(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "athena" {
  source                       = "tfe.axisb.com/ax-tfe/athena/aws"
  version                      = "X.X.X"

  create_database              = true
  database_name                = "tfe_athena_database"
  s3bucket_id                  = "example-bucket-597"
  encryption_option            = "SSE_S3"
  kms_key                      =  "arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"
  query_name                   = "tfe_athena_query"
  description                  = "executing query through "
  query                        =  "create table my_tfe_table(id INT,name STRING)LOCATION's3://${example-bucket-597}/output"
  workgroup_name               = "tfe_Athena_workgroup"
  output_location              = "s3://${example-bucket-597}/output"
  query_output_buckets_kms_key = "arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"
  
  tags                         = {
                                  Name = "Test"
                                  }

}

module "athena_catalog" {
  source                      = "tfe.axisb.com/ax-tfe/athena/aws"
  version                     = "X.X.X"

  create_catalog              = true
  create_database             = false
  catalog_name                = "tfe_athena_catalog"
  catalog_description         = "athena catalog through terraform"
  type_data_catalog           = "LAMBDA"
  parameters                  = {
                                "function" = "arn:aws:lambda:ap-south-1:1234567890:function:test_lambda_poc_fun"
                                }

    tags                      = {
                                 Name = "Test"
                                }

}


```