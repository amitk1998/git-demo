#!/bin/bash -ex

set -o xtrace
CLUSTER_NAME=${eks_cluster_name}
API_ENDPOINT=${eks_api_endpoint}
CLUSTER_CERT=${eks_cluster_cert}
sudo /etc/eks/bootstrap.sh $CLUSTER_NAME --apiserver-endpoint $API_ENDPOINT --b64-cluster-ca $CLUSTER_CERT --dns-cluster-ip 172.20.0.10 --use-max-pods true
sudo sh -c "echo Environment='KUBELET_SYSTEM_PODS_ARGS=--read-only-port=0 --streaming-connection-idle-timeout=5m --protect-kernel-defaults=true --make-iptables-util-chains=true --event-qps=0' >> /etc/systemd/system/kubelet.service.d/10-kubelet-args.conf"
sudo systemctl daemon-reload
sudo service kubelet restart
sudo systemctl restart network