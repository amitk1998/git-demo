#!/bin/bash -ex

set -o xtrace
CLUSTER_NAME=${eks_cluster_name}
API_ENDPOINT=${eks_api_endpoint}
CLUSTER_CERT=${eks_cluster_cert}
#Copy files from S3
aws s3 cp s3://axawssharedservices/worker-node-certs/root.cer ./
aws s3 cp s3://axawssharedservices/worker-node-certs/audit.rules ./
aws s3 cp s3://axawssharedservices/worker-node-certs/limits.conf ./
aws s3 cp s3://axawssharedservices/worker-node-certs/ntp.conf ./
aws s3 cp s3://axawssharedservices/worker-node-certs/pwquality.conf ./
aws s3 cp s3://axawssharedservices/worker-node-certs/sshd_config ./
aws s3 cp s3://axawssharedservices/worker-node-certs/sysctl.conf ./
aws s3 cp s3://axawssharedservices/worker-node-certs/useradd.sh ./
sudo aws s3 cp s3://axawssharedservices/worker-node-certs/DCS/agent64-linux-amzn2.bin ./
sudo aws s3 cp s3://axawssharedservices/worker-node-certs/DCS/agent-cert-prd.ssl ./
sudo aws s3 cp s3://axawssharedservices/worker-node-certs/DCS/sdcss-kmod-latest.amzn2.x86_64.rpm ./
#Replace files on relevant location
sudo cp ./root.cer /etc/pki/ca-trust/source/anchors/
sudo cp ./audit.rules /etc/audit/rules.d/
sudo cp ./limits.conf /etc/security/limits.conf
sudo cp ./ntp.conf /etc/ntp.conf
sudo cp ./pwquality.conf /etc/security/pwquality.conf
sudo cp ./sshd_config /etc/ssh/sshd_config
sudo cp ./sysctl.conf /etc/sysctl.conf
sudo cp ./useradd.sh /tmp/
sudo mv ./agent64-linux-amzn2.bin /tmp/
sudo mv ./agent-cert-prd.ssl /tmp/
sudo mv ./sdcss-kmod-latest.amzn2.x86_64.rpm /tmp/
#Restart services
sudo update-ca-trust extract
sudo service auditd restart
sudo systemctl restart sshd
#change Access Level
chmod 600 /etc/crontab
chmod 600 /etc/cron.hourly/
chmod 600 /etc/cron.daily/
chmod 600 /etc/cron.weekly/
chmod 600 /etc/cron.monthly/
chmod 600 /etc/cron.d/
chmod 777 /tmp/useradd.sh
#Run useradd script
sh /tmp/useradd.sh
#Remediation commands
sed -i 's/-F 2/-u chrony/g' /etc/sysconfig/chronyd
yum remove xorg-x11*
mv /etc/cron.deny /etc/cron.deny_$(date +%d%m%Y)
sed -i 's/PASS_MAX_DAYS\s*99999/PASS_MAX_DAYS 90/g' /etc/login.defs
sed -i 's/PASS_MIN_DAYS\s*0/PASS_MIN_DAYS 7/g' /etc/login.defs
sed -i 's/022/027/g' /etc/bashrc
sed -i 's/002/027/g' /etc/bashrc
sed -i 's/002/027/g' /etc/profile
sed -i 's/022/027/g' /etc/profile
# Updating rsyslog configuration
sudo bash -c "echo 'authpriv.* @10.9.121.68:514' >> /etc/rsyslog.conf"
sudo bash -c "echo 'auth.*;user.*;syslog.* @10.9.121.68:514' >> /etc/rsyslog.conf"
sudo systemctl restart rsyslog
sudo id ec2-user
# Updating Timezone & adding on premise ntp servers.
sudo timedatectl set-timezone Asia/Kolkata
sudo bash -c "echo 'server 10.0.30.50 prefer iburst minpoll 4 maxpoll 4' >> /etc/chrony.conf"
sudo bash -c "echo 'server 10.9.80.254 prefer iburst minpoll 4 maxpoll 4' >> /etc/chrony.conf"
sudo sed -i 's/prefer.*//g' /etc/chrony.d/link-local.sources
sudo systemctl restart chronyd
sudo /etc/eks/bootstrap.sh $CLUSTER_NAME --apiserver-endpoint $API_ENDPOINT --b64-cluster-ca $CLUSTER_CERT --dns-cluster-ip 172.20.0.10 --use-max-pods true
sudo sh -c "echo Environment='KUBELET_SYSTEM_PODS_ARGS=--read-only-port=0 --streaming-connection-idle-timeout=5m --protect-kernel-defaults=true --make-iptables-util-chains=true --event-qps=0' >> /etc/systemd/system/kubelet.service.d/10-kubelet-args.conf"
sudo systemctl daemon-reload
sudo service kubelet restart
sudo systemctl restart network
#Adding users to sudoers
sudo sed -i '100 a axawsroot    ALL=(ALL)       ALL' /etc/sudoers
sudo sed -i '101 a ccsadmin    ALL=(ALL)       ALL' /etc/sudoers
sudo sed -i '111 a ccsadmin        ALL=(ALL)       NOPASSWD: ALL' /etc/sudoers
sudo sed -i '112 a axawsroot        ALL=(ALL)       NOPASSWD: ALL' /etc/sudoers
#Install Openssh 9.3p1
aws s3 cp s3://axawssharedservices/worker-node-certs/openssh-9.3p1.tar.gz ./
sudo yum install gcc -y
sudo yum install openssl-devel -y
sudo yum install zlib-devel -y
sudo yum install mlocate -y
sudo yum install autoconf -y    
sudo tar zxvf openssh-9.3p1.tar.gz
cd openssh-9.3p1 && ./configure && make && sudo make install
sudo systemctl restart sshd.service
#DCS installation
sudo chmod 777 /tmp/agent64-linux-amzn2.bin
sudo chmod 777 /tmp/agent-cert-prd.ssl
sudo chmod 777 /tmp/sdcss-kmod-latest.amzn2.x86_64.rpm
sudo yum install zip -y
sudo yum install at -y
sudo /tmp/agent64-linux-amzn2.bin -silent -prefix=/opt/Symantec -server=10.9.9.58 -cert=/tmp/agent-cert-prd.ssl -agentport=443
sudo yum install /tmp/sdcss-kmod-latest.amzn2.x86_64.rpm -y
sudo su - sisips
./sisipsconfig.sh -forcereg
./sisipsconfig.sh -ipsstate on
/sisipsconfig.sh -t