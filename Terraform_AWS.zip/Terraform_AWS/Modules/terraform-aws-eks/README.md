# **AWS  Module**

Terraform module to create EKS on AWS

# **Description**
 
 This module is basically used to create EKS on Amazon Web Services(AWS).
 It requires following attributes in order to be created on AWS like `region`,`environment`,`account_id`,`eks_version`,`eks_cluster_subnet_ids`,`eks_cluster_endpoint_private_access`,`eks_cluster_endpoint_public_access`,`public_access_cidrs`,`eks_cluster_ip_family`,`eks_enabled_cluster_log_types`,`eks_cluster_tags`,`custom_networking_enabled`,`eks_node_group_subnet_ids`,`eks_node_group_desired_size`,`eks_node_group_max_size`,`eks_node_group_min_size`,`eks_node_group_capacity_type`,`eks_node_group_max_unavailable`,`ec2_ssh_key_name`,`kms_key_arn`,`kms_key_alias_name`,`launch_template_device_name`,`launch_template_volume_size`,`launch_template_instance_type`,`launch_template_image_id`,`addon_version`,`vpc_id`,`prefix_list_ids_for_eks_inbound`,`linux_jump_sg_id`,`kube_config_map_iam_role_arns`,`enable_sqs`,`jenkins_centrallized_role`,`eks_pod_subnet_details`,`additional_policies`,`aws_lb_controller_endpoint`,`aws_lb_cainjector_endpoint`,`aws_lb_cacontroller_endpoint`,`aws_lb_cawebhook_endpoint`,`karpenter_inflate_endpoint`,`karpenter_controller_endpoint`,`fluentbit_endpoint`,`docker_server_url`,`docker_username`,`docker_password`,`repository_username`,`repository_password`,`jsm_ticket_id` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_region"></a>[region](#input\_region) | Region | `string` | Yes | `N/A` | `"ap-south-1"` |
| <a name = "input_account_id"></a>[account\_id](#input\_account\_id) | Account id | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_environment"></a>[environment](#input\_environment) | Application Environment | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_name_prefix"></a>[name\_prefix](#input\_name\_prefix) | Name Suffix | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_jsm_ticket_id"></a>[jsm\_ticket\_id](#input\_jsm\_ticket\_id) | JSM Ticket ID | `string` | No | null | `"input jsm ticket id"` |
| <a name = "input_eks_version"></a>[eks\_version](#input\_eks\_version) | EKS version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_eks_cluster_subnet_ids"></a>[eks\_cluster\_subnet\_ids](#input\_eks\_cluster\_subnet\_ids) | Subnet Ids to be used in EKS Cluster | `list(string)` | No | [ ] | `["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]` |
| <a name = "input_eks_cluster_endpoint_private_access"></a>[eks\_cluster\_endpoint\_private\_access](#input\_eks\_cluster\_endpoint\_private\_access) | EKS Endpoint Private Access | `bool` | No | true | `true` |
| <a name = "input_eks_cluster_endpoint_public_access"></a>[eks\_cluster\_endpoint\_public\_access](#input\_eks\_cluster\_endpoint\_public\_access) | EKS Endpoint Public Access | `bool` | No | false | `false` |
| <a name = "input_public_access_cidrs"></a>[public\_access\_cidrs](#input\_public\_access\_cidrs) | List of public access Cidrs for EKS Cluster | `list(string)` | No | [ ] | `[ ]` |
| <a name = "input_eks_cluster_ip_family"></a>[eks\_cluster\_ip\_family](#input\_eks\_cluster\_ip\_family) | Ip Family to be used for EKS Cluster | `string` | No | "ipv4" | `"ipv4"` |
| <a name = "input_eks_encryption_resource_type"></a>[eks\_encryption\_resource\_type](#input\_eks\_encryption\_resource\_type) | EKS Encryption Resource type | `list(string)` | No |  ["secrets"] | ` ["secrets"]` |
| <a name = "input_eks_enabled_cluster_log_types"></a>[eks\_enabled\_cluster\_log\_types](#input\_eks\_enabled\_cluster\_log\_types) | EKS enabled cluster log types | `list(string)` | No | [ ] | `["api", "audit", "authenticator", "controllerManager", "scheduler"]` |
| <a name = "input_eks_cluster_tags"></a>[eks\_cluster\_tags](#input\_eks\_cluster\_tags) | Tags for Eks Cluster | `map(string)` | No | { } | `{ }` |
| <a name = "input_ec2_ssh_key_name"></a>[ec2\_ssh\_key\_name](#input\_ec2\_ssh\_key\_name) | SSH Key Name for Launch Template | `string` | No | null | `"Example-Key"` |
| <a name = "input_kube_config_map_iam_role_arns"></a>[kube\_config\_map\_iam\_role\_arns](#input\_kube\_config\_map\_iam\_role\_arns) | Kubernetes Kube Config Map IAM Role Arn for EKS Access | `list(string)` | No | [ ] | `["arn:aws:iam::123456789:role/AXAWS-SHARED_SERVICES-DEVSECOPS-PROD-EKS-OIDC-Role"]` |
| <a name = "input_eks_node_group_specifications"></a>[eks\_node\_group\_specifications](#input\_eks\_node\_group\_specifications) | EKS Node Group Specifications | <pre><code>list(object({<br> eks_node_group_subnet_ids                   = list(string)<br> eks_node_group_desired_size                 = number<br> eks_node_group_max_size                     = number<br> eks_node_group_min_size                     = number<br> eks_node_group_max_unavailable              = optional(number, 1)<br> eks_node_group_capacity_type                = optional(string, "ON_DEMAND")<br> eks_node_group_labels                       = optional(map(string), {})<br> eks_node_group_taint                        = optional(list(object({<br> key = string<br> value = string<br> effect = string<br> })),[])<br> force_update_version                        = optional(bool, null)<br> launch_template_device_name                 = optional(string, null)<br> launch_template_volume_size                 = optional(number, null)<br> launch_template_volume_type                 = optional(string, null)<br> launch_template_instance_type               = optional(string, null)<br> launch_template_image_id                    = optional(string, null)<br> launch_template_image_name                  = optional(string, null)<br> launch_template_image_owner                 = optional(string, null)<br> launch_template_image_type                  = optional(string, "MANAGED")<br> launch_template_http_put_response_hop_limit = optional(number, null)<br> launch_template_ebs_iops                    = optional(number, null)<br> launch_template_ebs_throughput              = optional(number, null)<br> launch_template_resource_type               = optional(string, "instance")<br> launch_template_tags                        = optional(map(string), {})<br> eks_worker_node_tags                        = optional(map(string), {})<br> eks_worker_node_sg_tags                     = optional(map(string), {})<br> eks_worker_role_tags                        = optional(map(string), {})<br> }))</code></pre> | Yes | [ ] |  <pre><code>[<br> {<br> eks_node_group_subnet_ids                   = ["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]<br> eks_node_group_desired_size                 = 3<br> eks_node_group_max_size                     = 4<br> eks_node_group_min_size                     = 3<br> eks_node_group_max_unavailable              = 1<br> eks_node_group_capacity_type                = "ON_DEMAND"<br> eks_node_group_labels                       = {}<br> eks_node_group_taint                        = []<br> force_update_version                        = null<br> launch_template_device_name                 = "/dev/xvda"<br> launch_template_volume_size                 = 300<br> launch_template_volume_type                 = "gp3"<br> launch_template_instance_type               = "m6a.2xlarge"<br> launch_template_image_id                    = "ami-0d794e65fc87b4b13"<br> launch_template_image_name                  = null<br> launch_template_image_owner                 = "123456789"<br> launch_template_image_type                  = "MANAGED"<br> launch_template_http_put_response_hop_limit = 2<br> launch_template_ebs_iops                    = null<br> launch_template_ebs_throughput              = null<br> launch_template_resource_type               = "instance"<br> launch_template_tags                        = {}<br> eks_worker_node_tags                        = {}<br> eks_worker_node_sg_tags                     = {}<br> eks_worker_role_tags                        = {}<br> }<br>]</code></pre> |
| <a name = "input_add_addons"></a>[add\_addons](#input\_add\_addons) | Condition for adding EKS addons | `bool` | No | true | `true` |
| <a name = "input_addon_version"></a>[addon\_version](#input\_addon\_version) | Specific Desired version for EKS Cluster addons | `list(string)` | No | [ ] | `["v1.12.6-eksbuild.2", "v1.22.0-eksbuild.2", "v1.9.3-eksbuild.7", "v1.25.14-eksbuild.2"]` |
| <a name = "input_addon_name"></a>[addon\_name](#input\_addon\_name) | EKS Cluster Addon names | `string` | No | null | `["vpc-cni", "aws-ebs-csi-driver", "coredns", "kube-proxy"]` |
| <a name = "input_eks_cluster_addons_resolve_conflicts"></a>[eks\_cluster_addons\_resolve\_conflicts](#input\_eks\_cluster\_addons\_resolve\_conflicts) | EKS Cluster Addons Resolve Conflicts | `string` | No | "OVERWRITE" | `"OVERWRITE"` |
| <a name = "input_eks_cluster_addons_resolve_conflicts_on_update"></a>[eks\_cluster\_addons\_resolve\_conflicts\_on\_update](#input\_eks\_cluster\_addons\_resolve\_conflicts\_on\_update) | EKS Cluster Addons Resolve Conflicts On Update | `string` | No | "PRESERVE" | `"PRESERVE"` |
| <a name = "input_addon_tags"></a>[addon\_tags](#input\_addon\_tags) | Tags for Eks Worker Node addons | `map(string)` | No | { } | `{ }` |
| <a name = "input_kms_key_arn"></a>[kms\_key\_arn](#input\_kms\_key\_arn) | KMS Key Arn | `string` | No | null | `"input kms key arn"` |
| <a name = "input_kms_key_alias_name"></a>[kms\_key\_alias\_name](#input\_kms\_key\_alias\_name) | KMS Key Alias Name | `string` | No | null | `"alias/test-key-alias"` |
| <a name = "input_eks_log_group_retention_period"></a>[eks\_log\_group\_retention\_period](#input\_eks\_log\_group\_retention\_period) | Desc | `number` | No | 3 | `3` |
| <a name = "input_eks_log_group_skip_destroy"></a>[eks\_log\_group\_ski\p_destroy](#input\_eks\_log\_group\_skip\_destroy) | Eks Log Group Skip Destroy | `bool` | No | false | `false` |
| <a name = "input_vpc_id"></a>[vpc\_id](#input\_vpc\_id) | VPC ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_prefix_list_ids_for_eks_inbound"></a>[prefix\_list\_ids\_for\_eks\_inbound](#input\_prefix\_list\_ids\_for\_eks\_inbound) | Prefix list id for Jenkins | `list(string)` | No | [ ] | `["pl-072720d2dc516d34e", "pl-08be416e7a844e165"]` |
| <a name = "input_additional_sg_ids_to_attach"></a>[additional\_sg\_ids\_to\_attach](#input\_additional\_sg\_ids\_to\_attach) | Security Group ids to attach | `string` | No | [ ] | `["sg-38ey3h4847uu3e"]` |
| <a name = "input_eks_control_plane_sg_tags"></a>[eks\_control\_plane\_sg\_tags](#input\_eks_control_plane_sg_tags) | Tags for Eks Control Plan Security Group | `map(string)` | No | { } | `{ }` |
| <a name = "input_enable_dlq"></a>[enable\_dlq](#input\_enable\_dlq) | Enable DLQ | `bool` | No | false | `false` |
| <a name = "input_sqs_queue_kms_data_key_reuse_period_seconds"></a>[sqs\_queue\_kms\_data\_key\_reuse\_period\_seconds](#input\_sqs\_queue\_kms\_data\_key\_reuse\_period\_seconds) | SQS queue kms data key reuse period seconds | `number` | No | 300 | `300` |
| <a name = "input_sqs_managed_sse_enabled"></a>[sqs\_managed\_sse\_enabled](#input\_sqs\_managed\_sse\_enabled) | Enable SQS Managed SSE | `bool` | No | true | `true` |
| <a name = "input_sqs_message_retention_seconds"></a>[sqs\_message\_retention\_seconds](#input\_sqs\_message\_retention\_seconds) | SQS queue message retention period seconds | `number` | No | 300 | `300` |
| <a name = "input_sqs_tags"></a>[sqs\_tags](#input\_sqs\_tags) | Tags for Sqs | `map(string)` | No | { } | `{ }` |
| <a name = "input_eks_cluster_role_tags"></a>[eks\_cluster\_role\_tags](#input\_eks\_cluster\_role\_tags) | Tags for Eks Cluster Role | `map(string)` | No | { } | `{ }` |
| <a name = "input_eks_aws_lb_controller_role_tags"></a>[eks\_aws\_lb\_controller\_role\_tags](#input\_eks\_aws\_lb\_controller\_role\_tags) | Tags for EKS AWS LB Controller Role | `map(string)` | No | { } | `{ }` |
| <a name = "input_eks_karpenter_role_tags"></a>[eks\_karpenter\_role\_tags](#input\_eks\_karpenter\_role\_tags) | Tags for Eks Karpenter Role | `map(string)` | No | { } | `{ }` |
| <a name = "input_ebs_csi_driver_iam_role_tags"></a>[ebs\_csi\_driver\_iam\_role\_tags](#input\_ebs\_csi\_driver\_iam\_role\_tags) | Desc | `map(string)` | No | { } | `{ }` |
| <a name = "input_efs_csi_driver_iam_role_tags"></a>[efs\_csi\_driver\_iam\_role\_tags](#input\_efs\_csi\_driver\_iam\_role\_tags) | Tags for EFS CSI Driver Role | `map(string)` | No | { } | `{ }` |
| <a name = "input_jenkins_cross_account_iam_role_tags"></a>[jenkins\_cross\_account\_iam\_role\_tags](#input\_jenkins\_cross\_account\_iam\_role\_tags) | Tags for Jenkins Cross Account Role | `map(string)` | No | { } | `{ }` |
| <a name = "input_jenkins_centrallized_role"></a>[jenkins\_centrallized\_role](#input\_jenkins\_centrallized\_role) | Jenkins Centrallized Role | `string` | Yes | `N/A` | `"arn:aws:iam::123456789:role/AXAWS-SHARED_SERVICES-DEVSECOPS-PROD-EKS-OIDC-Role"` |
| <a name = "input_enable_efs"></a>[enable\_efs](#input\_enable\_efs) | Enable EFS | `bool` | No | false | `false` |
| <a name = "input_additional_policies"></a>[additional\_policies](#input\_additional\_policies) | Additional Policies to be Added to Worker Node Role | <pre><code>list(object({<br> name        = string<br> description = string<br> policy      = string<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name = "input_eks_pod_subnet_details"></a>[eks\_pod\_subnet\_details](#input\_eks\_pod\_subnet\_details) | EKS Pod Subnet Details | <pre><code>list(object({<br> subnet_id = string<br> availability_zone = string<br> }))</code></pre> | Yes | `N/A` | <pre><code>[<br> {<br> subnet_id = "subnet-b5yy3e10y3y2a"<br> availability_zone = "ap-south-1"<br> }<br>]</code></pre> |
| <a name = "input_docker_server_url"></a>[docker_server_url](#input\_docker_server_url) | Docker Server URL | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_docker_username"></a>[docker\_username](#input\_docker\_username) | Docker Username | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_docker_password"></a>[docker\_password](#input\_docker\_password) | Docker Password | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_enable_cert_manager_provisioning"></a>[enable\_cert\_manager\_provisioning](#input\_enable\_cert\_manager\_provisioning) | Enable Cert Manager Provisioning | `bool` | No | true | `true` |
| <a name = "input_cert_manager_cainjector_artifactory_image"></a>[cert\_manager\_cainjector\_artifactory\_image](#input\_cert\_manager\_cainjector\_artifactory\_image) | Cert Manager CA Injector Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_cert_manager_cacontroller_artifactory_image"></a>[cert\_manager\_cacontroller\_artifactory\_image](#input\_cert\_manager\_cacontroller\_artifactory\_image) | Cert Manager CA Controller Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_cert_manager_cawebhook_artifactory_image"></a>[cert\_manager\_cawebhook\_artifactory\_image](#input\_cert\_manager\_cawebhook\_artifactory\_image) | Cert Manager CA CA Webhook Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_enable_aws_lb_controller_provisioning"></a>[enable\_aws\_lb\_controller\_provisioning](#input\_enable\_aws\_lb\_controller\_provisioning) | Enable AWS Load Balancer Controller Provisioning | `bool` | No | true | `true` |
| <a name = "input_aws_lb_controller_artifactory_image"></a>[aws\_lb\_controller\_artifactory\_image](#input\_aws\_lb\_controller\_artifactory\_image) | AWS Load Balancer Controller Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_enable_karpenter_provisioning"></a>[enable\_karpenter\_provisioning](#input\_enable\_karpenter\_provisioning) | Enable Karpenter Provisioning | `bool` | No | true | `true` |
| <a name = "input_karpenter_controller_artifactory_image"></a>[karpenter\_controller\_artifactory\_image](#input\_karpenter\_controller\_artifactory\_image) | Karpenter Controller Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_enable_fluentbit_provisioning"></a>[enable\_fluentbit\_provisioning](#input\_enable\_fluentbit\_provisioning) | Enable Fluentbit Provisioning | `bool` | No | true | `true` |
| <a name = "input_fluentbit_artifactory_image"></a>[fluentbit\_artifactory\_image](#input\_fluentbit\_artifactory\_image) | Fluentbit Artificatory Image | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_efs_sg_id"></a>[efs\_sg\_id](#input\_efs\_sg\_id) | EFS Securiy Group ID | `list(string)` | Yes | `N/A` | `["sg-38eh3e38e3u3oi3"]` |

## **Example Usage**

```hcl

module "eks" {
  source                                                  = "tfe.axisb.com/ax-tfe/eks/aws"
  version                                                 = "X.X.X"

  region                                                  = "ap-south-1"
  environment                                             = "Dev"
  account_id                                              = "1234567890"
  eks_version                                             = 1.25
  eks_cluster_subnet_ids                                  = ["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]
  eks_cluster_endpoint_private_access                     = true
  eks_cluster_endpoint_public_access                      = false
  public_access_cidrs                                     = []
  eks_cluster_ip_family                                   = "ipv4"
  eks_enabled_cluster_log_types                           = ["api", "audit", "authenticator", "controllerManager", "scheduler"]
  eks_cluster_tags                                        = {Name = "EKS_CLUSTER_TAGS"}
  custom_networking_enabled                               = true
  eks_node_group_subnet_ids                               = ["subnet-b5yy3e10y3y2a","a7ge3u80e3yh4y8"]
  eks_node_group_desired_size                             = 3
  eks_node_group_max_size                                 = 4
  eks_node_group_min_size                                 = 3
  eks_node_group_capacity_type                            = "ON_DEMAND"
  eks_node_group_labels                                   = {}
  eks_node_group_taint                                    = []
  eks_node_group_max_unavailable                          = 1
  eks_worker_node_tags                                    = {Name = "EKS_WORKER_TAGS"}      
  ec2_ssh_key_name                                        = "Example-Key"
  kms_key_arn                                             = "arn:aws:kms:ap-south-1:1234567890:key/0136f743-da0a-4162-9bbb-518dad99193e"
  kms_key_alias_name                                      = "alias/test-key-alias"
  launch_template_device_name                             = "/dev/xvda"
  launch_template_tags                                    = {Name = "LAUNCH_TEMPLATE_TAGS"}
  launch_template_volume_size                             = 300
  launch_template_volume_type                             = "gp3"
  launch_template_instance_type                           = "m6a.2xlarge"
  launch_template_image_id                                = "ami-0d794e65fc87b4b13"
  launch_template_image_owner                             = 123456789
  launch_template_http_put_response_hop_limit             = 2
  addon_tags                                              = {Name = "ADDON_TAGS"}
  add_addons                                              = true
  addon_version                                           = ["v1.12.6-eksbuild.2", "v1.22.0-eksbuild.2", "v1.9.3-eksbuild.7", "v1.25.14-eksbuild.2"]
  addon_name                                              = ["vpc-cni", "aws-ebs-csi-driver", "coredns", "kube-proxy"]
  eks_cluster_addons_resolve_conflicts                    = "OVERWRITE"
  ebs_csi_driver_iam_role_tags                            = {Name = "EBS_CSI_ROLE_TAGS"} 
  efs_csi_driver_iam_role_tags                            = {Name = "EFS_CSI_ROLE_TAGS"}
  sqs_managed_sse_enabled                                 = false
  sqs_message_retention_seconds                           = 300
  sqs_queue_kms_data_key_reuse_period_seconds             = 300
  eks_log_group_retention_period                          = 3
  eks_log_group_skip_destroy                              = false
  vpc_id                                                  = "vpc-o3he3u8ue9rh49"
  prefix_list_ids_for_eks_inbound                         = ["pl-072720d2dc516d34e", "pl-08be416e7a844e165"]
  linux_jump_sg_id                                        = "sg-38eh3e38e3u3oi3"
  eks_control_plane_sg_tags                               = {Name = "EKS_CONTROL_PLANE_SG_TAGS"}
  app_alb_ingress_controller_sg_tags                      = {Name = "APP_ALB_INGRESS_CONTROLLER_SG_TAGS"}
  web_alb_sg_tags                                         = {Name = "WEB_ALB_SG_TAGS"}
  eks_worker_node_sg_tags                                 = {Name = "EKS_WORKER_NODE_SG_TAGS"}
  kube_config_map_iam_role_arns                           = "arn:aws:iam::123456789:role/AXAWS-SHARED_SERVICES-DEVSECOPS-PROD-EKS-OIDC-Role"
  enable_sqs                                              = true
  enable_dlq                                              = false
  sqs_tags                                                = {Name = "EKS_CLUSTER_ROLE_TAGS"}
  eks_cluster_role_tags                                   = {Name = "EKS_WORKER_ROLE_TAGS"}
  eks_worker_role_tags                                    = {Name = "EKS_KARPENTER_ROLE_TAGS"}
  eks_karpenter_role_tags                                 = {Name = "EKS_LB_CONTROLLER_ROLE_TAGS"}
  eks_aws_lb_controller_role_tags                         = {Name = "JENKINS_CROSS_ACCOUNT_ROLE_TAGS"}
  jenkins_cross_account_iam_role_tags                     = {Name = "JENKINS_CENTRALIZED_ROLE_TAGS"}
  jenkins_centrallized_role                               = "arn:aws:iam::123456789:role/AXAWS-SHARED_SERVICES-DEVSECOPS-PROD-EKS-OIDC-Role"
  eks_pod_subnet_details                                  =  [
                                                              {
                                                               subnet_id         = "subnet-b5yy3e10y3y2a"
                                                               availability_zone = "ap-south-1"
                                                              }
                                                             ]
  additional_policies                                    = [
                                                            {
                                                              name        = "EXAMPLE-RDS-POLICY"
                                                              description = "RDS DB Authentication Policy"
                                                              policy      = jsonencode(
                                                               {
                                                                "Version" : "2012-10-17",
                                                                "Statement" : [
                                                                 {
                                                                  "Sid" : "RdsDbAuthentication",
                                                                  "Effect" : "Allow",
                                                                  "Action" : [
                                                                  "rds-db:connect"
                                                                 ],
                                                                   "Resource" : [
                                                                                  "arn:aws:rds-db:ap-south-1:123456789:dbuser:Test-A-P-M-Dev-Test-DB"/testrdsuser"
                                                                                ]
                                                                 }
                                                               ]
                                                             })
                                                            }
                                                          ]
  aws_lb_controller_endpoint                             = "artifactory.axisb.com/hoin-docker-local/aws-alb-controller/aws-alb-controller:2.4.5"
  aws_lb_cainjector_endpoint                             = "artifactory.axisb.com/hoin-docker-local/aws-alb-controller/certmanager/cainjector:v1.8.2"
  aws_lb_cacontroller_endpoint                           = "artifactory.axisb.com/hoin-docker-local/aws-alb-controller/certmanager/controller:v1.8.2"
  aws_lb_cawebhook_endpoint                              = "artifactory.axisb.com/hoin-docker-local/aws-alb-controller/certmanager/webhook:v1.8.2"
  karpenter_inflate_endpoint                             = "artifactory.axisb.com/hoin-docker-local/inflate-app:3.7"
  karpenter_controller_endpoint                          = "artifactory.axisb.com/hoin-docker-local/karpenter/karpenter-controller:0.30.0"
  fluentbit_endpoint                                     = "artifactory.axisb.com/hoin-docker-local/aws-for-fluent-bit:stable10jul23"
  docker_server_url                                      = "https://artifactory.axisb.com"
  docker_username                                        = "testdocker"
  docker_password                                        = "test@1234"
  repository_username                                    = "testbucket"
  repository_password                                    = "testbucket@1234"
  enable_efs                                             = false
  metadata                                               = null
  jsm_ticket_id                                          = "COMR-59"
}

```