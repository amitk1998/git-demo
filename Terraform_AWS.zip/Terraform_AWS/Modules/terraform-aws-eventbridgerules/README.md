# **AWS Eventbridge Rule Module**

Terraform module to create Eventbridge Rule on AWS

# **Description**
 
 This module is basically used to create Eventbridge Rule on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `name`,`description`,`event_pattern`,`rule` & `target_id`.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | Event Bridge Rule Name | `string` | No | null | `ExampleRule` |
| <a name = "input_description"></a>[description](#input\_description) | Description  of Event Bridge Rule | `string` | No | null | `Example Description` |
| <a name = "input_event_pattern"></a>[event\_pattern](#input\_event\_pattern) | Event Pattern for Event Bridge Rule | `string` | No | null | `jsonencode({detail_type = ["AWS Console Sign In Via Cloudtrail"]})` |
| <a name = "input_target_id"></a>[target\_id](#input\_target\_id) | Target ID of Event Bridge Target | `string` | No | null | `example-target` |
| <a name = "input_arn"></a>[arn](#input\_arn) | Arn of the Event Bridge Target | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "eventbridge" {
  source                       = "tfe.axisb.com/ax-tfe/athena/aws"
  version                      = "X.X.X"

  name                         = "example-rules"
  description                  = "Description of Event Bridge Rule"
  event_pattern                = "jsonencode({detail_type = ["AWS Console Sign In Via Cloudtrail"]})"
  target_id                    = "example-target-id"
  
  tags                         = {
                                  Name = "Test"
                                  }

}

```