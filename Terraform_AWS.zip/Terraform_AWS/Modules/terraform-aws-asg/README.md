# **AWS ASG Module**

Terraform module to create Auto Scalling Group on AWS

# **Description**
 
 This module is basically used to create Auto Scalling Group on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `launch_template`,`name`,`max_size`,`min_size`,`vpc_zone_identifier` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | The name of the autoscaling security group | `string` | No | null | `"example-asg"` |
| <a name = "input_launch_template"></a>[launch\_template](#input\_launch\_template) | Launch_template configuration | <pre><code>object({<br> id       = string<br> version  = string<br> })</code></pre> | Yes | `N/A` | ` N/A` |
| <a name = "input_vpc_zone_identifier"></a>[vpc\_zone\_identifier](#input\_vpc\_zone\_identifier) | List of subnet ids to launch resources | `list(string)` | Yes | [ ] | `N/A` |
| <a name = "input_desired_capacity"></a>[desired\_capacity](#input\_desired\_capacity) | The number of Amazon ec2 instance that should be runing in the autoscaling group | `number` | No | null | `4` |
| <a name = "input_desired_capacity_type"></a>[desired\_capacity\_type](#input\_desired\_capacity\_type) | The unit of measurement for the value specified for desired capacity | `string` | No | null | `"units"` |
| <a name = "input_max_size"></a>[max\_size](#input\_max\_size) | The Maximum size of autoscaling group | `number` | Yes | `N/A` | `N/A` |
| <a name = "input_min_size"></a>[min\_size](#input\_min\_size) | The Minimum size of autoscaling group | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_default_cooldown"></a>[default\_cooldown](#input\_default\_cooldown) | Amount of time in second, after a scaling activity completes before another scaling activity can start | `number` | No | null | `300` |
| <a name = "input_default_instance_warmup"></a>[default\_instance\_warmup](#input\_default\_instance\_warmup) | Amount of time , in seconds, until a newly launched instance can contribute to the Amazon cloudwatch metrics | `number` | No | null | `100` |
| <a name = "input_target_group_arns"></a>[target\_group\_arns](#input\_target\_group\_arns) | A set of aws_alb_target_group ARNS , for use with Application or Load Balancing | `list(string)` | No | [ ] | `["enter your set of target group arns here"]` |
| <a name = "input_force_delete"></a>[force\_delete](#input\_force\_delete) | Allows deleting the Auto Scaling Group without waiting for all instance in the pool to terminate | `bool` | No | null | `false` |
| <a name = "input_protect_from_scale_in"></a>[protect\_from\_scale\_in](#input\_protect\_from\_scale\_in) | Allows setting instence protection | `bool` | No | false | `false` |
| <a name = "input_load_balancers"></a>[load\_balancers](#input\_load\_balancers) | A List of elastic load balancer name to add to the autoscaling group name | `list(string)` | No | null | `["enter your list of elastic load balancers name here"]` |
| <a name = "input_placement_group"></a>[placement\_group](#input\_placement\_group) | The name of the placement group into which you'll launch your instence | `string` | No | null | `"example-pgrp"` |
| <a name = "input_health_check_type"></a>[health\_check\_type](#input\_health\_check\_type) | Ec2 or ELB Controls how health cheking is done | `string` | No | null | `"ELB"` |
| <a name = "input_health_check_grace_period"></a>[health\_check\_grace\_period](#input\_health\_check\_grace\_period) | Time in second after instence come into service before checking health | `number` | No | null | `300` |
| <a name = "input_termination_policies"></a>[termination\_policies](#input\_termination\_policies) | A list of policies to decide how the instence in the Auto Scaling Group should be terminated | `list(string)` | No | [ ] | `["Default"]` |
| <a name = "input_suspended_processes"></a>[suspended\_processes](#input\_suspended\_processes) | A list of processes to suspend for the Auto Scaling Group, The allowed values are Launch , Termination ,  HealthCheck, ReplaceUnhealthy, AZRebalance, AlarmNotification, ScheduleActions , AddToLoadBalalancer ,InstanceRefresh | `list(string)` | No | [ ] | `["AlarmNotification"]` |
| <a name = "input_max_instance_lifetime"></a>[max\_instance\_lifetime](#input\_max\_instance\_lifetime) | The Maximum amount of time ,in seconds, that an instence can be in service , value must be between 86400 and 31536000 second or 0 | `number` | No | null | `7878980` |
| <a name = "input_enabled_metrics"></a>[enabled\_metrics](#input\_enabled\_metrics) | A list of metrics to collect . The allowed values are GroupDesiredCapacity , GroupInServiceCapacity, GroupPendingCapacity , GroupMinSize , GroupMaxSize , | `list(string)` | No | [ ] | `["GroupInServiceCapacity"]` |
| <a name = "input_metrics_granularity"></a>[metrics\_granularity](#input\_metrics\_granularity) | The granularity to associate with the metrics to collect. The only valid value is 1Minute | `string` | No | null | `"1Minute"` |
| <a name = "input_wait_for_capacity_timeout"></a>[wait\_for\_capacity\_timeout](#input\_wait\_for\_capacity\_timeout) | The maximum duration that terraform should wait for ASG to be healthy before timing out | `string` | No | null | `"10m"` |
| <a name = "input_min_elb_capacity"></a>[min\_elb\_capacity](#input\_min\_elb\_capacity) | Setting this will causes Terraform for this number of instences to show up healthy in ELB only on creation | `number` | No | null | 10 |
| <a name = "input_instance_refresh"></a>[instance\_refresh](#input\_instance\_refresh) | If this block is configured, start an Instance refresh when this Auto Scaling Group is updated | <pre><code>list(object({<br> strategy  = string<br> triggers  = list(string)<br> preferences = object({<br> checkpoint_delay        = number<br> checkpoint_percentages  = list(number)<br> instance_warmup         = number<br> min_healthy_percentage  = number<br> auto_rollback           = bool})<br> }))</code></pre> | No | [ ] | <pre><code>[{<br> strategy = "Rolling"<br> triggers = ["tag"]<br> {<br> min_healthy_percentage = 50 <br>}<br> }]</code></pre> |
| <a name = "input_warm_pool"></a>[warm\_pool](#input\_warm\_pool) | If this block is configured,add a Warm Pool to the specified Auto Scaling group | <pre><code>list(object({<br> pool_state     = string<br> min_size       = number<br> max_group_prepared_capacity = number<br> instance_reuse_policy       = object({<br> reuse_on_scale_in     = bool<br> })<br> }))</code></pre> | No | [ ] | <pre><code>[<br>   {<br> pool_state = "Hibernated"<br> min_size  = 1<br> max_group_prepared_capacity = 10<br> {<br> reuse_on_scale_in = true <br>}<br> }<br>   ]</code></pre> |
| <a name = "input_mixed_instances_policy"></a>[mixed\_instances\_policy](#input\_mixed\_instances\_policy) | policy to use mixed group of on-demand/spot of differing type | <pre><code> object({<br> instances_distribution  = object({<br> on_demand_allocation_strategy             = string<br> on_demand_base_capacity                   = number<br> on_demand_percentage_above_base_capacity  = number<br> spot_allocation_strategy                  = string<br> spot_instance_pools                       = number<br> spot_max_price                            = optional(string,null)<br> })<br> override =list(object({<br> instance_type      = string<br> weighted_capacity = number<br> }))<br> })</code></pre> | No | null | <pre><code>[<br>  {<br> instance_type = c3.large <br>weighted_capacity  = 2 <br>}  <br>]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "asg" {
  source                  = "tfe.axisb.com/ax-tfe/asg/aws"
  version                 = "X.X.X"
 
  launch_template         = { id = "lt-07b83349fa16d5a80" version = "1" }
  name                    = "EG-POC-ASG-TEST"	
  max_size                = 5
  min_size                = 2
  vpc_zone_identifier     = ["subnet-01497376460e9cebe","subnet-0ee2c95c26aeca0dd"]

  tags                    = {
                             Name = "Test"
                             }

}

```