# **AWS ACM Module**

Terraform module to create ACM on AWS

# **Description**
 
 This module is basically used to create both existing and self managed acm certificate  on Amazon Web Services(AWS).
 For `existing acm certificate` it requires few attributes in order to be created on AWS like `import_certificate`,`private_key`,`certificate_body`,`certificate_chain`. and for `self managed acm certificate` it requires these attributes
,`create_aws_certificate`,`domain_name`,`subject_alternative_names`,`validation_method`,`validate_certificate`,`ttl`,`validation_option`,`vpc` etc.


 # **Variable Defination For Existing ACM**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_import_certificate"></a>[import\_certificate](#input\_import\_certificate) | Desc | `bool` | No | false | `false` |
| <a name = "input_private_key"></a>[private\_key](#input\_private\_key) | (Required) Path of private key | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_certificate_body"></a>[certificate\_body](#input\_certificate\_body) | (Required) Path of certificate body | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

 # **Variable Defination For Self Managed ACM**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_validation_record_fqdns"></a>[validation\_record\_fqdns](#input\_validation\_record\_fqdns) | (Optional) List of fully qualified domain name that implements the validation | `list(string)` | No | null | `null` |
| <a name = "input_domain_name"></a>[domain\_name](#input\_domain\_name) | (Required) A domain name for which the certificate should be issued | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_subject_alternative_names"></a>[subject\_alternative\_names](#input\_subject\_alternative\_names) | (Optional) Set of domains that should be SANs in the issued certificate. To remove all elements of a previously configured list, set this value equal to an empty list ([]) or use the terraform taint command to trigger recreation | `list(string)` | No | null | `["*.example.com"]` |
| <a name = "input_validation_method"></a>[validation\_method](#input\_validation\_method) | (Optional) Which method to use for validation, DNS or EMAIL | `string` | No | null | `"DNS"` |
| <a name = "input_validate_certificate"></a>[validate\_certificate](#input\_validate\_certificate) | Set to false to prevent the validation of a acm certificate | `bool` | No | true | `true` |
| <a name = "input_ttl"></a>[ttl](#input\_ttl) | Desc | `number` | No | null | `60` |
| <a name = "input_validation_option"></a>[validation\_option](#input\_validation\_option) | (Optional) The domain name that you want ACM to use to send you validation emails. This domain name is the suffix of the email addresses that you want ACM to use | <pre><code>list(object({<br> domain_name       = string<br> validation_domain = string<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> domain_name       = "example.com"<br> validation_domain = "example.com"<br> }<br>]</code></pre> |
| <a name = "input_allow_overwrite"></a>[allow\_overwrite](#input\_allow\_overwrite) | (Optional) Whether to allow overwrite of Route53 records | `bool` | No | true | `true` |
| <a name = "input_private_zone"></a>[private\_zone](#input\_private\_zone) | Used with name field to get a private Hosted Zone | `bool` | No | false | `false` |
| <a name = "input_certificate_transparency_logging_preference"></a>[certificate\_transparency\_logging\_preference](#input\_certificate\_transparency\_logging\_preference) | (Optional) Specifies whether certificate details should be added to a certificate transparency log | `bool` | No | true | `true` |
| <a name = "input_key_algorithm"></a>[key\_algorithm](#input\_key\_algorithm) | (Optional) Specifies the algorithm of the public and private key pair that your Amazon issued certificate uses to encrypt data | `string` | No | null | `"RSA"` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage For Existing ACM**

```hcl

module "existing_acm_certificate" {
  source                    = "tfe.axisb.com/ax-tfe/acm/aws"
  version                   = "X.X.X"

  import_certificate        = false
  private_key               = "input private key"
  certificate_body          = "input certificate body"
  certificate_chain         = null
  tags                      = {
                               Name = "Test"
                              }
}

```

## **Example Usage For Self Managed ACM**

```hcl

module "selfmanaged_acm_certificate" {
  source                      = "tfe.axisb.com/ax-tfe/acm/aws"
  version                     = "X.X.X"
  
  create_aws_certificate      = true  validation_record_fqdns     = null
  domain_name                 = "example.com"
  subject_alternative_names   = ["*.example.com"]
  validation_method           = "DNS"
  validate_certificate        = true
  ttl                         = 60
  validation_option           = [{domain_name = "example.com",validation_domain = "example.com"}]
  allow_overwrite             = true
  private_zone                = false
  vpc                         = [{vpc_id     = "vpc-a5fyegey7e8e878he",vpc_region = "ap-south-1"}]
  certificate_transparency_logging_preference = true
  key_algorithm               = "RSA"

  tags                        = {
                                 Name = "Test"
                                }
}

```