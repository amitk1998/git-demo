# **AWS EMR Module**

Terraform module to create EMR on AWS

# **Description**
 
 This module is basically used to create EMR on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `name`,`release_version`,`vpc_id`,`subnet_ids`,`applications` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_jsm_ticket_id"></a>[jsm\_ticket\_id](#input\_jsm\_ticket\_id) | JSM Ticket ID | `string` | No | null | `null` |
| <a name = "input_name"></a>[name](#input\_name) | EMR Cluster Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_vpc_id"></a>[vpc\_id](#input\_vpc\_id) | EMR Cluster VPC ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | EMR Cluster Subnet IDs | `list(string)` | No | null | `["subnet-03b1227d5071ac12f","subnet-0ed4e4260c516b7db"]` |
| <a name = "input_release_version"></a>[release\_version](#input\_release\_version) | EMR Cluster Release Version | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_applications"></a>[applications](#input\_applications) | EMR Cluster Applications required | `list(string)` | No | [] | `["Spark"]` |
| <a name = "input_enable_logging"></a>[enable\_logging](#input\_enable\_logging) | EMR Cluster Enable Logging | `bool` | No | false | `false` |
| <a name = "input_s3_bucket_log_uri"></a>[s3\_bucket\_log\_uri](#input\_s3\_bucket\_log\_uri) | EMR Cluster Logging S3 Bucket URI | `string` | No | null | `null` |
| <a name = "input_enable_delete_protection"></a>[enable\_delete\_protection](#input\_enable\_delete\_protection) | EMR Cluster Enable Delete Protection | `bool` | No | false | `false` |
| <a name = "input_enable_job_flow_visibility_to_all_iam_users"></a>[enable\_job\_flow\_visibility\_to\_all\_iam\_users](#input\_enable\_job\_flow\_visibility\_to\_all\_iam\_users) | EMR Cluster Enable Job Flow Visibility to all IAM Users associated | `bool` | No | true | `true` |
| <a name = "input_security_configuration"></a>[security\_configuration](#input\_security\_configuration) | EMR Cluster  Encoded Encoded. Cluster Security Configuration String | `string` | No | null | `null` |
| <a name = "input_ami_id"></a>[ami\_id](#input\_ami\_id) | EMR Cluster AMI ID to use Self Managed AMI | `string` | No | null | `null` |
| <a name = "input_root_volume_size"></a>[root\_volume\_size](#input\_root\_volume\_size) | EMR Cluster Root EBS Volume Size | `number` | No | null | `null` |
| <a name = "input_keep_job_flow_alive_when_no_steps"></a>[keep\_job\_flow\_alive\_when\_no\_steps](#input\_keep\_job\_flow\_alive\_when\_no\_steps) | EMR Cluster keep job flow alive when no steps are running | `bool` | No | true | true |
| <a name = "input_step_concurrency_level"></a>[step\_concurrency\_level](#input\_step\_concurrency\_level) | EMR Cluster Step Execution Concurrency | `number` | No | 1 | `1` |
| <a name = "input_software_settings_configuration_json_string"></a>[software\_settings\_configuration\_json\_string](#input\_software\_settings\_configuration\_json\_string) | EMR Cluster Software Settings Configurations JSON Encoded String | `string` | No | null | `null` |
| <a name = "input_additional_info_json_string"></a>[additional\_info\_json\_string](#input\_additional\_info\_json\_string) | EMR Cluster Additional Information JSON Encoded String | `string` | No | null | `null` |
| <a name = "input_cluster_scale_down_behavior_type"></a>[cluster\_scale\_down\_behavior_type](#input\_cluster\_scale\_down\_behavior\_type) | EMR Cluster Scale Down Behavior Type. Valid values are TERMINATE_AT_INSTANCE_HOUR or TERMINATE_AT_TASK_COMPLETION | `string` | No | null | `"TERMINATE_AT_INSTANCE_HOUR"` |
| <a name = "input_ssh_key_name"></a>[ssh\_key\_name](#input\_ssh\_key\_name) | EMR Cluster SSH Key Name | `string` | No | null | `"example-ssh-key"` |
| <a name = "input_enable_auto_terminate_cluster_on_idle"></a>[enable\_auto\_terminate\_cluster\_on\_idle](#input\_enable\_auto\_terminate\_cluster\_on\_idle) | EMR Cluster Enable Auto Termination of Cluster on Idle | `bool` | No | false | `false` |
| <a name = "input_auto_termination_idle_timeout"></a>[auto\_termination\_idle\_timeout](#input\_auto\_termination\_idle\_timeout) | EMR Cluster Auto Termination Idle Timeout. Only applicable when Auto Termination is enabled | `string` | No | "604800" | `"604800"` |
| <a name = "input_bootstrap_action_specifications"></a>[bootstrap\_action\_specifications](#input\_bootstrap\_action\_specifications) | EMR Cluster Bootstrap Actions to be run before Hadoop is started on Cluster Node | <pre><code>list(object({<br> name = string<br> path = string<br> args = optional(list(string), null)<br> }))</code></pre> | No | [] | <pre><code>[<br> {<br> name = N/A<br> path = N/A<br> args = ["instance.isMaster=true","echo running on master node"]<br> }<br>]</code></pre> |
| <a name = "input_steps_specifications"></a>[steps\_specifications](#input\_steps\_specifications) | EMR Cluster Steps to run when creating a cluster | <pre><code>list(object({<br> name				= string<br> action_on_failure	= string<br> jar					= string<br> main_class			= optional(string, null)<br> properties			= optional(map(string), null)<br> args				= optional(list(string), null)<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> name				= "example"<br> action_on_failure	= "TERMINATE_JOB_FLOW"<br> jar					= "command-runner.jar"<br> main_class			= null<br> properties			= null<br> args				= null<br> }<br>]</code></pre> |
| <a name = "input_provisioning_type"></a>[provisioning\_type](#input\_provisioning\_type) | EMR Cluster Provisioning Type. Valid values are GROUP_PROVISIONING or FLEET_PROVISIONING. Only GROUP_PROVISIONING is supported | `string` | No | "GROUP_PROVISIONING" | `"GROUP_PROVISIONING"` |
| <a name = "input_core_instance_specifications"></a>[core\_instance\_specifications](#input\_core\_instance\_specifications) | EMR Cluster Core Instance Group Specification. Only applicable for GROUP_PROVISIONING | <pre><code>object({<br> bid_price			= optional(string, null)<br> instance_count		= optional(number, null)<br> instance_type		= string<br> autoscaling_policy	= optional(string, null)<br> ebs_config			= optional(object({<br> type				= string<br> size				= number<br> iops				= optional(number, null)<br> throughput			= optional(number, null)<br> volumes_per_instance	= optional(number, null)<br> }),null)<br> })</code></pre> | No | null | <pre><code>{<br> bid_price			= "0.30"<br> instance_count		= 1<br> instance_type		= "c4.large"<br> autoscaling_policy	= null<br> ebs_config			= {<br> type				= "gp2"<br> size				= 40<br> iops				= null<br> throughput			= null<br> volumes_per_instance	= 1<br> }<br> }</code></pre> |
| <a name = "input_master_instance_specifications"></a>[master\_instance\_specifications](#input\_master\_instance\_specifications) | EMR Cluster Master Instance Group Specification. Only applicable for GROUP_PROVISIONING | <pre><code>object({<br> bid_price			= optional(string, null)<br> instance_count		= optional(number, null)<br> instance_type		= string<br> ebs_config			= optional(object({<br> type				= string<br> size				= number<br> iops				= optional(number, null)<br> throughput			= optional(number, null)<br> volumes_per_instance	= optional(number, null)<br> }),null)<br> })</code></pre> | No | null | <pre><code>{<br> bid_price			= "0.30"<br> instance_count		= 1<br> instance_type		= "c4.large"<br> ebs_config			= {<br> type				= "gp2"<br> size				= 40<br> iops				= null<br> throughput			= null<br> volumes_per_instance	= 1<br> }<br> }</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "emr" {
  source                   = "tfe.axisb.com/ax-tfe/emr/aws"
  version                  = "X.X.X"
         
  name                     = "emr-test-poc-cluster"
  release_version          = "emr-6.13.0"
  vpc_id                   = "vpc-0df41afb90386ae13"
  subnet_ids               = ["subnet-03b1227d5071ac12f","subnet-0ed4e4260c516b7db"]
  applications             = ["Spark"]

  tags                     = {
                              Name = "Test"
                             }
  }

```

