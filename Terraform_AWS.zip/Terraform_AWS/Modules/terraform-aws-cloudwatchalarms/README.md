# **AWS  CloudWatchAlarm Module**

Terraform module to create CloudWatchAlarm on AWS

# **Description**
 
 This module is basically used to  create CloudWatchAlarm on Amazon Web Services(AWS).
 It requires these attributes in order to be created on aws `alarm_name`,`alarm_description`,`comparison_operator`,`evaluation_periods`,`metric_name`,`namespace`,`period`,`statistic` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_alarm_name"></a>[alarm\_name](#input\_alarm\_name) | Cloudwatch Alarm Name | `string` | Yes | `N/A` | `N/A` |
| <a name="input_comparison_operator"></a>[comparison\_operator](#input\_comparison\_operator) | Cloudwatch Alarm Comparison Operator | `string` | Yes | `N/A` | `N/A` |
| <a name="input_evaluation_periods"></a>[evaluation\_periods](#input\_evaluation\_periods) | Cloudwatch Alarm Evaluation Periods | `number` | Yes | `N/A` | `N/A` |
| <a name="input_metric_name"></a>[metric\_name](#input\_metric\_name) | Cloudwatch Alarm Metric Name | `string` | No | `"alarm_metric"` | `"alarm_metric"` |
| <a name="input_namespace"></a>[namespace](#input\_namespace) | Cloudwatch Alarm Namespace | `string` | No | `"AWS/NETWORK"` | `"AWS/NETWORK"` |
| <a name="input_period"></a>[period](#input\_period) | Cloudwatch Alarm Period | `number` | No | `60` | `60` |
| <a name="input_statistic"></a>[statistic](#input\_statistic) | Cloudwatch Alarm Statistic | `string` | No | `"Average"` | `"Average"` |
| <a name="input_threshold"></a>[threshold](#input\_threshold) | Cloudwatch Alarm Threshold | `number` | No | `null` | `null` |
| <a name="input_unit"></a>[unit](#input\_unit) | Cloudwatch Alarm Unit | `string` | No | `null` | `"input unit"` |
| <a name="input_alarm_description"></a>[alarm\_description](#input\_alarm\_description) | Cloudwatch Alarm Description | `string` | No | `"testing cloudwatch alarm through terraform"` | `"testing cloudwatch alarm through terraform"` |
| <a name="input_metric_query"></a>[metric\_query](#input\_metric\_query) | Enables you to specify at most 20 alarms based on a metric math expression | `any` | No | `[ ]` | <pre><code>{<br> id = "e1"<br> expression = "ANOMALY_DETECTON_BAND(m1)"<br> label = "CPUtilization (Expected)"<br> return_data = true<br> }</code></pre> |
| <a name="input_dimensions"></a>[dimensions](#input\_dimensions) | Cloudwatch Alarm Dimensions | `map(string)` | No | `null` | <pre><code>{<br> loadbalancer = "app/web"<br> }</code></pre> |
| <a name="input_alarm_actions"></a>[alarm\_actions](#input\_alarm\_actions) | Cloudwatch Alarm action | `list(string)` | No | `[ ]` | `[ ]` |
| <a name="input_ok_actions"></a>[ok\_actions](#input\_ok\_actions) | Cloudwatch Alarm OK Actions | `list(string)` | No | `[ ]` | `[ ]` |
| <a name="input_insufficient_data_actions"></a>[insufficient\_data\_actions](#input\_insufficient\_data\_actions) | Cloudwatch Alarm Insufficient Data Actions | `list(string)` | No | `[ ]` | `[ ]` |
| <a name="input_tags"></a>[tags](#input\_tags) | Resource Tags. | `map(string)` | Yes | `{}` | `{ }` |

## **Example Usage**

```hcl

module "cloudwatchalarms" {
  source              = "tfe.axisb.com/ax-tfe/cloudwatchalarms/aws"
  version             = "X.X.X"

  alarm_name          = "tfe_test_cloudwatch_alarm_poc"
  alarm_description   = "testing cloudwatch alarm through terraform"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = 3
  metric_name         = "alarm_metric"
  namespace           = "AWS/NETWORK"
  period              = 60
  statistic           = "Average"

  tags                = {
                         Name = "Test"
                        }


}

```