# **AWS Transitgateway Acceptor Module**

Terraform module to create Transitgateway Acceptor on AWS

# **Description**
 
 This module is basically used to create Transitgateway Acceptor on Amazon Web Services(AWS).
 It requires only 1 attribute in order to be created on AWS like `aws_ec2_transit_gateway_vpc_attachment_id` .

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_aws_ec2_transit_gateway_vpc_attachment_id"></a>[aws\_ec2\_transit\_gateway\_vpc\_attachment\_id](#input\_aws\_ec2\_transit\_gateway\_vpc\_attachment\_id) | The AWS EC2 Transit Gateway VPC Attachment ID for acceptig | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

 module "" {
  source                                      = "tfe.axisb.com/ax-tfe/transitgatewayacceptor/aws"
  version                                     = "X.X.X"

  aws_ec2_transit_gateway_vpc_attachment_id   = "tgw-attach-123456" 
  tags                                        = {
                                                 Name = "Test"
                                                }
}

```