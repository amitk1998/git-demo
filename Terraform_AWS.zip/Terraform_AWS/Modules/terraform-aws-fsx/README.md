# **AWS FSx Module**

Terraform module to create FSx on AWS

# **Description**
 
 This module is basically used to create FSx on Amazon Web Services(AWS).
 Amazone FSx makes it easy and cost effective to launch,run and scale feature rich,high perfomance file system in the cloud.It requires few attributes in order to be created on AWS `file_type`,`deployment_type`,`storage_capacity`,`storage_type`,`subnet_ids`,`preferred_subnet_id`,`security_group_ids`,`throughput_capacity`,`fsx_ontap_fxx_admin_password`,`disk_iops_configuration_iops`,`disk_iops_configuration_mode` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_file_type"></a>[file_type](#input\_file_type) | The File type for FSx | `string` | No | "windows" | `"windows"` |
| <a name = "input_deployment_type"></a>[deployment\_type](#input\_deployment\_type) | The deployment type for FSx | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_storage_type"></a>[storage_type](#input\_storage_type) | The storage type for FSx | `string` | No | null | `"SSD"` |
| <a name = "input_active_directory_id"></a>[active\_directory\_id](#input\_active\_directory\_id) | The ID of the Active Directory to associate with FSx | `string` | No | null | `"input your active directory id here"` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | List of subnet IDs for FSx deployment | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_preferred_subnet_id"></a>[preferred_subnet_id](#input\_preferred_subnet_id) | The preferred subnet ID for FSx | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_kms_key_id"></a>[kms_key_id](#input\_kms_key_id) | The ARN of the KMS key for encryption | `string` | No | null | `"arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"` |
| <a name = "input_security_group_ids"></a>[security\_group\_ids](#input\_security\_group\_ids) | List of security group IDs for FSx | `list(string)` | No | [ ] | `["sg-6tygjggyu3t3tt"]` |
| <a name = "input_storage_capacity"></a>[storage\_capacity](#input\_storage\_capacity) | The storage capacity for FSx in GB | `number` | Yes | `N/A` | `N/A` |
| <a name = "input_throughput_capacity"></a>[throughput\_capacity](#input\_throughput\_capacity) | The throughput capacity for FSx in MBps, minimum 8 maximum 2048 | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_skip_final_backup"></a>[skip\_final\_backup](#input\_skip\_final\_backup) | Whether to skip the final backup during deletion | `bool` | No | false | `false` |
| <a name = "input_copy_tags_to_backups"></a>[copy\_tags\_to\_backups](#input\_copy\_tags\_to\_backups) | Whether to copy tags to backups | `bool` | No | false | `false` |
| <a name = "input_automatic_backup_retention_days"></a>[automatic_backup_retention_days](#input\_automatic_backup_retention_days) | The retention period for automatic backups in days | `number` | No | null | `0` |
| <a name = "input_backup_id"></a>[backup\_id](#input\_backup\_id) | The backup ID for FSx | `string` | No | null | `"input backup id here"` |
| <a name = "input_audit_log_config"></a>[audit\_log\_config](#input\_audit\_log\_config) | Audit log configuration for FSx | <pre><code>object({<br> audit_log_destination            = optional(string)<br> file_access_audit_log_level     = optional(string)<br> file_share_access_audit_log_level = optional(string)<br> })</code></pre> | No | null | `{"input audit log configuration here"}` |
| <a name = "input_self_managed_active_directory_config"></a>[self\_managed\_active\_directory\_config](#input\_self\_managed\_active\_directory\_config) | Configuration for self-managed Active Directory | <pre><code>object({<br> dns_ips     = list(string)<br> domain_name = string<br> password    = string<br> username    = string<br> file_system_administrators_group = optional(string)<br> organizational_unit_distinguished_name = optional(string)<br> })</code></pre> | No | null | <pre><code>{<br> dns_ips     = ["10.0.0.111","10.0.0.222"]<br> domain_name = "corp.example.com"<br> password    = "Admin@1980"<br> username    = "Admin"<br>  }</code></pre> |
| <a name = "input_fsx_openzfs_copy_tags_to_volumes"></a>[fsx\_openzfs\_copy\_tags\_to\_volumes](#input\_fsx\_openzfs\_copy\_tags\_to\_volumes) | Whether to copy tags to volumes | `bool` | No | false | `false` |
| <a name = "input_endpoint_ip_address_range"></a>[endpoint\_ip\_address\_range](#input\_endpoint\_ip\_address\_range) | The IP address range for the file system's endpoint | `string` | No | null | `"input ip address range here"` |
| <a name = "input_daily_automatic_backup_start_time"></a>[daily\_automatic\_backup\_start\_time](#input\_daily\_automatic\_backup\_start\_time) | The daily automatic backup start time | `string` | No | null | `"input daily automatic backup times here"` |
| <a name = "input_disk_iops_configuration_iops"></a>[disk\_iops\_configuration\_iops](#input\_disk\_iops\_configuration\_iops) | The IOPS (Input/Output Operations Per Second) for the disk | `number` | No | null | `30` |
| <a name = "input_disk_iops_configuration_mode"></a>[disk\_iops\_configuration\_mode](#input\_disk\_iops\_configuration\_mode) | The mode for disk IOPS configuration | `string` | No | null | `"AUTOMATIC"` |
| <a name = "input_fsx_lustre_import_path"></a>[fsx\_lustre\_import\_path](#input\_fsx\_lustre\_import\_path) | The import path for the Lustre file system | `string` | No | null | `"input fsx luster import path here"` |
| <a name = "input_fsx_lustre_export_path"></a>[fsx_lustre_export_path](#input\_fsx\_lustre\_export\_path) | The export path for the Lustre file system | `string` | No | null | `"input luster export path here"` |
| <a name = "input_fsx_lustre_imported_file_chunk_size"></a>[fsx\_lustre\_imported\_file\_chunk\_size](#input\_fsx\_lustre\_imported\_file\_chunk\_size) | The size of the imported file chunks for Lustre | `number` | No | null | `200` |
| <a name = "input_fsx_lustre_per_unit_storage_throughput"></a>[fsx\_lustre\_per\_unit\_storage\_throughput](#input\_fsx\_lustre\_per\_unit\_storage\_throughput) | The per-unit storage throughput for Lustre | `number` | No | null | `100` |
| <a name = "input_fsx_lustre_drive_cache_type"></a>[fsx\_lustre\_drive\_cache\_type](#input\_fsx\_lustre\_drive\_cache\_type) | The drive cache type for Lustre | `string` | No | null | `"LUSTRE"` |
| <a name = "input_fsx_lustre_auto_import_policy"></a>[fsx\_lustre\_auto\_import\_policy](#input\_fsx\_lustre\_auto\_import\_policy) | The auto-import policy for Lustre | `string` | No | null | `"input auto import policy for the luster here"` |
| <a name = "input_fsx_lustre_data_compression_type"></a>[fsx\_lustre\_data\_compression\_type](#input\_fsx\_lustre\_data\_compression\_type) | The data compression type for Lustre | `string` | No | null | `"input the data compression type for the luster here"` |
| <a name = "input_fsx_lustre_file_system_type_version"></a>[fsx\_lustre\_file\_system\_type\_version](#input\_fsx\_lustre\_file\_system\_type\_version) | The file system type version for Lustre | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_fsx_lustre_log_destination"></a>[fsx\_lustre\_log\_destination](#input\_fsx\_lustre\_log\_destination) | The destination for Lustre log data | `string` | No | null | `"input luster log destination"` |
| <a name = "input_fsx_lustre_log_level"></a>[fsx_lustre_log_level](#input\_fsx\_lustre\_log\_level) | The log level for Lustre log data | `string` | No | "DISABLED" | `"DISABLED"` |
| <a name = "input_fsx_lustre_no_squash_nids"></a>[fsx_lustre_no_squash_nids](#input\_fsx\_lustre\_no\_squash\_nids) | The no squash NIDs for Lustre | `string` | No | null | `["input no squash nid for the luster"]` |
| <a name = "input_fsx_lustre_root_squash"></a>[fsx_lustre_root_squash](#input\_fsx\_lustre\_root\_squash) | Whether to enable root squash for Lustre | `bool` | No | null | `false` |
| <a name = "input_fsx_ontap_fxx_admin_password"></a>[fsx\_ontap\_fxx\_admin\_password](#input\_fsx\_ontap\_fxx\_admin\_password) | The Fxx admin password for ONTAPfsx_ontap_route_table_ids | `string` | No | null | `` |
| <a name = "input_fsx_ontap_route_table_ids"></a>[fsx\_ontap\_route\_table\_ids](#input\_fsx\_ontap\_route\_table\_ids) | Description | `string` | No | null | `` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ontap_fsx" {
source                               = "tfe.axisb.com/ax-tfe/fsx/aws"
version                              = "X.X.X"

file_type                            = "ontap"
deployment_type                      = "MULTI_AZ_1"
storage_capacity                     = 1024
storage_type                         = "SSD"
subnet_ids                           = ["subnet-03b1227d5071ac12f","subnet-0ed4e4260c516b7db"]
preferred_subnet_id                  = "subnet-03b1227d5071ac12f"
security_group_ids                   = ["sg-01b745a8225377c38"]
throughput_capacity                  = 512
fsx_ontap_fxx_admin_password         = "Test@123"
disk_iops_configuration_iops         = 3072
disk_iops_configuration_mode         = "USER_PROVISIONED"
tags                                 = {
                                        Name = "Test"
                                       }
                                       
}

```