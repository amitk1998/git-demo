# **AWS SecretManager  Module**

Terraform module to create SecretManager on AWS

# **Description**
 
 This module is basically used to create SecretManager on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `name`,`description`,`force_overwrite_replica_secret`,`kms_key_id`,`recovery_window_in_days`,`policy`,`enable_secret_rotation`,`secret_string`,`manage_secret` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | Secret Manager Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_description"></a>[description](#input\_description) | Secret Manager Description | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_policy"></a>[policy](#inamenput\_policy) | Secret Manager Policy | `string` | No | null | `"input policy"` |
| <a name = "input_force_overwrite_replica_secret"></a>[force\_overwrite\_replica\_secret](#input\_force\_overwrite\_replica\_secret) | Secret Manager Force Overwrite Replica Secret | `bool` | No | null | `null` |
| <a name = "input_kms_key_id"></a>[kms\_key\_id](#input\_kms\_key\_id) | Secret Manager KMS Key ID | `string` | No | null | `"aws/secretsmanager"` |
| <a name = "input_recovery_window_in_days"></a>[recovery\_window\_in\_days](#input\_recovery\_window\_in\_days) | Number of days that AWS Secrets Manager waits before it can delete the secret | `number` | No | null | `null` |
| <a name = "input_replica_specification"></a>[replica\_specification](#input\_replica\_specification) | Secret Manager Replica Sepcifications | <pre><code>list(object({<br> kms_key_id  = optional(string, "aws/secretsmanager")<br> region      = string<br> }))</code></pre> | No | null | <pre><code>[<br> {<br> kms_key_id  = "aws/secretsmanager"<br> region      = "ap-south-1"<br> }<br>]</code></pre> |
| <a name = "input_secret_string"></a>[secret\_string](#input\_secret\_string) | Secret Manager Secret String | `string` | No | null | `"example-string-to-protect"` |
| <a name = "input_manage_secret"></a>[manage\_secret](#input\_manage\_secret) | Secret Manager Create / Manage Secret String | `bool` | No | false | `false` |
| <a name = "input_enable_secret_rotation"></a>[enable\_secret\_rotation](#input\_enable\_secret\_rotation) | Enable Secret Rotation | `bool` | No | false | `false` |
| <a name = "input_secret_rotation_lambda_function_arn"></a>[secret\_rotation\_lambda\_function\_arn](#input\_secret\_rotation\_lambda\_function\_arn) | Secret Rotation Lambda Function ARN | `string` | No | null | `"input lambda rotation arn"` |
| <a name = "input_secret_rotation_after_days"></a>[secret\_rotation\_after\_days](#input\_secret\_rotation\_after\_days) | Secret Rotation After Days | `number` | No | null | `null` |
| <a name = "input_secret_rotation_schedule_expression"></a>[secret\_rotation\_schedule\_expression](#input\_secret\_rotation\_schedule\_expression) | Secret Rotation Schedule Expression | `string` | No | null | `null` |
| <a name = "input_secret_rotation_window_duration_in_hours"></a>[secret\_rotation\_window\_duration\_in\_hours](#input\_secret\_rotation\_window\_duration\_in\_hours) | Description | `string` | No | null | `null` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "secretsmanager" {
  source                         = "tfe.axisb.com/ax-tfe/secretmanager/aws"
  version                        = "X.X.X"

  name                           = "example-secretmanager"
  description                    = "Secret Manager Description"
  force_overwrite_replica_secret = null
  kms_key_id                     = "aws/secretsmanager"
  recovery_window_in_days        = 30
  policy                         = null 
  enable_secret_rotation         = false
  manage_secret                  = false
  secret_string                  = "example-string-to-protect"

  tags                           = {
                                    Name = "Test"
                                   }
}

```