# **AWS ECS Module**

Terraform module to create ECS on AWS.

# **Description**
 
 This module is basically used to create Amazon Elastic Container Service on Amazon Web Services(AWS).
 It requires few attributes to created on AWS like `create_ecs_cluster`,`cluster_name`,`cloudwatch_name`,`kms_key_arn`,`service_specifications`,`cluster_task_definitions`,`container_definitions`,`subnet_ids` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create_ecs_cluster"></a>[create_ecs_cluster](#input_create_ecs_cluster) | Flag for creating cluster | `bool` | No | true | `true` |
| <a name = "input_cluster_name"></a>[cluster_name](#input\_cluster_name) | Name of the cluster | `string` | Yes | N/A | `N/A` |
| <a name = "input_kms_key_arn"></a>[kms_key_arn](#input\_kms_key_arn) | KMS key arn for encryption | `string` | No | null | null |
| <a name = "input_cluster_logging_type"></a>[cluster_logging_type](#input\_cluster_logging_type) | Cluster logging type | `string` | No | null | null |
| <a name = "input_cluster_logging_enable_cloudwatch_encryption"></a>[cluster_logging_enable_cloudwatch_encryption](#input\_cluster_logging_enable_cloudwatch_encryption) | Cluster logging enable cloudwatch encryption | `bool` | No | true | `true` |
| <a name = "input_cluster_logging_s3_bucket_encryption_enabled"></a>[cluster_logging_s3_bucket_encryption_enabled](#input\_cluster_logging_s3_bucket_encryption_enabled) | Cluster  enable S3 bucket encryption | `bool` | No | true | true |
| <a name = "input_cluster_logging_s3_bucket_name"></a>[cluster_logging_s3_bucket_name](#input\_cluster_logging_s3_bucket_name) | S3 Bucket name for logging | `string` | No | null | null |
| <a name = "input_cluster_logging_s3_key_prefix"></a>[cluster_logging_s3_key_prefix](#input\_cluster_logging_s3_key_prefix) | S3  key prefix for logging | `string` | No | null | null |
| <a name = "input_cluster_enable_container_insights"></a>[cluster_enable_container_insights](#input\_cluster_enable_container_insights) | Enable container insights | `bool` | No | false | `false` |
| <a name = "input_cluster_namespace_arn"></a>[cluster_namespace_arn](#input\_cluster_namespace_arn) | The cluster namespace arn for service connect | `string` | No | null | null |
| <a name = "input_service_specifications"></a>[service_specifications](#input\_service_specifications) | ECS service specification | <pre><code>list(object({<br> name                                     =  string<br> launch_type                              = optional(string, "EC2")<br> vpc_id                                   = optional(string,null)<br> platform_version                         = optional(string, "LATEST")<br>  desired_task_count                       = optional(number, 0)<br> deployment_maximum_percent               = optional(number, null)<br> deployment_minimum_healthy_percent       = optional(number, null)<br> enable_ecs_managed_tags                  = optional(bool, null)<br> enable_execute_command                   = optional(bool, null)<br> force_new_deployment                     = optional(bool, null)<br> health_check_grace_period_seconds        = optional(number, null)<br> scheduling_strategy                      = optional(number, null)<br> load_balancer_specifications             = optional(list(map(string)), null)<br> deployment_controller_type  = optional(string, null)<br> capacity_provider_strategy_specifications  = optional<br> (object({<br> base                = optional(number, null)<br> weight              = number<br> capacity_provider   = string<br> }),null)<br> enable_deployment_circuit_breaker =  optional(object({<br> enable_deployment_circuit_breaker      = optional(bool, false)<br> deployment_circuit_breaker_enable_rollback_on_failure   =  bool<br> }), null)<br> deployment_failure_detection_enable_cloudwatch_alarms = optional(object({<br> deployment_failure_detection_enable_cloudwatch_alarms     = bool<br> deployment_failure_detection_enable_rollback_on_failure    = bool<br> deployment_failure_detection_alarm_names = list(string)<br> }), null)<br> subnet_ids           = list(string)<br> assign_public_ip      = optional(bool, false)<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name = "input_cluster_task_definitions"></a>[cluster_task_definitions](#input\_cluster_task_definitions) | The Cluster task defination specification | <pre><code>list(object({<br> name                             = string<br> launch_types                     = list(string)<br> cpu                              = optional(string,null)<br> memory                           = optional(string,null)<br> network_mode                     = optional(string,null)<br> ipc_mode                         = optional(string,null)<br> pid_mode                         = optional(string,null)<br> skip_destroy                     = optional(bool,false)<br> inference_accelerator_device_name   = optional(string,null)<br> inference_accelerator_device_type   = optional(string,null)<br> ephemeral_storage_size              = optional(string,null)<br> proxy_configuration_details         =  optional(object({<br> container_name  = string<br> properties      =  map(string)<br> type            =  optional(string, "APPMESH")<br> }), null)<br> placement_constraints_details = optional(list(object({<br> expression      = optional(string, null)<br> type            = string<br> })),[])<br> runtime_platform_os_family  = optional(string,null)<br> runtime_platform_cpu_architecture = optional(string,null)<br> volume_details                    =  optional(list(object({<br> name                                            = string<br> host_path                                       = optional(string,null)<br> volume_type                                     =  string<br> docker_volume_configuration                     = optional(object({<br> autoprovision   = optional(bool,null)<br> driver_opts     = optional(map(string),null)<br> driver          = optional(string,null)<br> labels          = optional(map(string),null)<br> scope           = optional(string,null)<br> }),null)<br> efs_volume_configuration        =  optional(object({<br> file_system_id          = string<br> root_directory          = optional(string,null)<br> transit_encryption      = optional(string,"DISABLED")<br> transit_encryption_port = optional(string,null)<br> }),null)<br> })),[])<br> }))</code></pre> | Yes | `N/A` | `N/A` |
| <a name = "input_container_definitions"></a>[container_definitions](#input\_container_definitions) | Container defination for ecs | `string` | No | null | null |
| <a name = "input_log_group_skip_destroy"></a>[log_group_skip_destroy](#input\_log_group_skip_destroy) | ECS log group skip destroye | `bool` | No | false | `false` |
| <a name = "input_log_group_retention_period"></a>[log_group_retention_period](#input\_log_group_retention_period) | ECS log group retention period | `number` | No | 0 | `0` |
| <a name = "input_cloudwatch_name"></a>[cloudwatch_name](#input\_cloudwatch_name) | Cloudwatch name for logging | `string` | No | null | null |
| <a name = "input_use_runtime"></a>[use_runtime](#input\_use_runtime) | Flag for runtime | `bool` | No | false | `false` |
| <a name = "input_cluster_capacity_providers"></a>[cluster_capacity_providers](#input\_cluster_capacity_providers) | ECS Capacity provider | <pre><code>list(object({<br> name                                              = string<br> auto_scaling_group_arn                            = string<br> enable_container_aware_termination_protection     = optional(bool,true)<br> enable_ecs_managed_autoscaling                    = optional(bool,true)<br> maximum_scaling_step_size                         = optional(number, null)<br> minimum_scaling_step_size                         = optional(number, null)<br> target_capacity                                   = optional(number, null)<br> instance_warmup_period                            = optional(number, 300)<br> }))</code></pre> | No | null | <pre><code>[{<br> name                                              = "Testpocclustercapacity"<br> auto_scaling_group_arn                            = N/A<br> enable_container_aware_termination_protection     = true<br> enable_ecs_managed_autoscaling                    = true<br> maximum_scaling_step_size                         = null<br> minimum_scaling_step_size                         = null<br> target_capacity                                   = null<br> instance_warmup_period                            = 300<br> }]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ecs" {
  source                                       = "tfe.axisb.com/ax-tfe/ecs/aws"
  version                                      = "X.X.X"
                          
  create_ecs_cluster                           = true
  cloudwatch_name                              = "aws/eks/AXAWS-CoE-Fargate-Cluster/cluster"
  cluster_name                                 = "tfepocecs_cluster"
  kms_key_arn                                  = "arn:aws:kms:ap-south-1:695850308044:key/282f737a-404d-4dae-beb1-701bb1919d22" 
  cluster_logging_type                         = "OVERRIDE" 
  cluster_logging_enable_cloudwatch_encryption = true
  cluster_enable_container_insights            = true
  tags                                         = local.default_tags
  
   service_specifications                      = [{
                                                    name                            = "TFE-POC-Fargate"
                                                    launch_type                     = "FARGATE"
	                                                vpc_id                          = "vpc-0f2ccb142f9bd62aa"
  subnet_ids                                   = ["subnet-077007111db9c401f"]
    }]
    
   cluster_task_definitions                    = [{
                                                    cpu                              = "1024"
                                                    memory                           ="2048"
	                                                name                             = "fargate_task"
                                                    launch_types                     = ["FARGATE"]
                                                    network_mode                     = "awsvpc"
                                                 }]

   container_definitions                      =  jsonencode([
                                                         {
                                                            name = "first"
                                                            image = "service-first"
                                                            cpu = 10
                                                            memory = 512
                                                            essential = true
                                                            portMappings = [
                                                                            {
                                                                            containerPort = 80
                                                                            hostPort = 80
                                                                            }
                                                                           ]
                                                         }
                                                   ])



}

```