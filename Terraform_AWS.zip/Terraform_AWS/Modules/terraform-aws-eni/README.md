
# **AWS Network Interface Module**

Terraform module to create Network Interface on AWS

# **Description**

AWS Network Interface module is basically used to create and configure network interfaces on Amazon Web Services.This module takes attributes `subnet_id`,`private_ips`,`security_groups`,`instance_id` to create and configure network interfaces for connecting Amazon EC2 instances to your VPC.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_subnet_id"></a>[subnet\_id](#input\_subnet\_id) | Subnet required to create eni | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_description"></a>[description](#input\_description) | The description for the network interface | `string` | No | null | `The description for the network interface` |
| <a name = "input_interface_type"></a>[interface\_type](#input\_interface\_type) | Type of network interface to create, set efa for elastic fiber adapter | `string` | No | null | `efa` |
| <a name = "input_ipv4_prefixes"></a>[ipv4\_prefixes](#input\_ipv4\_prefixes) | One or more IPv4 prefixes assigned to the network interface | `list(string)` | No | [ ] | `["Example_Prefix_1","Example_Prefix_2"]` |
| <a name = "input_ipv6_address_list_enabled"></a>[ipv6\_address\_list\_enabled](#input\_ipv6\_address\_list\_enabled) | Whether the ipv6_address list is allowed or not | `bool` | No | false | `false` |
| <a name = "input_create_attachment"></a>[ipv6\_address\_list](#input\_create\_attachment) | Whether Eni attached to the instance | `bool` | No | false | `false` |
| <a name = "input_ipv6_address_list"></a>[ipv6\_address\_list](#input\_ipv6\_address\_list) | List of private ips to sassign to the ENI in sequential order | `list(string)` | No | [ ] | `["Example_ip_address_1","Example_ip_address_2"]` |
| <a name = "input_ipv6_prefixes"></a>[ipv6\_prefixes](#input\_ipv6\_prefixes) | One or more ipv6 prefixes assigned to the network interface | `list(string)` | No | [ ] | `["Example_ipv6_prefixes_1","Example_ipv6_prefixes_2"]` |
| <a name = "input_ipv6_addresses"></a>[ipv6\_addresses](#input\_ipv6\_addresses) | One or more ipv6 addreses assigned to the network interface | `list(string)` | No | [ ] | `["Example_ipv6_address_1","Example_ipv6_address_2"]` |
| <a name = "input_private_ip_list_enabled"></a>[private\_ip_list\_enabled](#input\_private\_ip\_list\_enabled) | Whether private_ip_list is allowed and controls the ips to assign to the eni. | `bool` | No | false | `false` |
| <a name = "input_private_ip_list"></a>[private\_ip\_list](#input\_private\_ip\_list) | List of private ips assign to the eni in sequential order | `list(string)` | No | [ ] | `["Example_private_ip_list_1","Example_private_ip_list_2"]` |
| <a name = "input_private_ips"></a>[private\_ips](#input\_private\_ips) | List of private ips assign to the eni | `list(string)` | No | [ ] | `["Example_private_ips_1","Example_private_ips_2"]` |
| <a name = "input_security_groups"></a>[security\_groups](#input\_security\_groups) | List of security group ids assign to the eni | `list(string)` | No | [ ] | `["sg-498rgfrh939eeg","sg-djb03db83uhd3e"]` |
| <a name = "input_source_dest_check"></a>[source\_dest\_check](#input\_source\_dest\_check) | Whether to enanabled source destination cheking for the eni | `string` | No | true | `true` |
| <a name = "input_instance_id"></a>[instance\_id](#input\_instance\_id) | Instance id attached to the ENI  | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_device_index"></a>[device\_index](#input\_device\_index) | Device index for the attachment | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |
## **Example Usage**

```hcl

module "vpc" {
  source                               = "tfe.axisb.com/ax-tfe/vpc/aws"
  version                              = "X.X.X"

  subnet_id                            = "your subnet id comes here"
  description                          = "The description for the network interface"
  create_attachment                    = true
  instance_id                          = "your ec2 instance id comes here"
  device_index                         = 1

  tags                                 = {
                                          Name = "Test"
                                         }

}

```