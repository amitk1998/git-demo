# **AWS SQS Module**

Terraform module to create SQS on AWS

# **Description**
 
 This module is basically used to create Simple Queue Service on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `sqs_queue_name`,`dlq_name`,`sqs_managed_sse_enabled`,`message_retention_seconds`,`sqs_queue_kms_master_key_id`,`sqs_queue_kms_data_key_reuse_period_seconds`,`sqs_policy` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_enable_dlq"></a>[enable\_dlq](#input\_enable\_dlq) | Enable SQS Dead Letter Queue | `bool` | No | false | `false` |
| <a name = "input_sqs_queue_name"></a>[sqs\_queue\_name](#input\_sqs\_queue\_name) | SQS Queue Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_dlq_name"></a>[dlq\_name](#input\_dlq\_name) | SQS dlq Name | `string` | No | `N/A` | `N/A` |
| <a name = "input_sqs_queue_kms_master_key_id"></a>[sqs\_queue\_kms\_master\_key\_id](#input\_sqs\_queue\_kms\_master\_key\_id) | sqs queue kms master key id | `string` | No | null | `"input kms master key id"` |
| <a name = "input_sqs_queue_kms_data_key_reuse_period_seconds"></a>[sqs\_queue\_kms\_data\_key\_reuse\_period\_seconds](#input\_sqs\_queue\_kms\_data\_key\_reuse\_period\_seconds) | sqs queue kms data key reuse period seconds | `number` | No | null | `600` |
| <a name = "input_sqs_tags"></a>[sqs\_tags](#input\_sqs\_tags) | SQS tags | `string` | No | { } | `{ }` |
| <a name = "input_sqs_dlq_tags"></a>[sqs\_dlq\_tags](#input\_sqs\_dlq\_tags) | SQS dlq tags | `string` | No | { } | `{ }` |
| <a name = "input_sqs_policy"></a>[sqs_policy](#input\_sqs_policy) | SQS Policy | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_sqs_managed_sse_enabled"></a>[sqs\_managed\_sse\_enabled](#input\_sqs\_managed\_sse\_enabled) | Enable SQS Managed SSE | `bool` | No | false | `false` |
| <a name = "input_message_retention_seconds"></a>[message\_retention\_seconds](#input\_message\_retention\_seconds) | SQS Message Retention Period in Seconds | `number` | No | 300 | `300` |
| <a name = "input_fifo_queue"></a>[fifo\_queue](#input\_fifo\_queue) | IS FIFO Queue? | `bool` | No | false | `false` |
| <a name = "input_fifo_throughput_limit"></a>[fifo\_throughput\_limit](#input\_fifo\_throughput\_limit) | FIFO Throughput Limit | `string` | No | null | `"input fifo throughput limit"` |
| <a name = "input_receive_wait_time_seconds"></a>[receive\_wait\_time\_seconds](#input\_receive\_wait\_time\_seconds) | Receive Message Wait Time Seconds | `number` | No | 0 | `0` |
| <a name = "input_visibility_timeout_seconds"></a>[visibility\_timeout\_seconds](#input\_visibility\_timeout\_seconds) | Visibility Timeout in Seconds | `number` | No | 30 | `30` |
| <a name = "input_max_message_size"></a>[max\_message\_size](#input\_max\_message\_size) | Maximum Message Size | `number` | No | null | `262144` |
| <a name = "input_delay_seconds"></a>[delay\_seconds](#input\_delay\_seconds) | Delay Period in Seconds | `number` | No | null | `0` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

locals {
  sqs_policy = jsonencode({
    "Version" : "2012-10-17",
    "Statement" : [
      {
        "Sid" : "SqsWrite",
        "Effect" : "Allow",
        "Principal" : {
            "Service" : [
                "sqs.amazonaws.com"
            ]
        },
        "Action" : [
            "sqs:SendMessage"
        ],
        "Resource" : "*"
      }
    ] 
  })
}

module "sqs" {
  source                                      = "tfe.axisb.com/ax-tfe/sqs/aws"
  version                                     = "X.X.X"

  sqs_queue_name                              = "example-sqs-queue"
  dlq_name                                    = "example-dlq-queue"
  sqs_managed_sse_enabled                     = false
  message_retention_seconds                   = 300
  sqs_queue_kms_master_key_id                 = "input sqs kms master key id"
  sqs_queue_kms_data_key_reuse_period_seconds = 300
  fifo_queue                                  = false                                  
  fifo_throughput_limit                       = null                      
  receive_wait_time_seconds                   = 10                 
  visibility_timeout_seconds                  = 30               
  max_message_size                            = 2048                            
  delay_seconds                               = 90                           
  enable_dlq                                  = true                                   
  sqs_policy                                  = local.sqs_policy
  sqs_tags                                    = { }
  sqs_dlq_tags                                = { }
  tags                                        = {
                                                 Name = "Test"
                                                }
}

```