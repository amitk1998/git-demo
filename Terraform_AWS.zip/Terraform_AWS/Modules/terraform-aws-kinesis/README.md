# **AWS Kinesis Module**

Terraform module to create Kinesis on AWS

# **Description**
 
 This module is basically used to create Kinesis on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS `name`, `type`,`stream_mode`,`firehose_extended_s3_configuration`,`kms_key_id` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_type"></a>[type](#input\_type) | Kinesis Type. Valid values are KINESIS_STREAMS, KINESIS_FIREHOSE, KINESIS_DATA_ANALYTICS, or KINESIS_VIDEO_STREAMS | `string` | No | "KINESIS_STREAMS" | `"KINESIS_STREAMS"` |
| <a name = "input_name"></a>[name](#input\_name) | Kinesis Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_stream_mode"></a>[stream\_mode](#input\_stream\_mode) | Kinesis Stream Capacity Mode for Kinesis Streams. Valid values are PROVISIONED or ON_DEMAND | `string` | No | "PROVISIONED" | `"PROVISIONED"` |
| <a name = "input_stream_shard_count"></a>[stream\_shard\_count](#input\_stream\_shard\_count) | Kinesis Stream Shard Count for Provisioned Type of Kinesis Streams | `number` | No | `1` | `1` |
| <a name = "input_stream_retention_period_hours"></a>[stream\_retention\_period\_hours](#input\_stream\_retention\_period\_hours) | Description | `number` | No | `24` | `24` |
| <a name = "input_stream_shard_level_metrics"></a>[stream_shard_level_metrics](#input\_stream_shard_level_metrics) | Kinesis Stream Shard Level Cloudwatch Metrics to be enabled for stream | `list(string)` | No | `["IncomingBytes", "OutgoingBytes"]` | `["IncomingBytes", "OutgoingBytes"]` |
| <a name = "input_stream_consumer_names"></a>[stream_consumer_names](#input\_stream_consumer_names) | Kinesis Stream Consumer Names | `list(string)` | No | `[ ]` | `["consumer1","consumer2"]` |
| <a name = "input_video_stream_device_name"></a>[video\_stream\_device\_name](#input\_video\_stream\_device\_name) | Kinesis Video Stream Device Name that is writing to the stream | `string` | No | `null` | `"video/h264"` |
| <a name = "input_firehose_destination_type"></a>[firehose\_destination\_type](#input\_firehose\_destination\_type) | Kinesis Firehose Destination. Valid values are extended_s3, redshift, elasticsearch, splunk, http_endpoint, or opensearch | `string` | No | `"extended_s3"` | `"extended_s3"` |
| <a name = "input_firehose_source_stream_arn"></a>[firehose\_source\_stream\_arn](#input\_firehose\_source\_stream\_arn) | Kinesis Stream ARN as a source for Firehose | `string` | No | `null` | `"input firehose source stream arn"` |
| <a name = "input_firehose_source_stream_access_iam_role_arn"></a>[firehose\_source\_stream\_access\_iam\_role\_arn](#input\_firehose\_source\_stream\_access\_iam\_role\_arn) | Firehose IAM Role ARN to provide access to Source Kinesis Stream, if used as a source | `string` | No | `null` | `"input your iam role arn"` |
| <a name = "input_firehose_enable_delivery_logging"></a>[firehose\_enable\_delivery\_logging](#input\_firehose\_enable\_delivery\_logging) | Firehose Enable Delivery Logging | `bool` | No | `true` | `true` |
| <a name = "input_firehose_extended_s3_configuration"></a>[firehose_extended_s3_configuration](#input\_firehose_extended_s3_configuration) | Firehose Extended S3 Configuration. Applicable when destination is extended_s3 | <pre><code>object({<br> 		s3_backup_mode = optional(string, "Disabled")<br> role_arn       = optional(string, null)<br> bucket_arn     = optional(string, null)<br> prefix         = optional(string, null)<br> enable_dynamic_partitioning = optional(bool, false)<br> dynamic_partitioning_retry_duration = optional(number, 300)<br> })</code></pre> | No | <pre><code>[<br>  {<br> s3_backup_mode                      = null<br> role_arn                            = aws_iam_role.firehose_role.arn<br>  bucket_arn                          = "arn:aws:s3:::tfe-axe-poc-s3"<br> }<br>  ]</code></pre> | <pre><code>[<br>  {<br> s3_backup_mode                      = null<br> role_arn                            = aws_iam_role.firehose_role.arn<br>  bucket_arn                          = "arn:aws:s3:::tfe-axe-poc-s3"<br> }<br>  ]</code></pre> |
| <a name = "input_firehose_elasticsearch_configuration"></a>[firehose\_elasticsearch\_configuration](#input\_firehose\_elasticsearch\_configuration) | Firehose ElasticSearch or Opensearch Configuration. Applicable when destination is elasticsearch or opensearch | <pre><code>object({<br> buffering_interval = optional(number, 300)<br> buffering_size = optional(number, 5)<br>  cluster_endpoint = optional(string, null)<br> index_name = optional(string, null)<br> index_rotation_period = optional(string, "OneDay")<br> retry_duration = optional(number, 300)<br> role_arn = optional(string, null)<br> s3_backup_mode = optional(string, "FailedDocumentsOnly")<br> name = optional(string, null)<br> vpc_config = optional(object({<br> subnet_ids 			= optional(list(string), null)<br> security_group_ids 	= optional(list(string), null)<br> role_arn 			= optional(string, null)<br> }), null)<br> })</code></pre> | No | <pre><code>{<br> buffering_interval =  300<br> buffering_size = 5<br> cluster_endpoint = "input your endpoint"<br> index_name = "example-index<br> index_rotation_period = "OneDay"<br> vpc_config = {<br> subnet_ids 			= ["subnet-4fhyh74y7hrdhg"]<br> security_group_ids 	= ["sg-36teygy74gry"]<br> role_arn 			= "input role arn"<br> }<br>  } </code></pre> | <pre><code>{<br> buffering_interval =  300<br> buffering_size = 5<br> cluster_endpoint = "input your endpoint"<br> index_name = "example-index<br> index_rotation_period = "OneDay"<br> vpc_config = {<br> subnet_ids 			= ["subnet-4fhyh74y7hrdhg"]<br> security_group_ids 	= ["sg-36teygy74gry"]<br> role_arn 			= "input role arn"<br> }<br>  } </code></pre> |
| <a name = "input_firehose_splunk_configuration"></a>[firehose_splunk_configuration](#input\_firehose\_splunk\_configuration) | Firehose Splunk Configuration. Applicable when destination is splunk | <pre><code>object({<br> hec_acknowledgment_timeout = optional(number, null)<br> hec_endpoint = optional(string, null)<br> hec_endpoint_type = optional(string, "Raw")<br> hec_token = optional(string, null)<br> s3_backup_mode = optional(string, "FailedEventsOnly")<br> retry_duration = optional(number, 300)<br> })</code></pre> | No | <pre><code>{<br> hec_acknowledgment_timeout = 300<br> hec_endpoint = "input endpoint"<br> hec_endpoint_type = "Raw"<br> hec_token = "input token"<br> s3_backup_mode = "FailedEventsOnly"><br> retry_duration = 300<br> }</code></pre> | <pre><code>{<br> hec_acknowledgment_timeout = 300<br> hec_endpoint = "input endpoint"<br> hec_endpoint_type = "Raw"<br> hec_token = "input token"<br> s3_backup_mode = "FailedEventsOnly"><br> retry_duration = 300<br> }</code></pre> |
| <a name = "input_firehose_redshift_configuration"></a>[firehose\_redshift\_configuration](#input\_firehose\_redshift\_configuration) | Firehose Redshift Configuration. Applicable when destination is redshift | <pre><code>object({<br> cluster_jdbcurl		= optional(string, null)<br> username			= optional(string, null)<br> password			= optional(string, null)<br> role_arn			= optional(string, null)<br> data_table_name		= optional(string, null)<br> data_table_columns	= optional(string, null)<br> copy_options		= optional(string, null)<br> s3_backup_mode 		= optional(string, "Disabled")<br> retry_duration 		= optional(number, 3600)<br> })</code></pre> | No | <pre><code>object{<br> cluster_jdbcurl		= "input cluster jdbc url"<br> username			= "admin"<br> password			= "admin123"<br> role_arn			= "input role arn"<br> data_table_name		= "test"<br> data_table_columns	= "testtb"<br> copy_options		= "null"<br> s3_backup_mode 		= "Disabled"<br> retry_duration    = 3600<br> }</code></pre> | <pre><code>{<br> cluster_jdbcurl		= "input cluster jdbc url"<br> username			= "admin"<br> password			= "admin123"<br> role_arn			= "input role arn"<br> data_table_name		= "test"<br> data_table_columns	= "testtb"<br> copy_options		= "null"<br> s3_backup_mode 		= "Disabled"<br> retry_duration    = 3600<br> }</code></pre> |
| <a name = "input_firehose_s3_backup_configuration"></a>[firehose\_s3\_backup\_configuration](#input\_firehose\_s3\_backup\_configuration) | DescriptFirehose S3 Backup Configuration. Applicable for all destinations | <pre><code>object({<br> role_arn = optional(string, null)<br> bucket_arn = optional(string, null)<br> prefix = optional(string, null)<br> buffering_size = optional(number, 5)<br> buffering_interval = optional(number, 300)<br> compression_format = optional(string, "UNCOMPRESSED")<br> error_output_prefix = optional(string, null)<br> kms_key_arn = optional(string, null)<br> })</code></pre> | No | <pre><code>{<br> role_arn = "input role arn"<br> bucket_arn = "test-example-buckets"<br> prefix = "null"<br> buffering_size = 5<br> buffering_interval = 300<br> compression_format = "UNCOMPRESSED"<br> error_output_prefix = "null"<br> kms_key_arn = "input kms key arn here"<br> }</code></pre> | <pre><code>{<br> role_arn = "input role arn"<br> bucket_arn = "test-example-buckets"<br> prefix = "null"<br> buffering_size = 5<br> buffering_interval = 300<br> compression_format = "UNCOMPRESSED"<br> error_output_prefix = "null"<br> kms_key_arn = "input kms key arn here"<br> }</code></pre> |
| <a name = "input_kms_key_id"></a>[kms\_key\_id](#input\_kms\_key\_id) | KMS Key ID | `string` | No | `null` | `"input kms key id here"` |
| <a name = "input_log_group_kms_key_arn"></a>[log\_group\_kms\_key\_arn](#input\_log\_group\_kms\_key\_arn) | Log Group KMS Key ARN | `string` | No | `null` | `"input log group kms key arn here"` |
| <a name = "input_log_group_retention_period"></a>[log\_group\_retention\_period](#input\_log\_group\_retention\_period) | Log Group Retention Period | `number` | No | `7` | `7` |
| <a name = "input_log_group_skip_destroy"></a>[log\_group\_skip\_destroy](#input\_log\_group\_skip\_destroy) | Log Group Skip Destroy | `bool` | No | `false` | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "kinesis_streams" {
  source      = "tfe.axisb.com/ax-tfe/kinesis/aws"
  version     = "X.X.X"
  
  type        = "KINESIS_STREAMS"
  name        = "terraform-test-kinesis-streams-597"
  stream_mode = "PROVISIONED"
  kms_key_id  = "arn:aws:kms:ap-south-1:123456789:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"

  tags        = {
                 Name = "Test"
                }
}

```

```hcl

module "kinesis_videostreams" {
  source      = "tfe.axisb.com/ax-tfe/kinesis/aws"
  version     = "X.X.X"
  
  type        = "KINESIS_VIDEO_STREAMS"
  name        = "terraform-test-kinesis_video-streams-597"
  stream_mode = "PROVISIONED"
  kms_key_id  = "arn:aws:kms:ap-south-1:123456789:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"

  tags        = {
                 Name = "Test"
                }
  }

```

```hcl

module "kinesis_firehose" {
  source      = "tfe.axisb.com/ax-tfe/kinesis/aws"
  version     = "X.X.X"
  
  type        = "KINESIS_FIREHOSE"
  name        = "terraform-test-kinesis_firehose-streams-597"
  kms_key_id  = "arn:aws:kms:ap-south-1:123456789:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  firehose_extended_s3_configuration = {
	s3_backup_mode                      = null
	role_arn                            = aws_iam_role.firehose_role.arn
	bucket_arn                          = "arn:aws:s3:::tfe-axe-poc-s3"

}
  tags        = {
                 Name = "Test"
                }
}

```