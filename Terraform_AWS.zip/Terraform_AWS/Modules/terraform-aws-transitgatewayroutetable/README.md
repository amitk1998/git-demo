# **AWS Transitgateway RouteTable Module**

Terraform module to create Transitgateway RouteTable on AWS

# **Description**
 
 This module is basically used to create Transitgateway RouteTable on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `transit_gateway_attachment_id`,`association_route_table_id`,`propagation_route_table_id`,`ingress_route_table_id`,`dmz_subnets_cidr`  etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_transit_gateway_attachment_id"></a>[transit\_gateway\_attachment\_id](#input\_transit\_gateway\_attachment\_id) | Transit Gateway Attachment ID | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_dmz_subnets_cidr"></a>[dmz\_subnets\_cidr](#input\_dmz\_subnets\_cidr) | DMZ Subnets Cidrs | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_association_route_table_id"></a>[association\_route\_table\_id](#input\_association\_route\_table\_id) | Association Route Table Ids | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_propagation_route_table_id"></a>[propagation\_route\_table\_id](#input\_propagation\_route\_table\_id) | Propagation Route Table ids | `list(string)` | Yes | `N/A` | `N/A` |
| <a name = "input_ingress_route_table_id"></a>[ingress\_route\_table\_id](#input\_ingress\_route\_table\_id) | Ingress Route Table ids | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "transitgatewayroutetable" {
  source                        = "tfe.axisb.com/ax-tfe/transitgatewayroutetable/aws"
  version                       = "X.X.X"

  transit_gateway_attachment_id = "tgw-attach-25251"
  association_route_table_id    = "rtb-7ywu3e833828u28uw"
  propagation_route_table_id    = "tgw-rtb-2398uu28yuwu2i"
  ingress_route_table_id        = "tgw-rtb-8778yw2w7uwu2i"
  dmz_subnets_cidr              = ["10.0.0.64/24","10.0.0.96/27"]

  tags                          = {
                                   Name = "Test"
                                  }
}

```