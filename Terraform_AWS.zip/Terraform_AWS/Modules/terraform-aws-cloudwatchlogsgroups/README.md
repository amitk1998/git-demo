# **AWS  CloudWatchLogGroups Module**

Terraform module to create CloudWatchLogGroups on AWS

# **Description**
 
 This module is basically used to  create CloudWatchLogGroups on Amazon Web Services(AWS).
 It requires these attributes in order to be created on aws `alarm_name`,`alarm_description`,`comparison_operator`,`evaluation_periods`,`metric_name`,`namespace`,`period`,`statistic` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_name"></a>[name](#input\_name) | Log group Name | `string` | No | `null` | `"example-loggroups"` |
| <a name="input_kms_key_arn"></a>[kms_key_arn](#input\_kms_key_arn) | Log Group KMS key ARN | `string` | No | `null` | `"input kms key arn"` |
| <a name="input_retention_period"></a>[retention\_period](#input\_retention\_period) | Log Group Retention period | `number` | No | `0` | `0` |
| <a name="input_name_prefix"></a>[name\_prefix](#input\_name\_prefix) | Enter the name_prefix | `string` | No | `null` | `"Example-Loggroups"` |
| <a name="input_skip_destroy"></a>[skip\_destroy](#input\_skip\_destroy) | Do you want to skip destroy of cloudwatch | `bool` | No | `false` | `false` |
| <a name="input_tags"></a>[tags](#input\_tags) | Resource Tags. | `map(string)` | No | `{ }` | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "cloudwatchloggroups" {
  source              = "tfe.axisb.com/ax-tfe/cloudwatchloggroups/aws"
  version             = "X.X.X"

  name              = "example-loggroups"
  kms_key_arn       = "arn:aws:kms:ap-south-1:123456789:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf"
  retention_period  = 12
  skip_destroy      = false

  tags              = {
                       Name = "Test"
                      }

}

```