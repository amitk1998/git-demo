
# **AWS VPC Module**

Terraform module to create VPC on AWS

# **Description**
 
 This module is basically used to create and manage Virtual Private Clouds(VPCs) on Amazon Web Services(AWS).
 It provides the flexibility to create new VPC with various configuration options like `CIDR block`,`DNS settings` or Optionally, associate `Secondary CIDR` with VPC and Optionally,configure `DHCP options` and associate them with the VPC.For managing existing VPC you can use `existing_vpc_id`.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_existing_vpc_id"></a>[existing\_vpc\_id](#input\_existing\_vpc\_id) | The VPC Id used for existing VPC | `string` | No | null | `"vpc-00f1dcb56dhj908dhf"` |
| <a name = "input_instance_tenancy"></a>[instance_tenancy](#input\_instance\_tenancy) | A instance_tenancy option for instances launched into the VPC |`string`| No | null | `"default"` |
| <a name = "input_vpc_cidr"></a>[vpc_cidr](#input\_vpc\_cidr) | IPV4 CIDR Block | `string` | No | null | `10.0.0.0/16` |
| <a name = "input_secondary_cidrs"></a>[secondary_cidrs](#input\_secondary\_cidrs) | Seconadry CIDR Block associated with vpc to extend the IP Address pool | `list(string)` | No | [ ] | `[100.65.0.0/20,100.64.0.0/20]` |
| <a name = "input_enable_dns_hostname"></a>[enable_dns_hostname](#input\_enable\dns_\_hostname) | DNS hostname used for the VPC | `bool` | No | false | `false` |
| <a name = "input_enable_dns_support"></a>[enable_dns_support](#input\_enable\_dns\_support) | DNS support used for the VPC | `bool` | No | true | `true` |
| <a name = "input_assign_generated_ipv6_cidr_block"></a>[assign_generated_ipv6_cidr_block](#input\_assign\_generated\_ipv6\_cidr\_block) | Requests an Amazon provided IPv6 CIDR block with a /56 prefix length for the VPC.You can Not specify the range of IP Addresses , or the size of the CIDR block | `bool` | No | false | `false` |
| <a name = "input_enable_network_address_usage_metrics"></a>[enable_network_address_usage_metrics](#input\_enable\_network\_address\_usage\_metrics) | Indicates whether network address usage metrics are enabled for vpc.| `bool` | No | false | `false` |
| <a name = "input_enable_dhcp_options"></a>[enable_dhcp_options](#input\_enable\_dhcp\_options) | Should be true if you want to specify a DHCP options set with a custom domain name, NTP servers , netbios servers , and/or netbios server type | `bool` | No | false | `false` |
| <a name = "input_dhcp_options_id"></a>[dhcp_options_id](#input\_dhcp\_options\_id) | The ID of DHCP option Set to associate with VPC | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_dhcp_options_domain_name"></a>[dhcp_options_domain_name](#input\_dhcp\_options\_domain\_name) | Specifies DNS name for DHCP options set (requires enable_dhcp_options set to true) | `string` | No | null | `"service.counsel"` |
| <a name = "input_dhcp_options_domain_name_servers"></a>[dhcp_options_domain_name_servers](#input\_dhcp\_options\_domain\_name\_servers) | Specify a list of DNS server addresses for DHCP options set, default to AWS provided(requires enable_dhcp_options set to true) | `list(string)` | No | `["AmazonProvidedDNS"]` | `["AmazonProvidedDNS"]` |
| <a name = "input_dhcp_options_ntp_servers"></a>[dhcp_options_ntp_servers](#input\_dhcp\_options\_ntp\_servers) | Specify a list of NTP servers for DHCP options set(requires enable_dhcp_options set to true) | `list(string)` | No | [ ] | `[127.0.0.1]` |
| <a name = "input_dhcp_options_netbios_name_servers"></a>[dhcp_options_netbios_name_servers](#input\_dhcp\_options\_netbios\_name\_servers) | Specify a list of netbios servers for DHCP options set(requires enable_dhcp_options set to true) | `list(string)` | No | [ ] | `[127.0.0.1]` |
| <a name = "input_dhcp_options_netbios_Node_type"></a>[dhcp_options_netbios_Node_type](#input\_dhcp\_options\_netbios\_Node\_type) | Specify netbios Node_type for DHCP options set(requires enable_dhcp_options set to true) | `number` | No | null | `2` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "vpc" {
  source                               = "tfe.axisb.com/ax-tfe/vpc/aws"
  version                              = "X.X.X"

  vpc_cidr                             = "10.0.0.0/16"
  secondary_cidrs                      = [100.65.0.0/20,100.64.0.0/20]

  tags                                 = {
                                          Name = "Test"
                                         }

}

```