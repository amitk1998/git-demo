# **AWS Datasync Module**

Terraform module to create Datasync on AWS

# **Description**
 
 This module is basically used to create Datasync on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `use_options`,`destination_location_arn`,`name`,`source_location_arn`,`cloudwatch_log_group_arn`,`schedule_expression` etc.

# **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name="input_use_options"></a>[use\_options](#input\_use\_options) | Set to true to include options block, false to exclude it | `bool` | No | `false` | `false` |
| <a name="input_destination_location_arn"></a>[destination\_location\_arn](#input\_destination\_location\_arn) | ARN of the destination location for the DataSync task | `string` | Yes | `N/A` | `N/A` |
| <a name="input_name"></a>[name](#input\_name) | Name for the DataSync task | `string` | Yes | `N/A` | `N/A` |
| <a name="input_source_location_arn"></a>[source\_location\_arn](#input\_source\_location\_arn) | ARN of the source location for the DataSync task | `string` | Yes | `N/A` | `N/A` |
| <a name="input_cloudwatch_log_group_arn"></a>[cloudwatch\_log\_group\_arn](#input\_cloudwatch\_log\_group\_arn) | ARN of the CloudWatch log group for the DataSync task (Optional) | `string` | No | null | `null` |
| <a name="input_options"></a>[options](#input\_options) | Options for the DataSync task | <pre><code>object({<br> atime                      = optional(string)<br> bytes_per_second           = optional(string)<br> gid                        = optional(string)<br> log_level                  = optional(string)<br> mtime                      = optional(string)<br> object_tags                = optional(string)<br> overwrite_mode             = optional(string)<br> posix_permissions          = optional(string)<br> preserve_deleted_files     = optional(string)<br> preserve_devices           = optional(string)<br> security_descriptor_copy_flags = optional(string)<br> task_queueing              = optional(string)<br> transfer_mode              = optional(string)<br> uid                        = optional(string)<br> verify_mode                = optional(string)<br> })</code></pre> | No | `null` | `null` |
| <a name="input_excludes"></a>[excludes](#input\_excludes) | Excludes configuration for the DataSync task | `map(string)` | No | `{ "filter_type" = "SIMPLE_PATTERN", "value" = "/folder1|/folder2" }` | `{ "filter_type" = "SIMPLE_PATTERN", "value" = "/folder1|/folder2" }` |
| <a name="input_includes"></a>[includes](#input\_includes) | Includes configuration for the DataSync task | `map(string)` | No | `{ "filter_type" = "SIMPLE_PATTERN", "value" = "/folder1|/folder2" }` | `{ "filter_type" = "SIMPLE_PATTERN", "value" = "/folder1|/folder2" }` |
| <a name="input_schedule_expression"></a>[schedule\_expression](#input\_schedule\_expression) | Schedule expression for the DataSync task | `string` | Yes | `N/A` | `N/A` |
| <a name="input_tags"></a>[tags](#input\_tags) | Tags for the DataSync task | `map(string)` | No | `{ "Name" = "DataSyncTask", "Environment" = "Production" }` | `{ "Name" = "DataSyncTask", "Environment" = "Production" }` |
| <a name="input_datasync_agent_name"></a>[datasync\_agent\_name](#input\_datasync\_agent\_name) | The name of the DataSync agent | `string` | Yes | `N/A` | `N/A` |
| <a name="input_ip_address"></a>[ip\_address](#input\_ip\_address) | The IP address or DNS name of the DataSync agent | `string` | No | `null` | `null` |
| <a name="input_security_group_arns"></a>[security\_group\_arns](#input\_security\_group\_arns) | A list of Amazon Resource Names (ARNs) of security groups for the DataSync agent | `list(string)` | No | `[]` | `[]` |
| <a name="input_subnet_arns"></a>[subnet\_arns](#input\_subnet\_arns) | A list of Amazon Resource Names (ARNs) of subnets for the DataSync agent | `list(string)` | No | `[]` | `[]` |
| <a name="input_vpc_endpoint_id"></a>[vpc\_endpoint\_id](#input\_vpc\_endpoint\_id) | The ID of the VPC endpoint the agent will use for connections | `string` | No | null | `"input vpc endpoint id"` |
| <a name="input_private_link_endpoint"></a>[private\_link\_endpoint](#input\_private\_link\_endpoint) | The private link endpoint for the DataSync agent (optional). Set to null if not using private link | `string` | No | `null` | `input private link endpoint` |
| <a name="input_agent_tag"></a>[agent\_tag](#input\_agent\_tag) | A map of tags to apply to the DataSync agent | `map(string)` | No | `{}` | `N/A` |

## **Example Usage**

```hcl

module "datasync" {
  source                    = "tfe.axisb.com/ax-tfe/datasync/aws"
  version                   = "X.X.X"

  use_options               = true
  destination_location_arn  = "s3://tfe-axe-poc-s3/example/target/"
  name                      = "example-datasyncloc"
  source_location_arn       = "s3://tfe-axe-poc-s3/example/source/"
  cloudwatch_log_group_arn  = "arn:aws:logs:us-east-1:123456789012:log-group/your-log-group"
  schedule_expression       = "cron(0 12 ? * SUN,WED *)"
 
  tags                      = {
                               Name = "Test"
                              }
}

```