# **AWS EBS Module**

Terraform module to create Elastic Block Store on AWS

# **Description**
 
 This module is basically used to create Elastic Block Store Volume on Amazon Web Services(AWS).
 To create EBS volume it requires few attributes like `availability_zone`,`size`,`type`,`encrypted` etc.
 To attach the created volume with ec2 instance it require some of attributes like `device_name`,`volume_id`,`instance_id` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_availability_zone"></a>[availability\_zone](#input\_availability\_zone) | The availability_zone for EBS volume | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_ebs_size"></a>[ebs\_size](#input\_ebs\_size) | The size of the  EBS volume in GB | `number` | No | 20 | `20` |
| <a name = "input_ebs_type"></a>[ebs\_type](#input\_ebs\_type) | The EBS volume type | `string` | No | gp2 | `gp2` |
| <a name = "input_is_encrypted"></a>[is\_encrypted](#input\_is\_encrypted) | Whether Volume is encrypted or not | `bool` | No | true | `true` |
| <a name = "input_kms_key_id"></a>[kms\_key\_id](#input\_kms_key_id) | Whether the final snapshot create or not | `string` | No | null | `arn:aws:kms:ap-south-1:1234567890:key/5070a2c8-8a8b-49b8-baf7-9558f9270ebf` |
| <a name = "input_final_snapshot"></a>[final\_snapshot](#input\_final\_snapshot) | Whether the final snapshot create or not. | `bool` | No | false | `false` |
| <a name = "input_iops"></a>[iops](#input\_iops) | The amount of iops to provision for the desk | `number` | No | null | `10` |
| <a name = "input_multi_attach_enabled"></a>[multi\_attach\_enabled](#input\_multi\_attach\_enabled) | Specifies whether to enabled Amazon EBS Multi_Attach | `bool` | No | null | `false` |
| <a name = "input_throughput"></a>[throughput](#input\_throughput) | Enter the throughput | `number` | No | null | `20` |
| <a name = "input_outpost_arn"></a>[outpost\_arn](#input\_outpost\_arn) | Enter the outpost arn | `string` | No | null | `mention outpost arn` |
| <a name = "input_device_name"></a>[device\_name](#input\_device\_name) | Enter the device_name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_volume_id"></a>[volume\_id](#input\_volume\_id) | Volume Id | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_instance_id"></a>[instance\_id](#input\_instance\_id) | Enter the instence_id | `string` | No | `N/A` | `N/A` |
| <a name = "input_force_detach"></a>[force\_detach](#input\_force\_detach) | Set true to create  Snapshot copy | `bool` | No | true | `true` |
| <a name = "input_skip_destroy"></a>[skip\_destroy](#input\_skip\_destroy) | Set true if you do not want to  detached volume | `bool` | No | false | `false` |
| <a name = "input_stop_instance_before_detaching"></a>[stop\_instance\_before\_detaching](#input\_stop\_instance\_before\_detaching) | Set true to ensure that the target instence is stopped before trying to detached the volume | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "ebs" {
  source                   = "tfe.axisb.com/ax-tfe/ebs/aws"
  version                  = "X.X.X"
  
  availability_zone        = "ap-south-1"
  ebs_type                 = "gp2"
  device_name              = "\dev\sdh"
  instance_id              = "your ec2 instance id comes here"
  tags                     = {
                              Name = "Test"
                             }
  
}

```