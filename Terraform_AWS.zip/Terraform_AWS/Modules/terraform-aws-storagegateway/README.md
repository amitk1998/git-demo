# **AWS Storage Gateway Module**

Terraform module to create Storage Gateway on AWS

# **Description**
 
 This module is basically used to create Storage Gateway on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `create_storage_gateway`,`gateway_name`,`gateway_timezone`,`gateway_ip_address`,`gateway_type` `smb_active_directory_settings`,`log_group_retention_period`  etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_create_storage_gateway"></a>[create\_storage\_gateway](#input\_create\_storage\_gateway) | Create Storage Gateway | `bool` | No | true | `true` |
| <a name = "input_existing_gateway_id"></a>[existing\_gateway\_id](#input\_existing\_gateway\_id) | Existing Storage Gateway ID | `string` | No | null | `null` |
| <a name = "input_gateway_name"></a>[gateway\_name](#input\_gateway\_name) | Storage Gateway Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_gateway_timezone"></a>[gateway\_timezone](#input\_gateway\_timezone) | Storage Gateway Timezone in format 'GMT', 'GMT+hr:mm' or 'GMT-hr:mm' | `string` | No | null | `"GMT+5:30"` |
| <a name = "input_gateway_ip_address"></a>[gateway\_ip\_address](#input\_gateway\_ip\_address) | Storage Gateway IP Address to retrieve Activation Key | `string` | No | null | `"1.2.3.4"` |
| <a name = "input_gateway_activation_key"></a>[gateway\_activation\_key](#input\_gateway\_activation\_key) | Storage Gateway Activation Key. Must be skipped if gateway_ip_address is provided | `string` | No | null | `null` |
| <a name = "input_gateway_type"></a>[gateway\_type](#input\_gateway\_type) | Storage Gateway Type. Supported values are CACHED, STORED, FILE_FSX_SMB, FILE_S3, or VTL | `string` | No | null | `"FILE_S3"` |
| <a name = "input_storage_gateway_vpc_endpoint_dns_name"></a>[storage\_gateway\_vpc\_endpoint\_dns\_name](#input\_storage\_gateway\_vpc\_endpoint\_dns\_name) | Storage Gateway VPC Endpoint DNS Name | `string` | No | null | `null` |
| <a name = "input_gateway_medium_changer_type"></a>[gateway\_medium\_changer\_type](#input\_gateway\_medium\_changer\_type) | Storage Gateway Medium Changer Type. Supported values are STK-L700, AWS-Gateway-VTL, or IBM-03584L32-0402 | `string` | No | null | `"STK-L700"` |
| <a name = "input_avg_download_rate_in_bits_per_sec"></a>[avg\_download\_rate\_in\_bits\_per\_sec](#input\_avg\_download\_rate\_in\_bits\_per\_sec) | Storage Gateway Avergae Download Bandwidth Rate Limit in Bits/Sec. Only Supported for CACHED, STORED, OR VTL Type Gateway | `string` | No | null | `null` |
| <a name = "input_avg_upload_rate_in_bits_per_sec"></a>[avg\_upload\_rate\_in\_bits\_per\_sec](#input\_avg\_upload\_rate\_in\_bits\_per\_sec) | Storage Gateway Avergae Upload Bandwidth Rate Limit in Bits/Sec. Only Supported for CACHED, STORED, OR VTL Type Gateway | `number` | No | null | `null` |
| <a name = "input_smb_security_strategy"></a>[smb\_security\_strategy](#input\_smb\_security\_strategy) | SMB Security Strategy Type. Supported values are ClientSpecified, MandatorySigning, or MandatoryEncryption | `string` | No | null | `"ClientSpecified"` |
| <a name = "input_smb_guest_password"></a>[smb\_guest\_password](#input\_smb\_guest\_password) | SMB Guest User Password. Only Supported for FILE_S3 or FILE_FSX_SMB Type Gateway | `string` | No | null | `null` |
| <a name = "input_smb_active_directory_settings"></a>[smb\_active\_directory\_settings](#input\_smb\_active\_directory\_settings) | SMB Active Directory Settings | <pre><code>object({<br> domain_name			= string<br> username			= string<br> password			= string<br> timeout_in_seconds	= optional(number, 20)<br> domain_controllers	= optional(list(string), null)<br> organizational_unit	= optional(string, null)<br> })</code></pre> | No | null | <pre><code>{<br> domain_name			= "corp.example.com"<br> username			= "Admin"<br> password			= "Admin@12345"<br> timeout_in_seconds	= 20<br> domain_controllers	= []<br> organizational_unit	= []<br> }</code></pre> |
| <a name = "input_maintenance_settings"></a>[maintenance\_settings](#input\_maintenance\_settings) | Storage Gateway Maintenance Settings | <pre><code>object({<br> day_of_month	= optional(number, null)<br> day_of_week		= optional(number, null)<br> hour_of_day		= optional(number, null)<br> minute_of_hour	= optional(number, null)<br> })</code></pre> | No | null | <pre><code>{<br> day_of_month	 = 5<br> day_of_week     = 6<br> hour_of_day     = 4<br> minute_of_hour  = 30<br> }</code></pre> |
| <a name = "input_log_group_kms_key_arn"></a>[log\_group\_kms\_key\_arn](#input\_log\_group\_kms\_key\_arn) | Storage Gateway Log Group KMS Key ARN | `string` | No | null | `null` |
| <a name = "input_log_group_retention_period"></a>[log\_group\_retention\_period](#input\_log\_group\_retention\_period) | Storage Gateway Log Group Retention Period | `string` | No | null | `null` |
| <a name = "input_log_group_skip_destroy"></a>[log\_group\_skip\_destroy](#input\_log\_group\_skip\_destroy) | Storage Gateway Log Group Skip Destroy | `string` | No | null | `null` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "storagegateway" {
  source                        = "tfe.axisb.com/ax-tfe/storagegateway/aws"
  version                       = "X.X.X"
  
  create_storage_gateway        = true
  existing_gateway_id           = null
  gateway_name                  = "example"
  gateway_timezone              = "GMT+5:30"
  gateway_ip_address            = "1.2.3.4"
  gateway_activation_key        = null
  gateway_type                  = "FILE_S3"
  smb_security_strategy         = "ClientSpecified"
  smb_guest_password            = "test123"
  smb_active_directory_settings = {domain_name = "corp.example.com",username = "Admin",password = "Admin@26526"}
  log_group_retention_period    = 7
  log_group_skip_destroy        = false

  tags                          = {
                                   Name = "Test"
                                  }

}

```