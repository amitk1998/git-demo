# **AWS ELB Module**

Terraform module to create ELB on AWS

# **Description**
 
 This module is basically used to create Elastic Load Balancer on Amazon Web Services(AWS).
 This module includes creation of `Application Loadbalancer`,`Network Loadbalancer` which additionally consist creation of listener and target groups.
 To create loadbalancer this modules requires attributes like  `name`,`type`,`subnet_ids`,`security_groups_id`,`listener_specifications` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_name"></a>[name](#input\_name) | Load Balancer Name | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_type"></a>[type](#input\_type) | Load Balancer Type. Valid values are application, network or gateway. | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_subnet_ids"></a>[subnet\_ids](#input\_subnet\_ids) | Load Balancer Subnet IDs | `list(string)` | No | null | `["subnet-76hehhbdb27ejno","subnet-10hehhbdb27ejno"]` |
| <a name = "input_sg_ids"></a>[sg\_ids](#input\_sg\_ids) | Load Balancer Security Group IDs. Only applicable for application or network load balancer | `list(string)` | No | null | `["sg-dh27jejdjh27eh"]` |
| <a name = "input_is_internal"></a>[is\_internal](#input\_is\_internal) | Is Load Balancer Type Internal | `bool` | No | false | `false` |
| <a name = "input_enable_http2"></a>[enable\_http2](#input\_enable\_http2) | Enable HTTP V2 for Application Load Balancer. Only applicable for application load balancer | `bool` | No | true | `true` |
| <a name = "input_desync_mitigation_mode"></a>[desync\_mitigation\_mode](#input\_desync\_mitigation\_mode) | Desync Mitigation Mode determines how Load Balancer will handle request that pose security risk. Valid values are monitor, defensive, or strictest. | `string` | No | `"defensive"` | `"defensive"` |
| <a name = "input_drop_invalid_header_fields"></a>[drop\_invalid\_header\_fields](#input\_drop\_invalid\_header\_fields) | Drop invalid header fields. Only applicable for application load balancer | `bool` | No | false | `false` |
| <a name = "input_enable_cross_zone_load_balancing"></a>[enable\_cross\_zone\_load\_balancing](#input\_enable\_cross\_zone\_load\_balancing) | Enable Cross Zone Load Balancing | `bool` | No | false | `false` |
| <a name = "input_enable_deletion_protection"></a>[enable\_deletion\_protection](#input\_enable\_deletion\_protection) | Enable Delete Protection | `bool` | No | true | `true` |
| <a name = "input_enable_tls_version_and_cipher_suite_headers"></a>[enable\_tls\_version\_and\_cipher\_suite\_headers](#input\_enable\_tls\_version\_and\_cipher\_suite\_headers) | Enable TLS Version and Cipher Suite Headers. Only applicable for application load balancer | `bool` | No | false | `false` |
| <a name = "input_enable_xff_client_port"></a>[enable\_xff\_client\_port](#input\_enable\_xff\_client\_port) | Enable Client Port Preservation. Only applicable for application load balancer | `bool` | No | false | `false` |
| <a name = "input_preserve_host_header"></a>[preserve\_host\_header](#input\_preserve\_host\_header) | Preserve Host Header. Only applicable for application load balancer | `bool` | No | false | `false` |
| <a name = "input_xff_header_processing_mode"></a>[xff\_header\_processing\_mode](#input\_xff\_header\_processing\_mode) | X-Forwarded-For Header Processing Mode. Valid values are append, preserve, or remove. Only applicable for application load balancer | `string` | No | `"append"` | `"append"` |
| <a name = "input_enable_waf_fail_open"></a>[enable\_waf\_fail\_open](#input\_enable\_waf\_fail\_open) | Enable Request to passthrough if Load Balancer is unable to forward request to WAF | `bool` | No | false | `false` |
| <a name = "input_idle_timeout"></a>[idle\_timeout](#input\_idle\_timeout) | Idle Timeout. Only applicable for application load balancer | `number` | No | null | `60` |
| <a name = "input_ip_address_type"></a>[ip\_address\_type](#input\_ip\_address\_type) | IP Address Type. Valid values are ipv4 or dualstack | `string` | No | `"ipv4"` | `"ipv4"` |
| <a name = "input_enable_access_logging"></a>[enable\_access\_logging](#input\_enable\_access\_logging) | Enable Access Logging | `bool` | No | true | `true` |
| <a name = "input_access_logging_bucket_id"></a>[access\_logging\_bucket\_id](#input\_access\_logging\_bucket\_id) | Access Logging Bucket ID or Bucket name| `string` | No | null | `"example-test-bucket"` |
| <a name = "input_access_logging_bucket_prefix"></a>[access\_logging\_bucket\_prefix](#input\_access\_logging\_bucket\_prefix) | Access Logging Bucket Path Prefix | `string` | No | null | `"example-prefix"` |
| <a name = "input_listener_specifications"></a>[listener\_specifications](#input\_listener\_specifications) | Load Balancer Listener with Target Group Specifications | <pre><code>list(object({<br>acm_certificate_arn = optional(string, null)<br>alpn_policy = optional(string, null)<br>port = optional(number, null)<br>protocol  = optional(string, null)<br>ssl_policy = optional(string, null)<br>type = optional(string, null)<br>order = optional(number, null)<br>forward_specification = optional(object({<br> content_type = optional(string, null)<br>message_body = optional(string, null)<br>status_code = optional(string, null)<br> }),null)<br>redirect_specification = optional(object({<br>status_code = optional(string, null)<br>host = optional(string, null)<br>path = optional(string, null)<br>port = optional(number, null)<br>protocol = optional(string, null)<br>query = optional(string, null)}), null)<br>target_group_specifications = optional(object({<br>name = optional(string, null)<br>port = optional(number, null)  <br>target_type = optional(string, null)<br>ip_address_type = optional(string, null)  <br>vpc_id = optional(string, null)<br>preserve_client_ip = optional(bool, null)<br>protocol = optional(string, null)<br>protocol_version = optional(string, null)  <br>proxy_protocol_v2 = optional(bool, null)<br>slow_start = optional(number, null) <br>connection_termination = optional(bool, null)<br>deregistration_delay = optional(number, null)<br>load_balancing_algorithm_type = optional(string, null)  <br>enable_health_check = optional(bool, null)<br>health_check_healthy_threshold = optional(number, null)<br>health_check_unhealthy_threshold = optional(number, null)  <br>health_check_interval = optional(number, null)<br>health_check_matcher = optional(string, null)<br>health_check_path = optional(string, null)<br>health_check_port = optional(string, null)<br>health_check_protocol = optional(string, null)  <br>health_check_timeout = optional(number, null)<br>enable_stickiness = optional(bool, null)<br>stickiness_cookie_duration = optional(number, null)<br>stickiness_type = optional(string, null)<br>stickiness_cookie_name = optional(string, null)<br>target_ids = optional(list(string), [])<br>target_port = optional(number, null) })), null}))</code></pre> | No | null | <pre><code><br>[<br>  {<br>port = 80 protocol = "HTTP" type = "fixed-response" order = 1 forward_specification = { content_type = "text/plain" message_body = "This is fixed respone" status_code = "200" } redirect_specification = { status_code = "HTTP_302" host = "www.testapp.com" path = "/testapp" } target_group_specifications = { name = "Test-Application-Loadbalancer" protocol = "HTTP" port = 80 target_type = "instance" vpc_id = "vpc-0df41afb90386ae13" target_ids = ["i-0f6e6690788cf08f2","i-0f6e6690788cf08f2"] target_port = 80 enable_health_check = true health_check_healthy_threshold = 3 health_check_unhealthy_threshold = 3 health_check_interval = 30 health_check_matcher = "200-399" health_check_path = "/healthz" health_check_port = "traffic-port" health_check_protocol = "HTTP" health_check_timeout = 6 enable_stickiness = true stickiness_cookie_duration = 86400 stickiness_type = "lb_cookie" stickiness_cookie_name = "app-cookie"<br> } <br> } <br>]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

Application Loadbalancer
------------------------

module "elb_application" {
  source                                      = "tfe.axisb.com/ax-tfe/elb/aws"
  version                                     = "X.X.X"
  
  name                                        = "application-loadbalancer"
  type                                        = "application"
  subnet_ids                                  = ["subnet-1a3eyghbdb10","subnet-sf4gvgv365gv2"]
  sg_ids                                      = ["sg-26tywgvtt76tva"]
  is_internal                                 = true
  enable_access_logging                       = true
  enable_deletion_protection                  = false
  listener_specifications                     = [{ port = 80 protocol = "HTTP" type =   "fixed-response" order = 1 forward_specification = { content_type = "text/plain" message_body = "This is fixed respone" status_code = "200" } redirect_specification = { status_code = "HTTP_302" host = "www.testapp.com" path = "/testapp" } target_group_specifications = { name = "Test-Application-Loadbalancer" protocol = "HTTP" port = 80 target_type = "instance" vpc_id = "vpc-0df41afb90386ae13" target_ids = ["i-0f6e6690788cf08f2","i-0f6e6690788cf08f2"] target_port = 80 enable_health_check = true health_check_healthy_threshold = 3 health_check_unhealthy_threshold = 3 health_check_interval = 30 health_check_matcher = "200-399" health_check_path = "/healthz" health_check_port = "traffic-port" health_check_protocol = "HTTP" health_check_timeout = 6 enable_stickiness = true stickiness_cookie_duration = 86400 stickiness_type = "lb_cookie" stickiness_cookie_name = "app-cookie" } }]

  tags                                        = {
                                                 Name = "Test"
                                                }

}

```


```hcl

Network Loadbalancer
--------------------

module "elb_network" {
  source                                      = "tfe.axisb.com/ax-tfe/elb/aws"
  version                                     = "X.X.X"

  name                                        = "network-loadbalancer"
  type                                        = "network"
  subnet_ids                                  = ["subnet-1a3eyghbdb10","subnet-sf4gvgv365gv2"]
  sg_ids                                      = ["sg-26tywgvtt76tva"]
  is_internal                                 = true
  enable_access_logging                       = true
  enable_deletion_protection                  = false
  listener_specifications                     = [{ port = 80 protocol = "TCP" type = "forward" order = 2 forward_specification = { content_type = "text/plain" message_body = "This is fixed respone" status_code = "200" } redirect_specification = { status_code = "HTTP_302" host = "www.testapp.com" path = "/testapp" } target_group_specifications = { name = "Test-Network-Loadbalancer" protocol = "TCP" port = 80 target_type = "ip" vpc_id = "vpc-0df41afb90386ae13" target_ids = ["10.24.158.37","10.24.158.60"] target_port = 80 enable_health_check = true health_check_healthy_threshold = 3 health_check_unhealthy_threshold = 3 health_check_interval = 30 health_check_matcher = "200-399" health_check_path = "/healthz" health_check_port = "traffic-port" health_check_protocol = "HTTP" health_check_timeout = 6 enable_stickiness = true stickiness_cookie_duration = 86400 stickiness_type = "source_ip" stickiness_cookie_name = "app-cookie" } }]
  
  tags                                        = {
                                                 Name = "Test"
                                                }

}

```
