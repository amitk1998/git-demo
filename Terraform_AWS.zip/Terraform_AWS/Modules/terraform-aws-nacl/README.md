# **AWS NACL Module**

Terraform module to create NACL on AWS

# **Description**
 
 This module is basically used to create NACL on Amazon Web Services(AWS).
 It requires few attributes in order to be created on AWS like `vpc_id`,`subnet_ids` & `rules`.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_vpc_id"></a>[vpc_id](#input\_vpc_id) | vpc_id to associate with route table | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_existing_network_acl_id"></a>[existing\_network\_acl\_id](#input\_existing\_network\_acl\_id) | existing_network_acl_id | `string` | No | null | `"input your existing network acl id"` |
| <a name = "input_subnet_ids"></a>[subnet_ids](#input\_subnet_ids) | list of subnet_ids to associate with ACL | `list(string)` | No | [ ] | `["subnet-63tygt3t8ue8eu","subnet-38y4tt4744jd"]` |
| <a name = "input_rules"></a>[rules](#input\_rules) | List of network ACL rule | <pre><code>list(object({<br> rule_number  = number<br> rule_type    = string<br> protocol     = string<br> rule_action  = string<br> cidr_block   = string<br> from_port    = number<br> to_port      = number<br> }))</code></pre> | No | [ ] | <pre><code>[<br> {<br> rule_number  = 200<br> rule_type    = "egress"<br> protocol     = "tcp"<br> rule_action  = "allow"<br> cidr_block   = "172.16.0.0/24"<br> from_port    = 22<br> to_port      = 22<br> }<br>]</code></pre> |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "nacl" {
  source                       = "tfe.axisb.com/ax-tfe/nacl/aws"
  version                      = "X.X.X"

  vpc_id                       = "vpc-0yu1gu3yy3atgy"
  subnet_ids                   = ["subnet-63tygt3t8ue8eu","subnet-38y4tt4744jd"]
  rules                        = [{
                                    rule_number  = 200
                                    rule_type    = "egress"
                                    protocol     = "tcp"
                                    rule_action  = "allow"
                                    cidr_block   = "172.16.0.0/24"
                                    from_port    = 20
                                    to_port      = 20
                                 }]
  
  tags                         = {
                                  Name = "Test"
                                  }

}

```