# **AWS Internet Gateway Module**

Terraform module to create IAM on AWS

# **Description**
 
 This module is basically used to create Identity And Access Managment on Amazon Web Services(AWS).
 It requires some attributes like `name`,`assume_role_policy`,`desciption`,`role`,`policy_arn` etc.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_role_name"></a>[role\_name](#input\_role\_name) | Iam Role Name | `string` | No | null | `"Test-Poc-Role"` |
| <a name = "input_iam_policy"></a>[iam\_policy](#input\_iam\_policy) | List of Policies to be included in the Role | <pre><code>list(object({<br> name = optional(string,null)<br> description = optional(string,null)<br> policy = string}))</code></pre> | Yes | `N/A` | `N/A` |
| <a name = "input_policy_arn"></a>[policy\_arn](#input\_policy\_arn) | Trust Relationship Policy for the Iam Role | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_instance_profile_name"></a>[instance\_profile\_name](#input\_instance\_profile\_name) | Instance profile name | `string` | No | null | `"example-profile"` |
| <a name = "input_attach_policy"></a>[attach\_policy](#input\_attach\_policy) | Attach policy to Iam Role | `bool` | No | false | `false` |
| <a name = "input_create_instance_profile"></a>[create\_instance\_profile](#input\_create\_instance\_profile) | Create instance profile | `bool` | No | false | `false` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "iam" {
  source   = "tfe.axisb.com/ax-tfe/iam/aws"
  version  = "X.X.X"

  role_name = "lambda_iam_role"
  
  trust_relationship_policy = jsonencode(
    {
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": [
          "lambda.amazonaws.com",
          "edgelambda.amazonaws.com"
        ]
				"AWS":"arn:aws:iam::1234567890:role/iamrole"
      },
      "Action": "sts:AssumeRole"
    }
  ]
})
  
tags         = {
                Name = "Test"
               }

  policy_arn = ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"] 

  iam_policy = flatten([{
    name = "lambda_test_policy"
    description = "Lambda Test Policy"
    policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement" : [
                {
                    "Sid" : "KMSS3ReadOnly",
                    "Effect" : "Allow",
                    "Action" : [
                        "kms:EnableKey",
                        "kms:GetPublicKey",
                        "kms:ImportKeyMaterial",
                        "kms:Decrypt",
                        "kms:UntagResource",
                        "kms:GenerateRandom",
                        "kms:GenerateDataKeyWithoutPlaintext",
                        "kms:Verify",
                        "kms:ListResourceTags",
                        "kms:CancelKeyDeletion",
                        "kms:GenerateDataKeyPair",
                        "kms:GetParametersForImport",
                        "kms:DescribeCustomKeyStores",
                        "kms:TagResource",
                        "kms:UpdateCustomKeyStore",
                        "kms:Encrypt",
                        "kms:GetKeyRotationStatus",
                        "kms:ScheduleKeyDeletion",
                        "kms:ReEncryptTo",
                        "kms:DescribeKey",
                        "kms:ConnectCustomKeyStore",
                        "kms:Sign",
                        "kms:CreateGrant",
                        "kms:EnableKeyRotation",
                        "kms:ListKeyPolicies",
                        "kms:UpdateKeyDescription",
                        "kms:ListRetirableGrants",
                        "kms:GetKeyPolicy",
                        "kms:GenerateDataKeyPairWithoutPlaintext",
                        "kms:ReEncryptFrom",
                        "kms:DisableKeyRotation",
                        "kms:CreateCustomKeyStore",
                        "kms:ListGrants",
                        "kms:UpdateAlias",
                        "kms:ListKeys",
                        "kms:ListAliases",
                        "kms:GenerateDataKey",
                        "kms:CreateAlias",
                        "kms:DisconnectCustomKeyStore",
                        "s3:Get*",
                        "s3:List*",
                        "s3:Describe*",
                        "s3-object-lambda:Get*",
                        "s3-object-lambda:List*"
                    ],
                    "Resource" : "*"
                }
        ]
    }
    )
  }
  ])

  attach_policy = true
}

```