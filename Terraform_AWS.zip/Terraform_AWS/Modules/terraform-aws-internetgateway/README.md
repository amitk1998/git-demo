# **AWS Internet Gateway Module**

Terraform module to create Internet Gateway on AWS

# **Description**
 
 This module is basically used to create Internet gateway on Amazon Web Services(AWS).
 It requires only one attributes `VPC ID` for association with internet gateway id.

 # **Variable Defination**

| Name | Description | Type | Required | Default | Example |
|------|-------------|------|----------|---------|:-------:|
| <a name = "input_vpc_id"></a>[vpc\_id](#input\_vpc\_id) | The VPC Id used for association with Internet gateway | `string` | Yes | `N/A` | `N/A` |
| <a name = "input_name"></a>[name](#input\_name) | Name of internet gateway | `string` | No | null | `Test-Poc-Igw` |
| <a name = "input_tags"></a>[tags](#input\_tags) | A map of tags assigned to the resource | `map(string)` | No | { } | `{Name = "tag-name"}` |

## **Example Usage**

```hcl

module "internetgateway" {
  source   = "tfe.axisb.com/ax-tfe/internetgateway/aws"
  version  = "X.X.X"
  
  vpc_id   = "your vpc id comes here"
  name     = "test-poc-vpc-igw"
  tags     = {
              Name = "Test"
             }
  
}

```